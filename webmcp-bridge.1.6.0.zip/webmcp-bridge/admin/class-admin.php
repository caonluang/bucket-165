<?php
/**
 * Admin settings page — settings, tool list, live examples, developer API.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class WebMCP_Bridge_Admin {

    private $registry;

    public function __construct( WebMCP_Bridge_Tool_Registry $registry ) {
        $this->registry = $registry;
    }

    public function init() {
        add_action( 'admin_menu',            [ $this, 'add_menu' ] );
        add_action( 'admin_init',            [ $this, 'register_settings' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_admin_scripts' ] );
    }

    public function add_menu() {
        add_options_page(
            __( 'WebMCP Bridge', 'webmcp-bridge' ),
            __( 'WebMCP Bridge', 'webmcp-bridge' ),
            'manage_options',
            'webmcp-bridge',
            [ $this, 'render_page' ]
        );
    }

    public function register_settings() {
        register_setting(
            'webmcp_bridge',
            'webmcp_bridge_options',
            [ 'sanitize_callback' => [ $this, 'sanitize_options' ] ]
        );
    }

    public function sanitize_options( $input ) {
        return [
            'enabled'       => ! empty( $input['enabled'] )       ? 1 : 0,
            'enable_search' => ! empty( $input['enable_search'] ) ? 1 : 0,
            'enable_forms'  => ! empty( $input['enable_forms'] )  ? 1 : 0,
            'enable_woo'    => ! empty( $input['enable_woo'] )    ? 1 : 0,
            'enable_nav'    => ! empty( $input['enable_nav'] )    ? 1 : 0,
            'rate_limit'    => max( 10, min( 1000, (int) ( $input['rate_limit']  ?? 120 ) ) ),
            'rate_window'   => max( 10, min( 3600, (int) ( $input['rate_window'] ?? 60  ) ) ),
        ];
    }

    public function enqueue_admin_scripts( $hook ) {
        if ( 'settings_page_webmcp-bridge' !== $hook ) return;

        wp_enqueue_style(
            'webmcp-bridge-admin',
            WEBMCP_BRIDGE_URL . 'admin/admin.css',
            [],
            WEBMCP_BRIDGE_VERSION
        );

        wp_enqueue_script(
            'webmcp-bridge-admin',
            WEBMCP_BRIDGE_URL . 'admin/admin.js',
            [],
            WEBMCP_BRIDGE_VERSION,
            true
        );

        wp_localize_script( 'webmcp-bridge-admin', 'webmcpAdmin', [
            'executeUrl' => esc_url_raw( rest_url( 'webmcp-bridge/v1/execute' ) ),
            'manifestUrl'=> esc_url_raw( rest_url( 'webmcp-bridge/v1/manifest' ) ),
            'nonce'      => wp_create_nonce( 'wp_rest' ),
            'i18n'       => [
                'copied'   => __( 'Copied!', 'webmcp-bridge' ),
                'copy'     => __( 'Copy', 'webmcp-bridge' ),
                'running'  => __( 'Running…', 'webmcp-bridge' ),
                'run'      => __( 'Run', 'webmcp-bridge' ),
                'error'    => __( 'Error', 'webmcp-bridge' ),
            ],
        ] );
    }

    // -------------------------------------------------------------------------

    public function render_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You do not have permission to access this page.', 'webmcp-bridge' ) );
        }

        $options      = get_option( 'webmcp_bridge_options', [] );
        $tools        = $this->registry->get_all();
        $manifest_url = rest_url( 'webmcp-bridge/v1/manifest' );
        $site_url     = home_url();
        $woo_active   = class_exists( 'WooCommerce' );
        $mescio_active = class_exists( 'Mescio_For_Agents' );

        // Build example calls — use real site URL so they work out of the box
        $examples = $this->get_examples( $site_url );
        ?>
        <div class="wrap webmcp-bridge-admin">

            <!-- Header -->
            <div class="webmcp-header">
                <div class="webmcp-logo">&#9889; WebMCP Bridge</div>
                <p class="webmcp-tagline"><?php esc_html_e( 'Make your WordPress site natively AI-agent friendly via the WebMCP protocol.', 'webmcp-bridge' ); ?></p>
                <?php if ( $mescio_active ) : ?>
                <p class="webmcp-mescio-badge">&#127381; <?php esc_html_e( 'Mescio for Agents detected — extra tools active!', 'webmcp-bridge' ); ?></p>
                <?php endif; ?>
            </div>

            <!-- Row 1: Settings + Tools -->
            <div class="webmcp-grid">

                <!-- Settings -->
                <div class="webmcp-card">
                    <h2><?php esc_html_e( 'Settings', 'webmcp-bridge' ); ?></h2>
                    <form method="post" action="options.php">
                        <?php settings_fields( 'webmcp_bridge' ); ?>
                        <table class="form-table webmcp-table">
                            <?php $this->render_toggle( 'enabled', $options,
                                __( 'Enable WebMCP', 'webmcp-bridge' ),
                                __( 'Exposes the manifest and tool execution endpoints.', 'webmcp-bridge' )
                            ); ?>
                            <?php $this->render_toggle( 'enable_search', $options,
                                __( 'Search &amp; Posts', 'webmcp-bridge' ),
                                __( 'Agents can search posts, pages, categories.', 'webmcp-bridge' )
                            ); ?>
                            <?php $this->render_toggle( 'enable_forms', $options,
                                __( 'Forms', 'webmcp-bridge' ),
                                __( 'Agents can interact with Contact Form 7 forms.', 'webmcp-bridge' )
                            ); ?>
                            <?php $this->render_toggle( 'enable_nav', $options,
                                __( 'Navigation', 'webmcp-bridge' ),
                                __( 'Agents can discover menu structure.', 'webmcp-bridge' )
                            ); ?>
                            <tr>
                                <th scope="row"><?php esc_html_e( 'WooCommerce', 'webmcp-bridge' ); ?></th>
                                <td>
                                    <label class="webmcp-toggle">
                                        <input type="checkbox" name="webmcp_bridge_options[enable_woo]" value="1"
                                            <?php checked( $options['enable_woo'] ?? 0 ); ?>
                                            <?php disabled( ! $woo_active ); ?>>
                                        <span class="webmcp-toggle-slider"></span>
                                    </label>
                                    <?php if ( ! $woo_active ) : ?>
                                        <p class="description webmcp-warn"><?php esc_html_e( 'WooCommerce not detected.', 'webmcp-bridge' ); ?></p>
                                    <?php else : ?>
                                        <p class="description"><?php esc_html_e( 'Agents can search products, manage cart, apply coupons.', 'webmcp-bridge' ); ?></p>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        </table>
                        <!-- Rate limiting -->
                        <tr>
                            <th scope="row"><?php esc_html_e( 'Rate limit (calls)', 'webmcp-bridge' ); ?></th>
                            <td>
                                <input type="number" name="webmcp_bridge_options[rate_limit]" min="10" max="1000"
                                    value="<?php echo esc_attr( $options['rate_limit'] ?? 120 ); ?>" style="width:80px">
                                <p class="description"><?php esc_html_e( 'Max /execute calls allowed in the time window (global, not per-IP). Default: 120.', 'webmcp-bridge' ); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php esc_html_e( 'Rate window (seconds)', 'webmcp-bridge' ); ?></th>
                            <td>
                                <input type="number" name="webmcp_bridge_options[rate_window]" min="10" max="3600"
                                    value="<?php echo esc_attr( $options['rate_window'] ?? 60 ); ?>" style="width:80px">
                                <p class="description"><?php esc_html_e( 'Time window in seconds for the rate limit counter. Default: 60.', 'webmcp-bridge' ); ?></p>
                            </td>
                        </tr>
                        <?php submit_button( esc_html__( 'Save Settings', 'webmcp-bridge' ), 'primary' ); ?>
                    </form>
                </div>

                <!-- Manifest + Tool List -->
                <div class="webmcp-card">
                    <h2><?php esc_html_e( 'Manifest URL', 'webmcp-bridge' ); ?></h2>
                    <p><?php esc_html_e( 'AI agents discover your tools via:', 'webmcp-bridge' ); ?></p>
                    <div class="webmcp-url-box">
                        <code><?php echo esc_html( $manifest_url ); ?></code>
                        <button class="button button-small webmcp-copy" data-url="<?php echo esc_attr( $manifest_url ); ?>">
                            <?php esc_html_e( 'Copy', 'webmcp-bridge' ); ?>
                        </button>
                    </div>

                    <?php if ( ! $mescio_active ) : ?>
                    <div class="webmcp-notice-mescio">
                        <strong><?php esc_html_e( 'Unlock more tools', 'webmcp-bridge' ); ?></strong> —
                        <?php esc_html_e( 'Install Mescio for Agents to enable Markdown export and llms.txt support.', 'webmcp-bridge' ); ?>
                    </div>
                    <?php endif; ?>

                    <h2 style="margin-top:20px">
                        <?php printf(
                            /* translators: %d: number of registered tools */
                            esc_html__( 'Registered Tools (%d)', 'webmcp-bridge' ),
                            count( $tools )
                        ); ?>
                    </h2>
                    <div class="webmcp-tools-list">
                        <?php foreach ( $tools as $name => $tool ) : ?>
                        <div class="webmcp-tool-row">
                            <span class="webmcp-tool-badge webmcp-badge-<?php echo esc_attr( $tool['group'] ?? 'custom' ); ?>">
                                <?php echo esc_html( $tool['group'] ?? 'custom' ); ?>
                            </span>
                            <strong><?php echo esc_html( $name ); ?></strong>
                            <span class="webmcp-tool-desc"><?php echo esc_html( $tool['description'] ?? '' ); ?></span>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <!-- Row 2: Live Examples -->
            <div class="webmcp-card webmcp-examples-card">
                <h2><?php esc_html_e( 'Live API Examples', 'webmcp-bridge' ); ?></h2>
                <p><?php esc_html_e( 'Run these calls directly from this page to test your tools. Results are returned live from your site.', 'webmcp-bridge' ); ?></p>

                <div class="webmcp-tabs">
                    <?php foreach ( $examples as $i => $ex ) : ?>
                    <button class="webmcp-tab <?php echo 0 === $i ? 'is-active' : ''; ?>"
                            data-tab="ex-<?php echo esc_attr( $i ); ?>">
                        <?php echo esc_html( $ex['label'] ); ?>
                    </button>
                    <?php endforeach; ?>
                </div>

                <?php foreach ( $examples as $i => $ex ) : ?>
                <div class="webmcp-tab-panel <?php echo 0 === $i ? 'is-active' : ''; ?>" id="ex-<?php echo esc_attr( $i ); ?>">
                    <p class="webmcp-ex-desc"><?php echo esc_html( $ex['description'] ); ?></p>

                    <div class="webmcp-ex-grid">
                        <!-- curl -->
                        <div>
                            <div class="webmcp-ex-label">
                                curl
                                <button class="webmcp-copy-small webmcp-copy" data-url="<?php echo esc_attr( $ex['curl'] ); ?>">
                                    <?php esc_html_e( 'Copy', 'webmcp-bridge' ); ?>
                                </button>
                            </div>
                            <pre class="webmcp-code webmcp-code-sm"><?php echo esc_html( $ex['curl'] ); ?></pre>
                        </div>

                        <!-- JS -->
                        <div>
                            <div class="webmcp-ex-label">
                                JavaScript
                                <button class="webmcp-copy-small webmcp-copy" data-url="<?php echo esc_attr( $ex['js'] ); ?>">
                                    <?php esc_html_e( 'Copy', 'webmcp-bridge' ); ?>
                                </button>
                            </div>
                            <pre class="webmcp-code webmcp-code-sm"><?php echo esc_html( $ex['js'] ); ?></pre>
                        </div>
                    </div>

                    <!-- Live runner -->
                    <div class="webmcp-runner">
                        <button class="button button-primary webmcp-run"
                                data-tool="<?php echo esc_attr( $ex['tool'] ); ?>"
                                data-params="<?php echo esc_attr( wp_json_encode( $ex['params'] ) ); ?>">
                            &#9654; <?php esc_html_e( 'Run', 'webmcp-bridge' ); ?>
                        </button>
                        <span class="webmcp-run-status"></span>
                        <pre class="webmcp-run-output" style="display:none"></pre>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <!-- Row 3: Developer API -->
            <div class="webmcp-card webmcp-dev-card">
                <h2><?php esc_html_e( 'Register Custom Tools', 'webmcp-bridge' ); ?></h2>
                <p><?php printf(
                    /* translators: %s: filename */
                    esc_html__( 'Add this to your theme\'s %s or a custom plugin:', 'webmcp-bridge' ),
                    '<code>functions.php</code>'
                ); ?></p>
                <pre class="webmcp-code"><?php echo esc_html( $this->get_custom_tool_example() ); ?></pre>
            </div>

        </div>
        <?php
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------

    private function render_toggle( $key, $options, $label, $description ) {
        ?>
        <tr>
            <th scope="row"><?php echo esc_html( $label ); ?></th>
            <td>
                <label class="webmcp-toggle">
                    <input type="checkbox" name="webmcp_bridge_options[<?php echo esc_attr( $key ); ?>]" value="1"
                        <?php checked( $options[ $key ] ?? 0 ); ?>>
                    <span class="webmcp-toggle-slider"></span>
                </label>
                <p class="description"><?php echo esc_html( $description ); ?></p>
            </td>
        </tr>
        <?php
    }

    private function get_examples( $site_url ) {
        $execute = esc_url_raw( rest_url( 'webmcp-bridge/v1/execute' ) );
        $manifest = esc_url_raw( rest_url( 'webmcp-bridge/v1/manifest' ) );

        $examples = [
            [
                'label'       => __( 'Manifest', 'webmcp-bridge' ),
                'description' => __( 'Fetch the full list of tools available on this site.', 'webmcp-bridge' ),
                'tool'        => '__manifest__',
                'params'      => [],
                'curl'        => "curl \\\n  \"" . $manifest . "\"",
                'js'          => "const res = await fetch('" . $manifest . "');\nconst data = await res.json();\nconsole.log(data.tools);",
            ],
            [
                'label'       => __( 'Site Info', 'webmcp-bridge' ),
                'description' => __( 'Return basic metadata about this site: name, URL, language, WordPress version.', 'webmcp-bridge' ),
                'tool'        => 'get_site_info',
                'params'      => (object) [],
                'curl'        => "curl -X POST \\\n  \"" . $execute . "\" \\\n  -H \"Content-Type: application/json\" \\\n  -d '{\"tool\":\"get_site_info\",\"params\":{}}'",
                'js'          => "const res = await fetch('" . $execute . "', {\n  method: 'POST',\n  headers: {'Content-Type':'application/json'},\n  body: JSON.stringify({tool:'get_site_info', params:{}})\n});\nconsole.log(await res.json());",
            ],
            [
                'label'       => __( 'Search Posts', 'webmcp-bridge' ),
                'description' => __( 'Search published posts and pages by keyword.', 'webmcp-bridge' ),
                'tool'        => 'search_posts',
                'params'      => [ 'query' => 'wordpress', 'per_page' => 3 ],
                'curl'        => "curl -X POST \\\n  \"" . $execute . "\" \\\n  -H \"Content-Type: application/json\" \\\n  -d '{\"tool\":\"search_posts\",\"params\":{\"query\":\"wordpress\",\"per_page\":3}}'",
                'js'          => "const res = await fetch('" . $execute . "', {\n  method: 'POST',\n  headers: {'Content-Type':'application/json'},\n  body: JSON.stringify({tool:'search_posts', params:{query:'wordpress', per_page:3}})\n});\nconsole.log(await res.json());",
            ],
            [
                'label'       => __( 'Categories', 'webmcp-bridge' ),
                'description' => __( 'List all post categories with their slugs and post counts.', 'webmcp-bridge' ),
                'tool'        => 'get_categories',
                'params'      => (object) [],
                'curl'        => "curl -X POST \\\n  \"" . $execute . "\" \\\n  -H \"Content-Type: application/json\" \\\n  -d '{\"tool\":\"get_categories\",\"params\":{}}'",
                'js'          => "const res = await fetch('" . $execute . "', {\n  method: 'POST',\n  headers: {'Content-Type':'application/json'},\n  body: JSON.stringify({tool:'get_categories', params:{}})\n});\nconsole.log(await res.json());",
            ],
        ];

        // Add WooCommerce example if active
        if ( class_exists( 'WooCommerce' ) ) {
            $examples[] = [
                'label'       => __( 'Search Products', 'webmcp-bridge' ),
                'description' => __( 'Search WooCommerce products by keyword.', 'webmcp-bridge' ),
                'tool'        => 'woo_search_products',
                'params'      => [ 'query' => '', 'per_page' => 3 ],
                'curl'        => "curl -X POST \\\n  \"" . $execute . "\" \\\n  -H \"Content-Type: application/json\" \\\n  -d '{\"tool\":\"woo_search_products\",\"params\":{\"per_page\":3}}'",
                'js'          => "const res = await fetch('" . $execute . "', {\n  method: 'POST',\n  headers: {'Content-Type':'application/json'},\n  body: JSON.stringify({tool:'woo_search_products', params:{per_page:3}})\n});\nconsole.log(await res.json());",
            ];
        }

        // Add Mescio examples if active
        if ( class_exists( 'Mescio_For_Agents' ) ) {
            $examples[] = [
                'label'       => __( 'llms.txt', 'webmcp-bridge' ),
                'description' => __( 'Return the site-wide llms.txt context — lets agents instantly understand your site. Powered by Mescio for Agents.', 'webmcp-bridge' ),
                'tool'        => 'get_llms_txt',
                'params'      => [ 'variant' => 'index' ],
                'curl'        => "curl -X POST \\\n  \"" . $execute . "\" \\\n  -H \"Content-Type: application/json\" \\\n  -d '{\"tool\":\"get_llms_txt\",\"params\":{\"variant\":\"index\"}}'",
                'js'          => "const res = await fetch('" . $execute . "', {\n  method: 'POST',\n  headers: {'Content-Type':'application/json'},\n  body: JSON.stringify({tool:'get_llms_txt', params:{variant:'index'}})\n});\nconsole.log(await res.json());",
            ];
        }

        return $examples;
    }

    private function get_custom_tool_example() {
        return "add_action( 'plugins_loaded', function() {\n" .
               "    if ( ! class_exists( 'WebMCP_Bridge_Tool_Registry' ) ) return;\n\n" .
               "    \$registry = WebMCP_Bridge_Tool_Registry::instance();\n\n" .
               "    \$registry->register( 'my_custom_tool', [\n" .
               "        'description' => 'Does something useful.',\n" .
               "        'group'       => 'custom',\n" .
               "        'inputSchema' => [\n" .
               "            'type'       => 'object',\n" .
               "            'properties' => [\n" .
               "                'name' => [ 'type' => 'string', 'description' => 'A name.' ],\n" .
               "            ],\n" .
               "            'required' => [ 'name' ],\n" .
               "        ],\n" .
               "        'callback' => function( \$params ) {\n" .
               "            return [ 'hello' => sanitize_text_field( \$params['name'] ) ];\n" .
               "        },\n" .
               "    ] );\n" .
               "} );";
    }
}
