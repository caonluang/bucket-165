/* WebMCP Bridge — Admin UI */
( function( config ) {
    'use strict';

    if ( ! config ) return;

    // -------------------------------------------------------------------------
    // Copy buttons
    // -------------------------------------------------------------------------
    document.querySelectorAll( '.webmcp-copy' ).forEach( function( btn ) {
        btn.addEventListener( 'click', function() {
            var text = btn.dataset.url || btn.dataset.text || '';
            navigator.clipboard.writeText( text ).then( function() {
                var original = btn.textContent;
                btn.textContent = config.i18n.copied;
                setTimeout( function() { btn.textContent = original; }, 2000 );
            } );
        } );
    } );

    // -------------------------------------------------------------------------
    // Tabs
    // -------------------------------------------------------------------------
    document.querySelectorAll( '.webmcp-tab' ).forEach( function( tab ) {
        tab.addEventListener( 'click', function() {
            var target = tab.dataset.tab;
            var container = tab.closest( '.webmcp-examples-card' );

            container.querySelectorAll( '.webmcp-tab' ).forEach( function( t ) {
                t.classList.remove( 'is-active' );
            } );
            container.querySelectorAll( '.webmcp-tab-panel' ).forEach( function( p ) {
                p.classList.remove( 'is-active' );
            } );

            tab.classList.add( 'is-active' );
            var panel = container.querySelector( '#' + target );
            if ( panel ) panel.classList.add( 'is-active' );
        } );
    } );

    // -------------------------------------------------------------------------
    // Live runner
    // -------------------------------------------------------------------------
    document.querySelectorAll( '.webmcp-run' ).forEach( function( btn ) {
        btn.addEventListener( 'click', function() {
            var tool    = btn.dataset.tool;
            var params  = {};
            try { params = JSON.parse( btn.dataset.params ); } catch(e) {}

            var panel   = btn.closest( '.webmcp-tab-panel' );
            var output  = panel.querySelector( '.webmcp-run-output' );
            var status  = panel.querySelector( '.webmcp-run-status' );

            btn.disabled    = true;
            btn.textContent = '\u25B6 ' + config.i18n.running;
            status.textContent = '';
            output.style.display = 'none';
            output.textContent   = '';

            // Manifest is a special case — GET instead of POST
            var fetchPromise;
            if ( tool === '__manifest__' ) {
                fetchPromise = fetch( config.manifestUrl, { cache: 'no-store' } );
            } else {
                fetchPromise = fetch( config.executeUrl, {
                    method  : 'POST',
                    headers : {
                        'Content-Type': 'application/json',
                        'X-WP-Nonce'  : config.nonce,
                    },
                    body: JSON.stringify( { tool: tool, params: params } ),
                } );
            }

            fetchPromise
                .then( function( res ) { return res.json(); } )
                .then( function( data ) {
                    output.textContent   = JSON.stringify( data, null, 2 );
                    output.style.display = 'block';
                    status.textContent   = '';
                } )
                .catch( function( err ) {
                    status.textContent = config.i18n.error + ': ' + err.message;
                } )
                .finally( function() {
                    btn.disabled    = false;
                    btn.textContent = '\u25B6 ' + config.i18n.run;
                } );
        } );
    } );

} )( window.webmcpAdmin || null );
