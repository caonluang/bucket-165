/**
 * WebMCP Bridge — Frontend bridge
 *
 * Registration priority:
 *   1. navigator.modelContext.provideContext()  — current Chrome WebMCP spec
 *   2. window.ai?.tools / navigator.ai?.tools   — legacy Early Preview API
 *   3. window.webmcpBridgeTools                  — vanilla JS public fallback
 */
( function( config ) {
    'use strict';

    if ( ! config ) return;

    // -------------------------------------------------------------------------
    // Internal: call a tool via the REST API
    // -------------------------------------------------------------------------
    async function executeTool( toolName, params ) {
        const res = await fetch( config.restUrl + '/execute', {
            method  : 'POST',
            headers : {
                'Content-Type': 'application/json',
                'X-WP-Nonce'  : config.nonce,
            },
            body: JSON.stringify( { tool: toolName, params: params || {} } ),
        } );

        if ( ! res.ok ) {
            const err = await res.json().catch( () => ( {} ) );
            throw new Error( err.message || `Tool execution failed (HTTP ${ res.status })` );
        }

        return res.json();
    }

    // -------------------------------------------------------------------------
    // Fetch manifest from REST endpoint
    // -------------------------------------------------------------------------
    async function fetchManifest() {
        const res = await fetch( config.restUrl + '/manifest', { cache: 'no-store' } );
        if ( ! res.ok ) throw new Error( 'Could not fetch WebMCP manifest.' );
        return res.json();
    }

    // -------------------------------------------------------------------------
    // Build tool definitions — use inputSchema (not parameters)
    // -------------------------------------------------------------------------
    function buildToolDefinitions( manifest ) {
        return ( manifest.tools || [] ).map( tool => ( {
            name       : tool.name,
            description: tool.description,
            // inputSchema is the correct field per WebMCP spec and Anthropic tool_use format
            inputSchema: tool.inputSchema || { type: 'object', properties: {}, additionalProperties: true },
            execute    : ( params ) => executeTool( tool.name, params ),
        } ) );
    }

    // -------------------------------------------------------------------------
    // Register with the browser WebMCP API
    // Priority: navigator.modelContext.provideContext() > legacy ai.tools
    // -------------------------------------------------------------------------
    async function registerWithBrowserAPI( toolDefinitions ) {

        // 1. Current Chrome WebMCP spec (navigator.modelContext.provideContext)
        if ( navigator.modelContext && typeof navigator.modelContext.provideContext === 'function' ) {
            try {
                await navigator.modelContext.provideContext( {
                    tools: toolDefinitions,
                } );
                console.info( '[WebMCP Bridge] Registered', toolDefinitions.length, 'tools via navigator.modelContext.provideContext()' );
                return true;
            } catch ( e ) {
                console.warn( '[WebMCP Bridge] modelContext.provideContext() failed:', e );
            }
        }

        // 2. Legacy Early Preview API (window.ai?.tools / navigator.ai?.tools)
        const aiTools = window.ai?.tools ?? navigator.ai?.tools ?? null;
        if ( aiTools && typeof aiTools.register === 'function' ) {
            try {
                await aiTools.register( {
                    name : config.siteTitle + ' (WebMCP Bridge)',
                    tools: toolDefinitions,
                } );
                console.info( '[WebMCP Bridge] Registered via legacy ai.tools.register()' );
                return true;
            } catch ( e ) {
                console.warn( '[WebMCP Bridge] Legacy ai.tools registration failed:', e );
            }
        }

        return false;
    }

    // -------------------------------------------------------------------------
    // Inject <meta> tags for agent discovery
    // -------------------------------------------------------------------------
    function injectMetaTags() {
        const meta = document.createElement( 'meta' );
        meta.name    = 'webmcp-manifest';
        meta.content = config.restUrl + '/manifest';
        document.head.appendChild( meta );

        const metaVersion = document.createElement( 'meta' );
        metaVersion.name    = 'webmcp-version';
        metaVersion.content = '1.0';
        document.head.appendChild( metaVersion );
    }

    // -------------------------------------------------------------------------
    // Expose public fallback API for non-WebMCP agents
    // -------------------------------------------------------------------------
    function exposePublicAPI( toolDefinitions ) {
        window.webmcpBridgeTools = {
            version     : '1.0.0',
            site        : config.siteTitle,
            manifestUrl : config.restUrl + '/manifest',
            tools       : {},

            call: function( toolName, params ) {
                return executeTool( toolName, params );
            },

            list: function() {
                return toolDefinitions.map( t => t.name );
            },
        };

        toolDefinitions.forEach( tool => {
            window.webmcpBridgeTools.tools[ tool.name ] = {
                description : tool.description,
                inputSchema : tool.inputSchema,
                call        : ( params ) => executeTool( tool.name, params ),
            };
        } );

        console.info( '[WebMCP Bridge] Public API available at window.webmcpBridgeTools' );
    }

    // -------------------------------------------------------------------------
    // Boot
    // -------------------------------------------------------------------------
    async function boot() {
        try {
            const manifest        = await fetchManifest();
            const toolDefinitions = buildToolDefinitions( manifest );

            injectMetaTags();
            exposePublicAPI( toolDefinitions );

            const registered = await registerWithBrowserAPI( toolDefinitions );
            if ( ! registered ) {
                console.info( '[WebMCP Bridge] No browser WebMCP API available — fallback active.' );
            }

            window.dispatchEvent( new CustomEvent( 'wpwebmcp:ready', {
                detail: { tools: toolDefinitions.map( t => t.name ), manifest },
            } ) );

        } catch ( e ) {
            console.error( '[WebMCP Bridge] Boot error:', e );
        }
    }

    if ( document.readyState === 'loading' ) {
        document.addEventListener( 'DOMContentLoaded', boot );
    } else {
        boot();
    }

} )( window.webmcpBridge || null );
