<?php
/**
 * WooCommerce tools: product search, cart, checkout helpers.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class WebMCP_Bridge_Tools_WooCommerce {

    private $registry;

    public function __construct( WebMCP_Bridge_Tool_Registry $registry ) {
        $this->registry = $registry;
    }

    public function register() {
        $this->registry->register( 'woo_search_products', [
            'description' => 'Search WooCommerce products by keyword, category or price range.',
            'group'       => 'woocommerce',
            'inputSchema' => [
                'type'       => 'object',
                'properties' => [
                    'query'        => [ 'type' => 'string',  'description' => 'Search keywords.' ],
                    'category'     => [ 'type' => 'string',  'description' => 'Category slug.' ],
                    'min_price'    => [ 'type' => 'number',  'description' => 'Minimum price.' ],
                    'max_price'    => [ 'type' => 'number',  'description' => 'Maximum price.' ],
                    'per_page'     => [ 'type' => 'integer', 'description' => 'Results (default: 6, max: 24).' ],
                    'orderby'      => [ 'type' => 'string',  'description' => 'price | popularity | rating | date (default: relevance).' ],
                ],
            ],
            'callback' => [ $this, 'tool_search_products' ],
        ] );

        $this->registry->register( 'woo_get_product', [
            'description' => 'Get full details for a single WooCommerce product.',
            'group'       => 'woocommerce',
            'inputSchema' => [
                'type'       => 'object',
                'properties' => [
                    'id'   => [ 'type' => 'integer', 'description' => 'Product ID.' ],
                    'slug' => [ 'type' => 'string',  'description' => 'Product slug.' ],
                ],
            ],
            'callback' => [ $this, 'tool_get_product' ],
        ] );

        $this->registry->register( 'woo_add_to_cart', [
            'description' => 'Add a product to the WooCommerce cart.',
            'group'       => 'woocommerce',
            'inputSchema' => [
                'type'       => 'object',
                'properties' => [
                    'product_id'   => [ 'type' => 'integer', 'description' => 'Product ID.' ],
                    'quantity'     => [ 'type' => 'integer', 'description' => 'Quantity (default: 1).' ],
                    'variation_id' => [ 'type' => 'integer', 'description' => 'Variation ID for variable products.' ],
                ],
                'required' => [ 'product_id' ],
            ],
            'callback' => [ $this, 'tool_add_to_cart' ],
        ] );

        $this->registry->register( 'woo_get_cart', [
            'description' => 'Return the current cart contents and totals.',
            'group'       => 'woocommerce',
            'inputSchema' => [ 'type' => 'object', 'properties' => [] ],
            'callback'    => [ $this, 'tool_get_cart' ],
        ] );

        $this->registry->register( 'woo_remove_from_cart', [
            'description' => 'Remove an item from the cart by cart item key.',
            'group'       => 'woocommerce',
            'inputSchema' => [
                'type'       => 'object',
                'properties' => [
                    'cart_item_key' => [ 'type' => 'string', 'description' => 'Cart item key from woo_get_cart.' ],
                ],
                'required' => [ 'cart_item_key' ],
            ],
            'callback' => [ $this, 'tool_remove_from_cart' ],
        ] );

        $this->registry->register( 'woo_apply_coupon', [
            'description' => 'Apply a coupon code to the cart.',
            'group'       => 'woocommerce',
            'inputSchema' => [
                'type'       => 'object',
                'properties' => [
                    'coupon_code' => [ 'type' => 'string', 'description' => 'Coupon code.' ],
                ],
                'required' => [ 'coupon_code' ],
            ],
            'callback' => [ $this, 'tool_apply_coupon' ],
        ] );

        $this->registry->register( 'woo_get_checkout_fields', [
            'description' => 'Return the checkout form fields so an agent can fill them.',
            'group'       => 'woocommerce',
            'inputSchema' => [ 'type' => 'object', 'properties' => [] ],
            'callback'    => [ $this, 'tool_get_checkout_fields' ],
        ] );

        $this->registry->register( 'woo_get_product_categories', [
            'description' => 'List all WooCommerce product categories.',
            'group'       => 'woocommerce',
            'inputSchema' => [ 'type' => 'object', 'properties' => [] ],
            'callback'    => [ $this, 'tool_get_product_categories' ],
        ] );
    }

    // -------------------------------------------------------------------------

    public function tool_search_products( $params ) {
        $per_page = min( (int) ( $params['per_page'] ?? 6 ), 24 );

        $args = [
            'post_type'      => 'product',
            'post_status'    => 'publish',
            'posts_per_page' => $per_page,
        ];

        if ( ! empty( $params['query'] ) ) {
            $args['s'] = sanitize_text_field( $params['query'] );
        }

        if ( ! empty( $params['category'] ) ) {
            $args['tax_query'] = [ [ // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
                'taxonomy' => 'product_cat',
                'field'    => 'slug',
                'terms'    => sanitize_key( $params['category'] ),
            ] ];
        }

        if ( ! empty( $params['min_price'] ) || ! empty( $params['max_price'] ) ) {
            $args['meta_query'][] = [ // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
                'key'     => '_price', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
                'value'   => [ floatval( $params['min_price'] ?? 0 ), floatval( $params['max_price'] ?? 999999 ) ],
                'compare' => 'BETWEEN',
                'type'    => 'NUMERIC',
            ];
        }

        $orderby_map = [
            'price'      => [ 'orderby' => 'meta_value_num', 'meta_key' => '_price' ], // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
            'popularity' => [ 'orderby' => 'meta_value_num', 'meta_key' => 'total_sales' ], // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
            'rating'     => [ 'orderby' => 'meta_value_num', 'meta_key' => '_wc_average_rating' ], // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
            'date'       => [ 'orderby' => 'date' ],
        ];
        if ( ! empty( $params['orderby'] ) && isset( $orderby_map[ $params['orderby'] ] ) ) {
            $args = array_merge( $args, $orderby_map[ $params['orderby'] ] );
        }

        $query = new WP_Query( $args );
        $results = [];

        foreach ( $query->posts as $post ) {
            $product = wc_get_product( $post->ID );
            if ( ! $product ) continue;
            $results[] = $this->format_product( $product );
        }

        return [ 'total' => $query->found_posts, 'results' => $results ];
    }

    public function tool_get_product( $params ) {
        if ( ! empty( $params['id'] ) ) {
            $product = wc_get_product( (int) $params['id'] );
        } elseif ( ! empty( $params['slug'] ) ) {
            $post = get_page_by_path( sanitize_title( $params['slug'] ), OBJECT, 'product' );
            $product = $post ? wc_get_product( $post->ID ) : null;
        } else {
            throw new Exception( 'Provide either id or slug.' );
        }

        if ( ! $product ) throw new Exception( 'Product not found.' );

        $data = $this->format_product( $product );
        $data['description'] = wp_strip_all_tags( $product->get_description() );
        $data['attributes']  = [];
        foreach ( $product->get_attributes() as $attr ) {
            $data['attributes'][] = [
                'name'   => wc_attribute_label( $attr->get_name() ),
                'values' => $attr->get_options(),
            ];
        }

        return $data;
    }

    public function tool_add_to_cart( $params ) {
        $product_id   = (int) $params['product_id'];
        $quantity     = max( 1, (int) ( $params['quantity'] ?? 1 ) );
        $variation_id = (int) ( $params['variation_id'] ?? 0 );

        if ( ! WC()->cart ) {
            throw new Exception( 'Cart is not available.' );
        }

        $key = WC()->cart->add_to_cart( $product_id, $quantity, $variation_id );
        if ( false === $key ) {
            throw new Exception( 'Could not add product to cart.' );
        }

        return [
            'cart_item_key' => $key,
            'product_id'    => $product_id,
            'quantity'      => $quantity,
            'cart_total'    => WC()->cart->get_total( 'edit' ),
            'cart_count'    => WC()->cart->get_cart_contents_count(),
        ];
    }

    public function tool_get_cart( $params ) {
        if ( ! WC()->cart ) throw new Exception( 'Cart not available.' );

        $items = [];
        foreach ( WC()->cart->get_cart() as $key => $item ) {
            $product = $item['data'];
            $items[] = [
                'cart_item_key' => $key,
                'product_id'    => $item['product_id'],
                'name'          => $product->get_name(),
                'quantity'      => $item['quantity'],
                'line_total'    => $item['line_total'],
                'price'         => $product->get_price(),
            ];
        }

        return [
            'items'        => $items,
            'subtotal'     => WC()->cart->get_subtotal(),
            'total'        => WC()->cart->get_total( 'edit' ),
            'item_count'   => WC()->cart->get_cart_contents_count(),
            'coupons'      => WC()->cart->get_applied_coupons(),
            'checkout_url' => wc_get_checkout_url(),
        ];
    }

    public function tool_remove_from_cart( $params ) {
        if ( ! WC()->cart ) throw new Exception( 'Cart not available.' );
        $key = sanitize_text_field( $params['cart_item_key'] );
        $removed = WC()->cart->remove_cart_item( $key );
        if ( ! $removed ) throw new Exception( 'Item not found in cart.' );
        return [ 'removed' => true, 'cart_count' => WC()->cart->get_cart_contents_count() ];
    }

    public function tool_apply_coupon( $params ) {
        if ( ! WC()->cart ) throw new Exception( 'Cart not available.' );
        $code = sanitize_text_field( $params['coupon_code'] );
        $applied = WC()->cart->apply_coupon( $code );
        if ( ! $applied ) throw new Exception( 'Coupon could not be applied. It may be invalid or expired.' );
        return [ 'applied' => true, 'coupon' => $code, 'total' => WC()->cart->get_total( 'edit' ) ];
    }

    public function tool_get_checkout_fields( $params ) {
        $checkout = WC()->checkout();
        $fields   = [];

        foreach ( [ 'billing', 'shipping', 'order' ] as $group ) {
            $group_fields = $checkout->get_checkout_fields( $group );
            $fields[ $group ] = [];
            foreach ( $group_fields as $key => $field ) {
                $fields[ $group ][] = [
                    'key'      => $key,
                    'label'    => $field['label'] ?? $key,
                    'type'     => $field['type'] ?? 'text',
                    'required' => $field['required'] ?? false,
                ];
            }
        }

        return $fields;
    }

    public function tool_get_product_categories( $params ) {
        $terms = get_terms( [ 'taxonomy' => 'product_cat', 'hide_empty' => false ] );
        if ( is_wp_error( $terms ) ) throw new Exception( esc_html( $terms->get_error_message() ) );
        return array_map( function( $term ) {
            return [
                'id'    => $term->term_id,
                'name'  => $term->name,
                'slug'  => $term->slug,
                'count' => $term->count,
                'url'   => get_term_link( $term ),
            ];
        }, $terms );
    }

    // -------------------------------------------------------------------------

    private function format_product( WC_Product $product ) {
        return [
            'id'           => $product->get_id(),
            'name'         => $product->get_name(),
            'slug'         => $product->get_slug(),
            'url'          => get_permalink( $product->get_id() ),
            'price'        => $product->get_price(),
            'price_html'   => $product->get_price_html(),
            'sku'          => $product->get_sku(),
            'stock_status' => $product->get_stock_status(),
            'in_stock'     => $product->is_in_stock(),
            'type'         => $product->get_type(),
            'image'        => wp_get_attachment_url( $product->get_image_id() ) ?: '',
            'rating'       => $product->get_average_rating(),
            'categories'   => wp_list_pluck( get_the_terms( $product->get_id(), 'product_cat' ) ?: [], 'name' ),
        ];
    }
}
