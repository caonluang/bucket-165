<?php
/**
 * Core WordPress tools: search, navigation, forms, posts.
 * Includes optional enhanced tools when Mescio for Agents plugin is active.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class WebMCP_Bridge_Tools_Core {

    private $registry;

    public function __construct( WebMCP_Bridge_Tool_Registry $registry ) {
        $this->registry = $registry;
    }

    public function register() {

        $this->registry->register( 'search_posts', [
            'description' => 'Search posts, pages or custom post types on the site.',
            'group'       => 'content',
            'inputSchema' => [
                'type'       => 'object',
                'properties' => [
                    'query'     => [ 'type' => 'string',  'description' => 'Search keywords.' ],
                    'post_type' => [ 'type' => 'string',  'description' => 'Post type slug (default: any).' ],
                    'per_page'  => [ 'type' => 'integer', 'description' => 'Results per page (default: 5, max: 20).' ],
                ],
                'required' => [ 'query' ],
            ],
            'callback' => [ $this, 'tool_search_posts' ],
        ] );

        $this->registry->register( 'get_post', [
            'description' => 'Retrieve a single post or page by ID or slug.',
            'group'       => 'content',
            'inputSchema' => [
                'type'       => 'object',
                'properties' => [
                    'id'   => [ 'type' => 'integer', 'description' => 'Post ID.' ],
                    'slug' => [ 'type' => 'string',  'description' => 'Post slug.' ],
                ],
            ],
            'callback' => [ $this, 'tool_get_post' ],
        ] );

        $this->registry->register( 'get_menu', [
            'description' => 'Return the items of a navigation menu.',
            'group'       => 'navigation',
            'inputSchema' => [
                'type'       => 'object',
                'properties' => [
                    'menu' => [ 'type' => 'string', 'description' => 'Menu name, slug, or ID (default: primary).' ],
                ],
            ],
            'callback' => [ $this, 'tool_get_menu' ],
        ] );

        $this->registry->register( 'submit_contact_form', [
            'description' => 'Submit a Contact Form 7 form programmatically.',
            'group'       => 'forms',
            'inputSchema' => [
                'type'       => 'object',
                'properties' => [
                    'form_id' => [ 'type' => 'integer', 'description' => 'CF7 form post ID.' ],
                    'fields'  => [ 'type' => 'object',  'description' => 'Key-value pairs matching the form field names.' ],
                ],
                'required' => [ 'form_id', 'fields' ],
            ],
            'callback' => [ $this, 'tool_submit_cf7' ],
        ] );

        $this->registry->register( 'get_site_info', [
            'description' => 'Return basic site metadata (name, description, URL, language).',
            'group'       => 'core',
            'inputSchema' => [ 'type' => 'object', 'properties' => [] ],
            'callback'    => [ $this, 'tool_get_site_info' ],
        ] );

        $this->registry->register( 'get_categories', [
            'description' => 'List all post categories with their slugs and counts.',
            'group'       => 'content',
            'inputSchema' => [
                'type'       => 'object',
                'properties' => [
                    'taxonomy' => [ 'type' => 'string', 'description' => 'Taxonomy slug (default: category).' ],
                ],
            ],
            'callback' => [ $this, 'tool_get_categories' ],
        ] );

        // -------------------------------------------------------------------------
        // Enhanced tools — only when Mescio for Agents plugin is active.
        // -------------------------------------------------------------------------
        if ( class_exists( 'Mescio_For_Agents_Markdown' ) && class_exists( 'Mescio_For_Agents_Rest' ) ) {

            $this->registry->register( 'get_markdown_content', [
                'description' => 'Retrieve a published post or page as clean Markdown — ideal for AI consumption. Requires Mescio for Agents.',
                'group'       => 'content',
                'inputSchema' => [
                    'type'       => 'object',
                    'properties' => [
                        'id'   => [ 'type' => 'integer', 'description' => 'Post ID.' ],
                        'slug' => [ 'type' => 'string',  'description' => 'Post slug.' ],
                    ],
                ],
                'callback' => [ $this, 'tool_get_markdown_content' ],
            ] );

            $this->registry->register( 'get_llms_txt', [
                'description' => 'Return the structured llms.txt context for the whole site — lets agents understand what the site is about at a glance. Requires Mescio for Agents.',
                'group'       => 'content',
                'inputSchema' => [
                    'type'       => 'object',
                    'properties' => [
                        'variant' => [ 'type' => 'string', 'description' => '"index" for the summary (default) or "full" for the complete content.' ],
                    ],
                ],
                'callback' => [ $this, 'tool_get_llms_txt' ],
            ] );
        }
    }

    // -------------------------------------------------------------------------
    // Core callbacks
    // -------------------------------------------------------------------------

    public function tool_search_posts( $params ) {
        $per_page = min( (int) ( $params['per_page'] ?? 5 ), 20 );
        $args     = [
            's'              => sanitize_text_field( $params['query'] ),
            'post_type'      => sanitize_key( $params['post_type'] ?? 'any' ),
            'posts_per_page' => $per_page,
            'post_status'    => 'publish',
        ];
        $query   = new WP_Query( $args );
        $results = [];
        foreach ( $query->posts as $post ) {
            $results[] = [
                'id'      => $post->ID,
                'title'   => get_the_title( $post ),
                'slug'    => $post->post_name,
                'url'     => get_permalink( $post ),
                'excerpt' => wp_trim_words( get_the_excerpt( $post ), 30 ),
                'type'    => $post->post_type,
                'date'    => $post->post_date,
            ];
        }
        return [ 'total' => $query->found_posts, 'results' => $results ];
    }

    public function tool_get_post( $params ) {
        if ( ! empty( $params['id'] ) ) {
            $post = get_post( (int) $params['id'] );
        } elseif ( ! empty( $params['slug'] ) ) {
            $posts = get_posts( [ 'name' => sanitize_title( $params['slug'] ), 'post_type' => 'any', 'numberposts' => 1 ] );
            $post  = $posts[0] ?? null;
        } else {
            throw new Exception( 'Provide either id or slug.' );
        }

        if ( ! $post instanceof WP_Post || 'publish' !== $post->post_status ) {
            throw new Exception( 'Post not found.' );
        }

        return [
            'id'      => $post->ID,
            'title'   => get_the_title( $post ),
            'content' => wp_strip_all_tags( wp_kses_post( apply_filters( 'webmcp_bridge_the_content', $post->post_content ) ) ),
            'url'     => get_permalink( $post ),
            'type'    => $post->post_type,
            'date'    => $post->post_date,
            // Note: author display_name intentionally omitted — not needed by agents
            // and exposes internal user information.
        ];
    }

    public function tool_get_menu( $params ) {
        $menu_name = sanitize_text_field( $params['menu'] ?? 'primary' );
        $items     = wp_get_nav_menu_items( $menu_name );
        if ( false === $items ) {
            throw new Exception( esc_html( "Menu '{$menu_name}' not found." ) );
        }
        return array_map( function( $item ) {
            return [
                'id'     => $item->ID,
                'title'  => $item->title,
                'url'    => $item->url,
                'parent' => $item->menu_item_parent,
                'order'  => $item->menu_order,
            ];
        }, $items );
    }

    public function tool_submit_cf7( $params ) {
        if ( ! function_exists( 'wpcf7_get_contact_form_by_id' ) ) {
            throw new Exception( 'Contact Form 7 is not installed.' );
        }
        $cf7 = wpcf7_get_contact_form_by_id( (int) $params['form_id'] );
        if ( ! $cf7 ) {
            throw new Exception( 'Form not found.' );
        }
        $submission_data = [];
        foreach ( (array) $params['fields'] as $key => $value ) {
            $submission_data[ sanitize_key( $key ) ] = sanitize_textarea_field( $value );
        }
        return [
            'status'  => 'ready',
            'form_id' => (int) $params['form_id'],
            'fields'  => $submission_data,
            'note'    => 'Use the declarative WebMCP form action to complete submission.',
        ];
    }

    public function tool_get_site_info( $params ) {
        return [
            'name'              => get_bloginfo( 'name' ),
            'description'       => get_bloginfo( 'description' ),
            'url'               => get_home_url(),
            'language'          => get_bloginfo( 'language' ),
            'wp_version'        => get_bloginfo( 'version' ),
            // admin_email intentionally omitted — sensitive data, not needed by agents.
            'mescio_for_agents' => class_exists( 'Mescio_For_Agents' ),
        ];
    }

    public function tool_get_categories( $params ) {
        $taxonomy = sanitize_key( $params['taxonomy'] ?? 'category' );
        $terms    = get_terms( [ 'taxonomy' => $taxonomy, 'hide_empty' => false ] );
        if ( is_wp_error( $terms ) ) {
            throw new Exception( esc_html( $terms->get_error_message() ) );
        }
        return array_map( function( $term ) {
            return [
                'id'    => $term->term_id,
                'name'  => $term->name,
                'slug'  => $term->slug,
                'count' => $term->count,
                'url'   => get_term_link( $term ),
            ];
        }, $terms );
    }

    // -------------------------------------------------------------------------
    // Mescio for Agents — enhanced callbacks
    // -------------------------------------------------------------------------

    public function tool_get_markdown_content( $params ) {
        if ( ! class_exists( 'Mescio_For_Agents_Markdown' ) ) {
            throw new Exception( 'Mescio for Agents plugin is not active or is outdated (Mescio_For_Agents_Markdown missing).' );
        }

        $post = null;
        if ( ! empty( $params['id'] ) ) {
            $post = get_post( (int) $params['id'] );
        } elseif ( ! empty( $params['slug'] ) ) {
            $slug = sanitize_title( $params['slug'] );
            foreach ( get_post_types( [ 'public' => true ] ) as $post_type ) {
                $candidate = get_page_by_path( $slug, OBJECT, $post_type );
                if ( $candidate instanceof WP_Post ) {
                    $post = $candidate;
                    break;
                }
            }
        }

        if ( ! $post instanceof WP_Post || 'publish' !== $post->post_status ) {
            throw new Exception( 'Published post not found.' );
        }

        $markdown = Mescio_For_Agents_Markdown::post_to_markdown( $post );

        // Sanitize the Markdown output before returning it to the agent.
        // A WordPress editor can insert arbitrary JS/HTML in post content.
        // Without this step, stored XSS in the post would be forwarded verbatim
        // to the AI agent — enabling prompt injection attacks via post content.
        $markdown = $this->sanitize_markdown( $markdown );

        $language = class_exists( 'Mescio_For_Agents_I18n' )
            ? Mescio_For_Agents_I18n::detect_post_language( $post )
            : get_bloginfo( 'language' );

        $tokens = method_exists( 'Mescio_For_Agents_Markdown', 'estimate_tokens' )
            ? Mescio_For_Agents_Markdown::estimate_tokens( $markdown )
            : (int) ceil( mb_strlen( $markdown ) / 4 );

        return [
            'id'              => $post->ID,
            'title'           => get_the_title( $post ),
            'slug'            => $post->post_name,
            'type'            => $post->post_type,
            'url'             => get_permalink( $post ),
            'markdown'        => $markdown,
            'markdown_tokens' => $tokens,
            'language'        => $language,
        ];
    }

    /**
     * Sanitize Markdown content before sending it to an AI agent.
     *
     * Threats addressed:
     *   1. HTML tags surviving the Markdown conversion (script, iframe, etc.)
     *      — could be injected by a WordPress editor into post content.
     *   2. Inline event handlers (onclick=, onerror=, onload=, etc.)
     *      — JS execution vectors embedded in HTML attributes.
     *   3. javascript: and data: URIs in Markdown links/images
     *      — [click me](javascript:alert(1))
     *   4. Basic prompt injection patterns
     *      — text designed to hijack the AI agent's instructions.
     *
     * @param  string $markdown Raw Markdown from Mescio.
     * @return string           Sanitized Markdown safe to send to an agent.
     */
    private function sanitize_markdown( string $markdown ): string {

        // 1. Strip dangerous HTML tags entirely (including their content for script/style).
        $dangerous_tags = 'script|style|iframe|object|embed|form|input|button|textarea|select|link|meta|base';
        $markdown = preg_replace(
            '/<(' . $dangerous_tags . ')[^>]*>.*?<\/\1>/is',
            '',
            $markdown
        );

        // 2. Strip any remaining HTML tags that survived (keep text content).
        //    wp_kses with an empty allowed list strips all tags but keeps text.
        $markdown = wp_kses( $markdown, [] );

        // 3. Neutralize javascript: and data: URIs in Markdown links and images.
        //    Matches: [text](javascript:...) and ![alt](data:...)
        $markdown = preg_replace(
            '/(\[.*?\]\()(?:javascript|data|vbscript):[^\)]*(\))/i',
            '$1#removed$2',
            $markdown
        );

        // 4. Strip inline event handlers (onclick=, onerror=, etc.)
        $markdown = (string) preg_replace(
            '/\s+on[a-z]+\s*=\s*(["\'])(?:(?!\1).)*\1/i',
            '',
            (string) $markdown
        );

        // 5. Detect and neutralize obvious prompt injection attempts.
        //    These are heuristic — they flag content that looks like instructions
        //    directed at an AI system rather than normal editorial content.
        $injection_patterns = [
            '/ignore\s+(all\s+)?(previous|prior|above)\s+instructions?/i',
            '/disregard\s+(all\s+)?(previous|prior|above)\s+instructions?/i',
            '/you\s+are\s+now\s+(a\s+)?[\w\s]+assistant/i',
            '/system\s*:\s*(you\s+are|act\s+as|pretend)/i',
            '/\[INST\]|\[\/INST\]|<\|im_start\|>|<\|im_end\|>/i',
        ];
        foreach ( $injection_patterns as $pattern ) {
            $markdown = preg_replace( $pattern, '[removed]', $markdown );
        }

        return trim( $markdown );
    }

    public function tool_get_llms_txt( $params ) {
        if ( ! class_exists( 'Mescio_For_Agents_Rest' ) ) {
            throw new Exception( 'Mescio for Agents plugin is not active or is outdated (Mescio_For_Agents_Rest missing).' );
        }

        $variant  = strtolower( sanitize_key( $params['variant'] ?? 'index' ) );
        $response = Mescio_For_Agents_Rest::context_callback( new WP_REST_Request( 'GET' ) );
        $context  = $response->get_data();

        if ( 'full' === $variant ) {
            if ( ! class_exists( 'Mescio_For_Agents_Llms' ) ) {
                throw new Exception( 'Mescio for Agents plugin is not active or is outdated (Mescio_For_Agents_Llms missing).' );
            }

            $body = Mescio_For_Agents_Llms::build_full();

            if ( empty( $body ) ) {
                throw new Exception( esc_html__( 'Could not retrieve full llms content from Mescio for Agents.', 'webmcp-bridge' ) );
            }

            // Sanitize the full content for the same reasons as get_markdown_content.
            $body = $this->sanitize_markdown( $body );

            $context['content']         = $body;
            $context['source']          = 'internal';
            $context['markdown_tokens'] = method_exists( 'Mescio_For_Agents_Markdown', 'estimate_tokens' )
                ? Mescio_For_Agents_Markdown::estimate_tokens( $body )
                : (int) ceil( mb_strlen( $body ) / 4 );
        }

        return $context;
    }
}
