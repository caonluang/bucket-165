<?php
/**
 * Agent Discovery — RFC 8288 Link headers, MCP Server Card, API Catalog, Agent Skills index.
 *
 * Implements four discovery standards so AI agents can find and understand
 * this site's capabilities without manual configuration:
 *
 *   1. Link response headers (RFC 8288) on the homepage
 *   2. MCP Server Card at /.well-known/mcp/server-card.json  (SEP-1649)
 *   3. API Catalog      at /.well-known/api-catalog          (RFC 9727)
 *   4. Agent Skills     at /.well-known/agent-skills/index.json
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class WebMCP_Bridge_Discovery {

    public function init() {
        add_action( 'rest_api_init',     [ $this, 'register_routes' ] );
        add_action( 'template_redirect', [ $this, 'serve_well_known' ] );

        // A) <link> tags in HTML <head> — survive nginx cache, RFC 8288 §4.2 compliant
        add_action( 'wp_head',           [ $this, 'print_link_tags' ], 1 );

        // B) HTTP Link headers when PHP runs (cache miss / bypass)
        add_filter( 'wp_headers',        [ $this, 'add_link_headers' ] );

        // C) Content Signals in robots.txt (contentsignals.org spec)
        add_filter( 'robots_txt',        [ $this, 'add_robots_content_signals' ], 10, 2 );
    }

    // -------------------------------------------------------------------------
    // 1. Link response headers (RFC 8288)
    // -------------------------------------------------------------------------

    /**
     * Inject RFC 8288 Link headers via wp_headers filter.
     * This fires after WP query is set up, so is_front_page() works correctly.
     * We add the headers on every page (not just homepage) so agents can
     * discover the API from any entry point — this is standard practice.
     *
     * @param array $headers Existing headers array.
     * @return array Modified headers array.
     */
    public function add_link_headers( array $headers ): array {
        $options = get_option( 'webmcp_bridge_options', [] );
        if ( empty( $options['enabled'] ) ) return $headers;

        $manifest = esc_url_raw( rest_url( 'webmcp-bridge/v1/manifest' ) );
        $catalog  = esc_url_raw( home_url( '/.well-known/api-catalog' ) );
        $mcp_card = esc_url_raw( home_url( '/.well-known/mcp/server-card.json' ) );

        $openapi = esc_url_raw( rest_url( 'webmcp-bridge/v1/manifest' ) );

        // RFC 8288 — full set of relations for maximum agent compatibility
        $link = '<' . $catalog  . '>; rel="api-catalog"; type="application/linkset+json", '
              . '<' . $openapi  . '>; rel="service-desc"; type="application/json", '
              . '<' . $openapi  . '>; rel="service-doc"; type="application/json", '
              . '<' . $manifest . '>; rel="webmcp-manifest", '
              . '<' . $mcp_card . '>; rel="mcp-server-card"';

        if ( isset( $headers['Link'] ) ) {
            $headers['Link'] .= ', ' . $link;
        } else {
            $headers['Link'] = $link;
        }

        // Ensure caches vary by Accept header so Markdown for Agents works correctly.
        // Without this, nginx may serve cached HTML to agents requesting text/markdown.
        if ( isset( $headers['Vary'] ) ) {
            if ( false === strpos( $headers['Vary'], 'Accept' ) ) {
                $headers['Vary'] .= ', Accept';
            }
        } else {
            $headers['Vary'] = 'Accept';
        }

        return $headers;
    }

    /**
     * Print <link> tags in <head> for RFC 8288 discovery.
     * These are part of the cached HTML so they work even when nginx
     * serves a cached page without running PHP.
     * RFC 8288 §4.2 explicitly allows Link relations in HTML link elements.
     */
    public function print_link_tags() {
        $options = get_option( 'webmcp_bridge_options', [] );
        if ( empty( $options['enabled'] ) ) return;

        $manifest = esc_url( rest_url( 'webmcp-bridge/v1/manifest' ) );
        $catalog  = esc_url( home_url( '/.well-known/api-catalog' ) );
        $mcp_card = esc_url( home_url( '/.well-known/mcp/server-card.json' ) );
        $skills   = esc_url( home_url( '/.well-known/agent-skills/index.json' ) );

        $openapi = esc_url( rest_url( 'webmcp-bridge/v1/manifest' ) );

        echo "
<!-- WebMCP Bridge: agent discovery (RFC 8288) -->
";
        echo '<link rel="api-catalog" href="' . $catalog  . '" type="application/linkset+json">' . "
";
        echo '<link rel="service-desc" href="' . $openapi  . '" type="application/json">' . "
";
        echo '<link rel="service-doc"  href="' . $openapi  . '" type="application/json">' . "
";
        echo '<link rel="webmcp-manifest" href="' . $manifest . '">' . "
";
        echo '<link rel="mcp-server-card" href="' . $mcp_card . '">' . "
";
        echo '<link rel="agent-skills" href="' . $skills . '">' . "
";
        echo "<!-- /WebMCP Bridge -->

";
    }

    // -------------------------------------------------------------------------
    // 2/3/4. /.well-known/* endpoints via template_redirect
    // -------------------------------------------------------------------------

    public function serve_well_known() {
        $request_uri = $_SERVER['REQUEST_URI'] ?? '';
        $path        = strtok( $request_uri, '?' );

        $options = get_option( 'webmcp_bridge_options', [] );
        if ( empty( $options['enabled'] ) ) return;

        switch ( $path ) {
            case '/.well-known/mcp/server-card.json':
                $this->serve_json( $this->build_mcp_server_card() );
                break;
            case '/.well-known/api-catalog':
                $this->serve_json( $this->build_api_catalog(), 'application/linkset+json' );
                break;
            case '/.well-known/agent-skills/index.json':
                $this->serve_json( $this->build_agent_skills() );
                break;
            // OAuth discovery — served always so agents can discover auth mechanism.
            // WordPress uses nonce auth; the endpoints explain this to agents.
            // WooCommerce endpoints are additionally included when WC is active.
            case '/.well-known/oauth-authorization-server':
            case '/.well-known/openid-configuration':
                $this->serve_json( $this->build_oauth_server() );
                break;
            case '/.well-known/oauth-protected-resource':
                $this->serve_json( $this->build_oauth_protected_resource() );
                break;
            case '/.well-known/ucp':
                if ( class_exists( 'WooCommerce' ) ) {
                    $this->serve_json( $this->build_ucp_profile() );
                }
                break;
            case '/.well-known/acp.json':
                if ( class_exists( 'WooCommerce' ) ) {
                    $this->serve_json( $this->build_acp_discovery() );
                }
                break;
        }
    }

    private function serve_json( array $data, string $content_type = 'application/json' ) {
        status_header( 200 );
        header( 'Content-Type: ' . $content_type . '; charset=utf-8' );
        header( 'Cache-Control: public, max-age=3600' );
        echo wp_json_encode( $data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES );
        exit;
    }

    // -------------------------------------------------------------------------
    // Builders
    // -------------------------------------------------------------------------

    /**
     * MCP Server Card (SEP-1649)
     * Tells agents this site exposes MCP-compatible tools via WebMCP Bridge.
     */
    private function build_mcp_server_card(): array {
        $manifest_url = rest_url( 'webmcp-bridge/v1/manifest' );
        $execute_url  = rest_url( 'webmcp-bridge/v1/execute' );

        return [
            '$schema'    => 'https://modelcontextprotocol.io/schema/server-card/v1',
            'serverInfo' => [
                'name'    => get_bloginfo( 'name' ) . ' — WebMCP Bridge',
                'version' => WEBMCP_BRIDGE_VERSION,
            ],
            'description' => sprintf(
                'WebMCP Bridge exposes WordPress tools for AI agents on %s. ' .
                'Agents can search content, read posts, navigate menus, and interact with WooCommerce.',
                get_bloginfo( 'name' )
            ),
            'transport'   => [
                [
                    'type'        => 'http',
                    'url'         => $execute_url,
                    'method'      => 'POST',
                    'contentType' => 'application/json',
                ],
            ],
            'capabilities' => [
                'tools' => true,
            ],
            'links' => [
                'manifest'     => $manifest_url,
                'homepage'     => home_url( '/' ),
                'plugin'       => 'https://wordpress.org/plugins/webmcp-bridge/',
            ],
        ];
    }

    /**
     * API Catalog (RFC 9727)
     * Machine-readable index of all APIs this site exposes.
     */
    private function build_api_catalog(): array {
        $manifest_url  = rest_url( 'webmcp-bridge/v1/manifest' );
        $execute_url   = rest_url( 'webmcp-bridge/v1/execute' );
        $wp_rest_url   = rest_url();

        $linkset = [
            [
                'anchor' => home_url( '/' ),
                $manifest_url => [
                    [ 'rel' => 'service-desc', 'type' => 'application/json' ],
                ],
                $execute_url => [
                    [ 'rel' => 'service-endpoint', 'type' => 'application/json' ],
                ],
                $wp_rest_url => [
                    [ 'rel' => 'https://api.w.org/' ],
                ],
            ],
        ];

        // Add Mescio OpenAPI if available
        if ( class_exists( 'Mescio_For_Agents_Rest' ) ) {
            $openapi_url = rest_url( 'mescio-for-agents/v1/openapi' );
            $linkset[0][ $openapi_url ] = [
                [ 'rel' => 'service-desc', 'type' => 'application/vnd.oai.openapi+json' ],
            ];
        }

        return [ 'linkset' => $linkset ];
    }

    /**
     * Agent Skills index (Agent Skills Discovery RFC v0.2.0)
     * Lists what this site can do in a format agents can parse and act on.
     */
    /**
     * Build Agent Skills index (v0.2.0).
     * Required fields per skill: name, type, description, url, sha256.
     * sha256 is a digest of the skill url string — used by validators to verify integrity.
     */
    private function build_agent_skills(): array {
        $manifest_url = rest_url( 'webmcp-bridge/v1/manifest' );
        $execute_url  = rest_url( 'webmcp-bridge/v1/execute' );
        $wp_rest_url  = rest_url();

        $skills = [
            [
                'name'        => 'webmcp-bridge',
                'type'        => 'webmcp',
                'description' => 'WebMCP tool execution endpoint — search posts, navigate menus, manage WooCommerce cart, and more.',
                'url'         => $execute_url,
                'sha256'      => hash( 'sha256', $execute_url ),
                'manifest'    => $manifest_url,
            ],
            [
                'name'        => 'wp-rest-api',
                'type'        => 'rest-api',
                'description' => 'WordPress REST API — full access to posts, pages, taxonomies, and users.',
                'url'         => $wp_rest_url,
                'sha256'      => hash( 'sha256', $wp_rest_url ),
            ],
        ];

        // Add Mescio skills if active
        if ( class_exists( 'Mescio_For_Agents_Rest' ) ) {
            $mescio_url   = rest_url( 'mescio-for-agents/v1' );
            $skills[] = [
                'name'        => 'mescio-markdown',
                'type'        => 'rest-api',
                'description' => 'Mescio for Agents — retrieve posts as clean Markdown and access the site llms.txt context.',
                'url'         => $mescio_url,
                'sha256'      => hash( 'sha256', $mescio_url ),
                'openapi'     => rest_url( 'mescio-for-agents/v1/openapi' ),
            ];
        }

        return [
            '$schema' => 'https://agentskills.io/schema/v0.2.0/index.json',
            'version' => '0.2.0',
            'updated' => gmdate( 'Y-m-d\TH:i:s\Z' ),
            'skills'  => $skills,
        ];
    }

    // -------------------------------------------------------------------------
    // Content Signals in robots.txt
    // -------------------------------------------------------------------------

    /**
     * Append Content-Signal directives to robots.txt.
     *
     * Content Signals (contentsignals.org) let site owners declare preferences
     * for how AI systems may use their content:
     *   ai-train  — whether content may be used to train AI models
     *   search    — whether content may be indexed for AI search
     *   ai-input  — whether content may be used as real-time AI input
     *
     * Defaults to permissive (yes to all) — filterable via
     * webmcp_bridge_content_signals so site owners can customise.
     *
     * @param string $output  Current robots.txt content.
     * @param bool   $public  Whether the site is public.
     * @return string         Modified robots.txt content.
     */
    public function add_robots_content_signals( string $output, bool $public ): string {
        $options = get_option( 'webmcp_bridge_options', [] );
        if ( empty( $options['enabled'] ) ) return $output;

        $signals = (array) apply_filters( 'webmcp_bridge_content_signals', [
            'ai-train' => 'yes',
            'search'   => 'yes',
            'ai-input' => 'yes',
        ] );

        $parts = [];
        foreach ( $signals as $key => $value ) {
            $parts[] = sanitize_key( $key ) . '=' . ( 'yes' === $value ? 'yes' : 'no' );
        }

        if ( ! empty( $parts ) ) {
            $output .= "
# AI Content Signals (contentsignals.org)
";
            $output .= 'Content-Signal: ' . implode( ', ', $parts ) . "
";
        }

        return $output;
    }

    // -------------------------------------------------------------------------
    // Commerce protocols — WooCommerce only
    // -------------------------------------------------------------------------

    /**
     * OAuth Authorization Server metadata (RFC 8414).
     *
     * WordPress uses cookie/nonce auth, not OAuth tokens. However, agents
     * that follow RFC 8414 for API discovery expect this endpoint. We expose
     * the WP REST API nonce endpoint as the "token" mechanism so agents
     * understand how to authenticate with protected tools.
     */
    private function build_oauth_server(): array {
        return [
            'issuer'                            => home_url( '/' ),
            'authorization_endpoint'            => wp_login_url(),
            'token_endpoint'                    => rest_url( 'webmcp-bridge/v1/nonce' ),
            'token_endpoint_auth_methods_supported' => [ 'none' ],
            'grant_types_supported'             => [ 'implicit' ],
            'response_types_supported'          => [ 'token' ],
            'scopes_supported'                  => [ 'webmcp' ],
            'service_documentation'             => 'https://wordpress.org/plugins/webmcp-bridge/',
            'x_wordpress_auth'                  => [
                'type'        => 'nonce',
                'nonce_action' => 'wp_rest',
                'header'      => 'X-WP-Nonce',
                'endpoint'    => rest_url( 'webmcp-bridge/v1/nonce' ),
            ],
        ];
    }

    /**
     * OAuth Protected Resource metadata (RFC 9728).
     * Tells agents which authorization server protects this resource
     * and what scopes are supported.
     */
    private function build_oauth_protected_resource(): array {
        return [
            'resource'              => rest_url( 'webmcp-bridge/v1' ),
            'authorization_servers' => [ home_url( '/' ) ],
            'scopes_supported'      => [ 'webmcp' ],
            'bearer_methods_supported' => [ 'header' ],
            'resource_documentation'   => 'https://wordpress.org/plugins/webmcp-bridge/',
            'x_wordpress_auth'      => [
                'type'        => 'nonce',
                'nonce_action' => 'wp_rest',
                'header'      => 'X-WP-Nonce',
            ],
        ];
    }

    /**
     * Universal Commerce Protocol profile (ucp.dev).
     * Exposes WooCommerce capabilities in UCP format for commerce agents.
     */
    private function build_ucp_profile(): array {
        $execute_url = rest_url( 'webmcp-bridge/v1/execute' );

        return [
            'protocol'     => [ 'name' => 'ucp', 'version' => '1.0' ],
            'services'     => [
                [
                    'name'        => 'product-search',
                    'description' => 'Search WooCommerce products by keyword, category or price.',
                    'endpoint'    => $execute_url,
                    'tool'        => 'woo_search_products',
                ],
                [
                    'name'        => 'product-detail',
                    'description' => 'Get full details for a single product.',
                    'endpoint'    => $execute_url,
                    'tool'        => 'woo_get_product',
                ],
                [
                    'name'        => 'cart',
                    'description' => 'Add, remove and view cart items.',
                    'endpoint'    => $execute_url,
                    'tools'       => [ 'woo_add_to_cart', 'woo_get_cart', 'woo_remove_from_cart' ],
                ],
                [
                    'name'        => 'checkout',
                    'description' => 'Apply coupons and retrieve checkout fields.',
                    'endpoint'    => $execute_url,
                    'tools'       => [ 'woo_apply_coupon', 'woo_get_checkout_fields' ],
                ],
            ],
            'capabilities' => [
                'search'   => true,
                'cart'     => true,
                'checkout' => true,
                'payments' => false,
            ],
            'auth' => [
                'type'   => 'wordpress-nonce',
                'header' => 'X-WP-Nonce',
            ],
            'manifest' => rest_url( 'webmcp-bridge/v1/manifest' ),
        ];
    }

    /**
     * Agentic Commerce Protocol discovery document (agenticcommerce.dev).
     * Lets commerce agents discover the store API without creating a session first.
     */
    private function build_acp_discovery(): array {
        $execute_url = rest_url( 'webmcp-bridge/v1/execute' );

        return [
            'protocol' => [
                'name'    => 'acp',
                'version' => '1.0',
            ],
            'api_base_url' => rest_url( 'webmcp-bridge/v1' ),
            'transports'   => [ 'https' ],
            'capabilities' => [
                'services' => [ 'product-catalog', 'cart', 'checkout', 'coupons' ],
            ],
            'endpoints' => [
                'manifest' => rest_url( 'webmcp-bridge/v1/manifest' ),
                'execute'  => $execute_url,
                'products' => [
                    'search' => [ 'tool' => 'woo_search_products', 'endpoint' => $execute_url ],
                    'detail' => [ 'tool' => 'woo_get_product',     'endpoint' => $execute_url ],
                ],
                'cart' => [
                    'get'    => [ 'tool' => 'woo_get_cart',         'endpoint' => $execute_url ],
                    'add'    => [ 'tool' => 'woo_add_to_cart',      'endpoint' => $execute_url ],
                    'remove' => [ 'tool' => 'woo_remove_from_cart', 'endpoint' => $execute_url ],
                ],
                'checkout' => [
                    'fields' => [ 'tool' => 'woo_get_checkout_fields', 'endpoint' => $execute_url ],
                    'coupon' => [ 'tool' => 'woo_apply_coupon',        'endpoint' => $execute_url ],
                ],
            ],
            'auth' => [
                'type'        => 'wordpress-nonce',
                'description' => 'Send a valid WP REST nonce in the X-WP-Nonce header for write operations.',
                'header'      => 'X-WP-Nonce',
                'nonce_url'   => rest_url( 'webmcp-bridge/v1/nonce' ),
            ],
            'store_info' => [
                'name'     => get_bloginfo( 'name' ),
                'url'      => home_url( '/' ),
                'currency' => function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : 'EUR',
            ],
        ];
    }

    // -------------------------------------------------------------------------
    // REST route: also expose manifest via /.well-known/ for RFC 9727 compat
    // -------------------------------------------------------------------------

    public function register_routes() {
        register_rest_route( 'webmcp-bridge/v1', '/discovery', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [ $this, 'rest_discovery' ],
            'permission_callback' => '__return_true',
        ] );

        // Nonce endpoint: agents can GET this to obtain a valid WP REST nonce
        // for use in the X-WP-Nonce header on protected tool calls.
        register_rest_route( 'webmcp-bridge/v1', '/nonce', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [ $this, 'rest_nonce' ],
            'permission_callback' => '__return_true',
        ] );
    }

    public function rest_nonce( WP_REST_Request $request ): WP_REST_Response {
        // Returns a fresh WP REST nonce valid for ~12 hours.
        // Agents use this to authenticate write operations (cart, forms, etc.)
        // by sending it as the X-WP-Nonce header.
        return rest_ensure_response( [
            'nonce'   => wp_create_nonce( 'wp_rest' ),
            'expires' => gmdate( 'Y-m-d\TH:i:s\Z', time() + ( 12 * HOUR_IN_SECONDS ) ),
            'header'  => 'X-WP-Nonce',
        ] );
    }

    public function rest_discovery( WP_REST_Request $request ): WP_REST_Response {
        $data = [
            'mcp_server_card' => home_url( '/.well-known/mcp/server-card.json' ),
            'api_catalog'     => home_url( '/.well-known/api-catalog' ),
            'agent_skills'    => home_url( '/.well-known/agent-skills/index.json' ),
            'manifest'        => rest_url( 'webmcp-bridge/v1/manifest' ),
            'execute'         => rest_url( 'webmcp-bridge/v1/execute' ),
            'nonce'           => rest_url( 'webmcp-bridge/v1/nonce' ),
        ];

        if ( class_exists( 'WooCommerce' ) ) {
            $data['commerce'] = [
                'oauth_server'     => home_url( '/.well-known/oauth-authorization-server' ),
                'oauth_resource'   => home_url( '/.well-known/oauth-protected-resource' ),
                'ucp'              => home_url( '/.well-known/ucp' ),
                'acp'              => home_url( '/.well-known/acp.json' ),
            ];
        }

        return rest_ensure_response( $data );
    }
}
