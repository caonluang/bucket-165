<?php

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Central registry for all WebMCP tools.
 */
class WebMCP_Bridge_Tool_Registry {

    private static $instance = null;
    private $tools = [];

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Register a tool.
     *
     * @param string $name       Unique tool name (snake_case).
     * @param array  $definition {
     *   @type string   $description  Human-readable description.
     *   @type array    $inputSchema  JSON-Schema-like array describing parameters.
     *   @type callable $callback     Function( array $params ) : mixed
     *   @type string   $group        Optional group (core|woocommerce|custom).
     * }
     */
    public function register( $name, array $definition ) {
        if ( isset( $this->tools[ $name ] ) ) {
            // Allow overriding via filter
            $this->tools[ $name ] = apply_filters( "webmcp_bridge_tool_{$name}", $definition );
            return;
        }
        $this->tools[ $name ] = apply_filters( "webmcp_bridge_tool_{$name}", $definition );
    }

    /** Return all registered tools. */
    public function get_all() {
        return $this->tools;
    }

    /** Return a single tool definition or null. */
    public function get( $name ) {
        return $this->tools[ $name ] ?? null;
    }

    /**
     * Execute a tool by name.
     *
     * @param string $name
     * @param array  $params
     * @return array { success: bool, data: mixed, error: string }
     */
    public function execute( $name, array $params = [] ) {
        $tool = $this->get( $name );
        if ( ! $tool ) {
            return [ 'success' => false, 'error' => "Tool '{$name}' not found." ];
        }

        try {
            $result = call_user_func( $tool['callback'], $params );
            return [ 'success' => true, 'data' => $result ];
        } catch ( Throwable $e ) {
            return [ 'success' => false, 'error' => $e->getMessage() ];
        }
    }

    /** Build the WebMCP-compatible tool manifest (JSON). */
    public function get_manifest() {
        $manifest = [];
        foreach ( $this->tools as $name => $tool ) {
            $manifest[] = [
                'name'        => $name,
                'description' => $tool['description'] ?? '',
                'inputSchema' => $tool['inputSchema'] ?? [ 'type' => 'object', 'properties' => [] ],
                'group'       => $tool['group'] ?? 'custom',
            ];
        }
        return $manifest;
    }
}
