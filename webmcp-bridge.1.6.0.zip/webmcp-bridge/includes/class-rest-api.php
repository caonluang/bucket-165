<?php
/**
 * REST API: exposes the manifest, tool schema, and tool execution endpoint.
 *
 * Permission model:
 *   /manifest         — intentionally public: AI agents discover tools without auth (WebMCP protocol).
 *   /tools/{name}     — intentionally public: schema only, no data, mirrors the manifest.
 *   /execute          — mixed: public tools are open; write/sensitive tools require a valid WP nonce
 *                       or an authenticated session. See check_execute_permission() for full logic.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class WebMCP_Bridge_REST_API {

    private $registry;
    const NAMESPACE = 'webmcp-bridge/v1';

    /**
     * Global rate limit for /execute endpoint.
     *
     * Why global and not per-IP?
     * Per-IP limits are trivially bypassed with proxy rotation.
     * A global counter limits the total server load regardless of source.
     * The window and limit are filterable for sites with different needs.
     *
     * Defaults: 120 execute calls per 60 seconds across ALL visitors.
     * Adjust via filters: webmcp_bridge_rate_limit and webmcp_bridge_rate_window.
     */
    private function check_global_rate_limit(): bool {
        $opts   = get_option( 'webmcp_bridge_options', [] );
        $limit  = (int) apply_filters( 'webmcp_bridge_rate_limit',  $opts['rate_limit']  ?? 120 ); // max calls
        $window = (int) apply_filters( 'webmcp_bridge_rate_window', $opts['rate_window'] ?? 60  ); // seconds
        $key    = 'webmcp_bridge_rate_' . gmdate( 'YmdHi' ) . '_' . (int) floor( gmdate( 's' ) / $window );

        $count = (int) get_transient( $key );
        if ( $count >= $limit ) {
            return false; // rate limit exceeded
        }

        // Increment atomically via transient (best-effort — not a strict semaphore,
        // but sufficient to throttle aggressive automated traffic)
        set_transient( $key, $count + 1, $window * 2 );
        return true;
    }

    /**
     * Tools that require a logged-in user or a valid WP REST nonce to execute.
     * Filterable via webmcp_bridge_protected_tools so other plugins can extend the list.
     */
    private function get_protected_tools(): array {
        return (array) apply_filters( 'webmcp_bridge_protected_tools', [
            'woo_add_to_cart',
            'woo_remove_from_cart',
            'woo_apply_coupon',
            'woo_get_cart',
            'woo_get_checkout_fields',
            'submit_contact_form',
        ] );
    }

    public function __construct( WebMCP_Bridge_Tool_Registry $registry ) {
        $this->registry = $registry;
    }

    public function init() {
        add_action( 'rest_api_init', [ $this, 'register_routes' ] );
    }

    public function register_routes() {

        // Public: AI agents must be able to fetch the manifest without authentication.
        // This is by design in the WebMCP protocol — discovery is always unauthenticated.
        register_rest_route( self::NAMESPACE, '/manifest', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [ $this, 'get_manifest' ],
            'permission_callback' => '__return_true',
        ] );

        // Mixed: read-only tools are public; write/sensitive tools require a WP nonce or login.
        // The distinction is made inside check_execute_permission() per-tool.
        register_rest_route( self::NAMESPACE, '/execute', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [ $this, 'execute_tool' ],
            'permission_callback' => [ $this, 'check_execute_permission' ],
            'args'                => [
                'tool'   => [ 'required' => true,  'type' => 'string',  'sanitize_callback' => 'sanitize_key' ],
                'params' => [ 'required' => false, 'type' => 'object', 'default' => [] ],
            ],
        ] );

        // Public: returns the schema (description + inputSchema) for a single tool.
        // Contains no user data — equivalent to a public API reference doc.
        register_rest_route( self::NAMESPACE, '/tools/(?P<tool>[a-zA-Z0-9_]+)', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [ $this, 'get_tool' ],
            'permission_callback' => '__return_true',
        ] );
    }

    // -------------------------------------------------------------------------

    public function get_manifest( WP_REST_Request $request ) {
        $options = get_option( 'webmcp_bridge_options', [] );
        if ( empty( $options['enabled'] ) ) {
            return new WP_Error( 'disabled', 'WebMCP Bridge is disabled.', [ 'status' => 403 ] );
        }

        $manifest = array_values( array_filter(
            $this->registry->get_manifest(),
            fn( $tool ) => $this->is_tool_enabled( $tool['name'] ?? '' )
        ) );

        return rest_ensure_response( [
            'site'              => get_bloginfo( 'name' ),
            'site_url'          => home_url( '/' ),
            'version'           => WEBMCP_BRIDGE_VERSION,
            'mescio_for_agents' => class_exists( 'Mescio_For_Agents' ),
            'tools'             => $manifest,
        ] );
    }

    public function get_tool( WP_REST_Request $request ) {
        $tool_name = sanitize_key( $request['tool'] );
        $tool      = $this->registry->get( $tool_name );

        if ( ! $tool ) {
            return new WP_Error( 'not_found', 'Tool not found.', [ 'status' => 404 ] );
        }
        if ( ! $this->is_tool_enabled( $tool_name ) ) {
            return new WP_Error( 'disabled', 'Tool is disabled by plugin settings.', [ 'status' => 403 ] );
        }

        return rest_ensure_response( $tool );
    }

    public function execute_tool( WP_REST_Request $request ) {
        // Global rate limit — checked before any processing.
        if ( ! $this->check_global_rate_limit() ) {
            return new WP_Error(
                'rate_limited',
                'Too many requests. Please slow down.',
                [ 'status' => 429 ]
            );
        }

        // Tool name is already sanitized by the 'sanitize_callback' arg above.
        $tool_name = $request->get_param( 'tool' );

        // is_tool_enabled() is checked here too (not just in permission_callback)
        // because the permission layer only runs once and we want a clear error response.
        if ( ! $this->is_tool_enabled( $tool_name ) ) {
            return new WP_Error( 'disabled', 'Tool is disabled by plugin settings.', [ 'status' => 403 ] );
        }

        $params = (array) $request->get_param( 'params' );
        $result = $this->registry->execute( $tool_name, $params );

        if ( ! $result['success'] ) {
            return new WP_Error( 'tool_error', $result['error'], [ 'status' => 400 ] );
        }

        return rest_ensure_response( $result['data'] );
    }

    /**
     * Permission callback for /execute.
     *
     * Logic:
     *   1. Plugin must be enabled globally.
     *   2. The requested tool must be enabled in settings.
     *   3. Read-only tools (search, get_post, etc.) are public — no auth needed.
     *   4. Write/sensitive tools (cart, forms) require either:
     *      a) A logged-in WordPress session, OR
     *      b) A valid WP REST API nonce (X-WP-Nonce header) — used by the admin live runner.
     */
    public function check_execute_permission( WP_REST_Request $request ): bool {
        $options = get_option( 'webmcp_bridge_options', [] );
        if ( empty( $options['enabled'] ) ) {
            return false;
        }

        $tool_name = sanitize_key( $request->get_param( 'tool' ) );
        if ( ! $this->is_tool_enabled( $tool_name ) ) {
            return false;
        }

        // Protected tools need an authenticated session or a valid nonce.
        if ( in_array( $tool_name, $this->get_protected_tools(), true ) ) {
            if ( is_user_logged_in() ) {
                return true;
            }
            $nonce = $request->get_header( 'X-WP-Nonce' );
            return $nonce && wp_verify_nonce( $nonce, 'wp_rest' );
        }

        // All other tools are intentionally public (read-only data).
        return true;
    }

    /**
     * Check whether a tool is enabled based on current plugin settings.
     */
    private function is_tool_enabled( string $tool_name ): bool {
        $tool = $this->registry->get( $tool_name );
        if ( ! $tool ) return false;

        $options = get_option( 'webmcp_bridge_options', [] );
        $group   = $tool['group'] ?? 'custom';

        switch ( $group ) {
            case 'woocommerce':
                return ! empty( $options['enable_woo'] ) && class_exists( 'WooCommerce' );
            case 'forms':
                return ! empty( $options['enable_forms'] );
            case 'navigation':
                return ! empty( $options['enable_nav'] );
            case 'content':
                return ! empty( $options['enable_search'] );
            case 'core':
                return ! empty( $options['enabled'] );
            default:
                return true; // custom tools: always enabled
        }
    }
}
