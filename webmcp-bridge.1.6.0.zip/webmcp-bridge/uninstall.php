<?php
/**
 * Fired when the plugin is deleted via wp-admin.
 */
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

delete_option( 'webmcp_bridge_options' );

if ( is_multisite() ) {
    global $wpdb;
    // phpcs:ignore WordPress.DB.DirectDatabaseQuery
    $webmcp_bridge_blog_ids = $wpdb->get_col( "SELECT blog_id FROM {$wpdb->blogs}" );
    foreach ( $webmcp_bridge_blog_ids as $webmcp_bridge_blog_id ) {
        switch_to_blog( (int) $webmcp_bridge_blog_id );
        delete_option( 'webmcp_bridge_options' );
        restore_current_blog();
    }
}
