=== WebMCP Bridge ===
Contributors: vinsmach
Tags: ai, mcp, webmcp, ai-agent, woocommerce
Requires at least: 6.0
Tested up to: 6.9
Stable tag: 1.6.0
Requires PHP: 8.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Make your WordPress site natively AI-agent friendly via the WebMCP protocol — no backend server required.

== Description ==

**WebMCP Bridge** exposes your WordPress (and WooCommerce) functionality as [WebMCP](https://github.com/webmcp/webmcp-spec) tools that AI agents can discover and invoke directly in the browser.

Once installed, your site automatically becomes "agent-friendly":

* AI agents can **search posts, pages, and custom post types**
* AI agents can **browse products, manage the cart, apply coupons** (WooCommerce)
* AI agents can **read navigation menus and site metadata**
* Developers can **register custom tools** in minutes via a simple PHP API

**What is WebMCP?**

WebMCP is a new browser-native protocol (currently in Chrome Early Preview) that lets web apps expose their functionality as structured "tools" that AI agents can invoke — without needing to screenshot or parse HTML. Think of your website as an MCP server running entirely client-side.

**How it works**

1. Install and activate the plugin
2. Enable the features you want from **Settings → WebMCP Bridge**
3. Your tool manifest is immediately available at `/wp-json/webmcp-bridge/v1/manifest`
4. AI agents (or any JavaScript code) can call your tools via REST API or the native browser WebMCP API

**Included tools**

*Core:*

* `search_posts` — Search posts, pages, or custom post types
* `get_post` — Retrieve a single post by ID or slug
* `get_menu` — Return navigation menu items
* `get_categories` — List taxonomy terms
* `get_site_info` — Site name, description, URL, language
* `submit_contact_form` — Contact Form 7 integration

*WooCommerce (requires WooCommerce plugin):*

* `woo_search_products` — Search by keyword, category, price range
* `woo_get_product` — Full product details including attributes
* `woo_add_to_cart` — Add a product to the cart
* `woo_get_cart` — Current cart contents and totals
* `woo_remove_from_cart` — Remove an item by cart key
* `woo_apply_coupon` — Apply a coupon code
* `woo_get_checkout_fields` — Return checkout field schema
* `woo_get_product_categories` — List all product categories

**Even more powerful with Mescio for Agents**

WebMCP Bridge integrates automatically with the **Mescio for Agents** plugin. When both plugins are active, two additional tools are unlocked:

* `get_markdown_content` — Returns any post or page as clean Markdown, the format AI models consume most efficiently. Instead of raw HTML, agents receive structured, token-optimized content ready for reasoning and summarization.
* `get_llms_txt` — Exposes the site-wide `llms.txt` context document (index or full variant), giving agents an instant, structured overview of what the site is about, who it is for, and what content is available — before they even start searching.

Together, the two plugins turn your WordPress site into a fully AI-native content source: WebMCP Bridge handles the tool layer (what agents can *do*), while Mescio for Agents handles the content layer (what agents can *read* and *understand*).

**Privacy**

This plugin does not collect, store, or transmit any user data to external servers. All tool execution happens locally within your WordPress installation. No telemetry, no phone-home, no external API calls.

== Installation ==

1. Upload the `webmcp-bridge` folder to `/wp-content/plugins/`
2. Activate the plugin via **Plugins → Installed Plugins**
3. Go to **Settings → WebMCP Bridge** and enable the features you want

= Minimum Requirements =

* WordPress 6.0 or higher
* PHP 8.0 or higher
* WooCommerce 7.0+ (optional, only required for WooCommerce tools)
* Contact Form 7 (optional, only required for form tools)
* Mescio for Agents (optional, unlocks `get_markdown_content` and `get_llms_txt`)

== Frequently Asked Questions ==

= Do I need Chrome for this to work? =

No. The REST API endpoints work in every browser and environment. The native WebMCP browser registration is only available in Chrome Early Preview (experimental), but the fallback JavaScript API (`window.webmcpBridgeTools`) and REST endpoints work everywhere.

= Is this secure? =

Yes. Read-only tools (search, get post, etc.) are publicly accessible by default, matching WordPress's own REST API behaviour. Write-action tools (add to cart, apply coupon, submit form) require a valid WordPress nonce. You can customise which tools require authentication via the `webmcp_bridge_protected_tools` filter.

= Does it work with WooCommerce? =

Yes. WooCommerce tools are automatically registered when WooCommerce is active and the WooCommerce option is enabled in settings.

= What does Mescio for Agents add? =

When Mescio for Agents is active alongside WebMCP Bridge, two extra tools become available in the manifest: `get_markdown_content` (AI-optimized content format) and `get_llms_txt` (site-wide context document). These are detected automatically — no configuration needed.

= Can I add my own tools? =

Absolutely. Use the PHP API:

`
add_action( 'plugins_loaded', function() {
    if ( ! class_exists( 'WebMCP_Bridge_Tool_Registry' ) ) return;
    $registry = WebMCP_Bridge_Tool_Registry::instance();
    $registry->register( 'my_tool', [
        'description' => 'Does something useful.',
        'group'       => 'custom',
        'inputSchema' => [ 'type' => 'object', 'properties' => [] ],
        'callback'    => function( $params ) { return [ 'ok' => true ]; },
    ] );
} );
`

= Where is the manifest URL? =

`https://your-site.com/wp-json/webmcp-bridge/v1/manifest`

You can also find it on the **Settings → WebMCP Bridge** page with a one-click copy button.

= Does this plugin collect any data? =

No. WebMCP Bridge does not collect, store, or send any data to external servers. See the Privacy section above.

== Screenshots ==

1. Settings page — enable/disable tool groups and copy the manifest URL
2. Registered tools list — all available tools with their group and description
3. Developer API — example of adding a custom tool from your theme

== Changelog ==

= 1.6.0 =
* JS: migrated browser registration to navigator.modelContext.provideContext() per current WebMCP spec; legacy ai.tools.register() kept as fallback
* JS: corrected tool field from parameters to inputSchema (WebMCP/Anthropic spec)
* Discovery: added service-desc and service-doc Link relations alongside api-catalog and webmcp-manifest
* Discovery: OAuth authorization-server and oauth-protected-resource now served on all sites (not WooCommerce-only) — explains WordPress nonce auth to agents
* Discovery: <link> HTML tags updated to include service-desc and service-doc

= 1.5.0 =
* Added WooCommerce commerce agent discovery (active only when WooCommerce is installed):
  - OAuth Authorization Server metadata at /.well-known/oauth-authorization-server (RFC 8414)
  - OAuth Protected Resource metadata at /.well-known/oauth-protected-resource (RFC 9728)
  - Universal Commerce Protocol profile at /.well-known/ucp (ucp.dev)
  - Agentic Commerce Protocol discovery at /.well-known/acp.json (agenticcommerce.dev)
* Added /wp-json/webmcp-bridge/v1/nonce endpoint — agents can fetch a fresh WP REST nonce for authenticated tool calls
* Discovery endpoint now includes commerce URLs when WooCommerce is active

= 1.4.4 =
* Added Content-Signal directives to robots.txt (contentsignals.org): ai-train=yes, search=yes, ai-input=yes — filterable via webmcp_bridge_content_signals hook
* Added Vary: Accept header so nginx/CDN caches correctly serve Markdown for Agents requests separately from HTML responses

= 1.4.3 =
* Fixed RFC 8288 Link discovery for cached sites: added <link> tags in HTML <head> via wp_head
* Link tags are part of the cached HTML so agents find them even when nginx serves cached pages without running PHP
* HTTP Link headers still added via wp_headers as secondary channel on cache misses

= 1.4.2 =
* Fixed RFC 8288 Link headers: switched from send_headers action to wp_headers filter for reliable delivery through nginx/cache layers
* Link headers now added to all pages (not just homepage) so agents can discover the API from any entry point

= 1.4.1 =
* Fixed Agent Skills index: added sha256 digest field to each skill entry (required by v0.2.0 spec)

= 1.4.0 =
* Added RFC 8288 Link response headers on homepage: advertises manifest, API catalog and MCP Server Card to agents
* Added /.well-known/mcp/server-card.json (SEP-1649): MCP Server Card for agent discovery
* Added /.well-known/api-catalog (RFC 9727): machine-readable API catalog including WebMCP and Mescio endpoints
* Added /.well-known/agent-skills/index.json: Agent Skills discovery index listing all site capabilities
* Added /wp-json/webmcp-bridge/v1/discovery: convenience endpoint listing all discovery URLs
* All well-known endpoints include Mescio for Agents data automatically when plugin is active

= 1.3.2 =
* Fixed PHP syntax error in sanitize_markdown() regex (inline event handler pattern)
* All PHP files pass WordPress.org pre-commit syntax check

= 1.3.1 =
* Security: sanitize Markdown output in get_markdown_content and get_llms_txt — prevents stored XSS and prompt injection via post content
* Removed admin_email from get_site_info response — not needed by agents, sensitive data
* Removed author display_name from get_post response — exposes internal WordPress usernames
* Added global rate limiting on /execute endpoint (default: 120 calls/60s, configurable in settings)
* Rate limit is global (not per-IP) — effective against proxy rotation attacks; returns HTTP 429

= 1.3.0 =
* Removed admin_email from get_site_info — sensitive data not needed by agents
* Removed author field from get_post — avoids exposing internal WordPress usernames
* Added global rate limiting on /execute: configurable max calls per time window in settings
* Rate limit counter uses WP transients; returns HTTP 429 when exceeded
* Rate limit and window now editable from Settings → WebMCP Bridge

= 1.2.0 =
* Added Live API Examples section in admin: test every tool directly from the settings page
* curl and JavaScript snippets auto-generated for each tool with real site URL
* Added Mescio for Agents examples (llms.txt, get_markdown_content) when plugin is active
* Admin JS extracted to separate file for better caching and CSP compatibility
* Added full Italian translation (it_IT) — .po, .mo and .pot files included
* Admin UI: tab navigation for examples, live JSON output viewer


= 1.1.0 =
* Added integration with Mescio for Agents plugin: when active, unlocks `get_markdown_content` and `get_llms_txt` tools
* Manifest now filters tools based on enabled settings — disabled groups no longer appear
* Added `site_url` and `mescio_for_agents` fields to manifest response
* Tool groups refactored: core split into `content`, `navigation`, `forms` for finer control
* Improved error handling: registry now catches all `Throwable` (not just `Exception`)
* Fixed `wp_remote_get` in llms-full.txt fetch: proper timeout, user-agent, SSL filter
* Fixed: tools disabled in settings were still executable via REST — now correctly blocked

= 1.0.1 =
* Added automatic compatibility with Autoptimize, WP Rocket, LiteSpeed Cache, W3 Total Cache, SG Optimizer
* Fixed duplicate textdomain and deactivation hooks
* Added ABSPATH protection to all PHP files
* Fixed output escaping in exception messages

= 1.0.0 =
* Initial release
* Core tools: search_posts, get_post, get_menu, get_categories, get_site_info, submit_contact_form
* WooCommerce tools: product search, cart management, coupon, checkout fields
* REST API manifest and execution endpoints
* JavaScript frontend bridge with WebMCP browser API support and fallback
* Admin settings page

== Upgrade Notice ==

= 1.3.2 =
Security and stability patch. Sanitizes Markdown output to prevent prompt injection, removes sensitive data from responses, adds rate limiting. Recommended update for all users.

= 1.1.0 =
Adds Mescio for Agents integration and fixes tool filtering in the manifest. Recommended update for all users.
