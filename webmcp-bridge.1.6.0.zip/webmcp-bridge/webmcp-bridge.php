<?php
/**
 * Plugin Name:       WebMCP Bridge
 * Plugin URI:        https://wordpress.org/plugins/webmcp-bridge/
 * Description:       Exposes WordPress functionality as WebMCP tools so AI agents can interact with your site natively in the browser — no backend MCP server required.
 * Version:           1.6.0
 * Requires at least: 6.0
 * Requires PHP:      8.0
 * Author:            Mescio
 * Author URI:        https://mescio.it/
 * License:           GPL-2.0+
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       webmcp-bridge
 * Domain Path:       /languages
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'WEBMCP_BRIDGE_VERSION', '1.6.0' );
define( 'WEBMCP_BRIDGE_DIR', plugin_dir_path( __FILE__ ) );
define( 'WEBMCP_BRIDGE_URL', plugin_dir_url( __FILE__ ) );

// Load includes
require_once WEBMCP_BRIDGE_DIR . 'includes/class-tool-registry.php';
require_once WEBMCP_BRIDGE_DIR . 'includes/class-tools-core.php';
require_once WEBMCP_BRIDGE_DIR . 'includes/class-tools-woocommerce.php';
require_once WEBMCP_BRIDGE_DIR . 'includes/class-rest-api.php';
require_once WEBMCP_BRIDGE_DIR . 'admin/class-admin.php';
require_once WEBMCP_BRIDGE_DIR . 'includes/class-discovery.php';

/**
 * Bootstrap the plugin.
 */
function webmcp_bridge_init() {
    $registry = WebMCP_Bridge_Tool_Registry::instance();

    // Always register core tools
    $core = new WebMCP_Bridge_Tools_Core( $registry );
    $core->register();

    // Register WooCommerce tools only if WC is active
    if ( class_exists( 'WooCommerce' ) ) {
        $woo = new WebMCP_Bridge_Tools_WooCommerce( $registry );
        $woo->register();
    }

    // Boot REST API
    $rest = new WebMCP_Bridge_REST_API( $registry );
    $rest->init();

    // Boot agent discovery (Link headers, well-known endpoints)
    $discovery = new WebMCP_Bridge_Discovery();
    $discovery->init();

    // Boot admin
    if ( is_admin() ) {
        $admin = new WebMCP_Bridge_Admin( $registry );
        $admin->init();
    }

    // Enqueue frontend JS
    add_action( 'wp_enqueue_scripts', 'webmcp_bridge_enqueue_frontend' );
}
add_action( 'plugins_loaded', 'webmcp_bridge_init' );

function webmcp_bridge_enqueue_frontend() {
    $options = get_option( 'webmcp_bridge_options', [] );
    if ( empty( $options['enabled'] ) ) return;

    wp_enqueue_script(
        'webmcp-bridge',
        WEBMCP_BRIDGE_URL . 'assets/js/webmcp.js',
        [],
        WEBMCP_BRIDGE_VERSION,
        true
    );

    // Mark script as async-safe and add data-* attributes for optimizer exclusion
    add_filter( 'script_loader_tag', 'webmcp_bridge_script_tag', 10, 2 );

    wp_localize_script( 'webmcp-bridge', 'webmcpBridge', [
        'restUrl'   => esc_url_raw( rest_url( 'webmcp-bridge/v1' ) ),
        'nonce'     => wp_create_nonce( 'wp_rest' ),
        'siteTitle' => get_bloginfo( 'name' ),
        'options'   => [
            'enableSearch' => ! empty( $options['enable_search'] ),
            'enableForms'  => ! empty( $options['enable_forms'] ),
            'enableWoo'    => ! empty( $options['enable_woo'] ) && class_exists( 'WooCommerce' ),
            'enableNav'    => ! empty( $options['enable_nav'] ),
        ],
    ] );
}

/**
 * Add data-no-optimize attributes so cache/minify plugins leave this script alone.
 * Supports: Autoptimize, WP Rocket, LiteSpeed Cache, W3 Total Cache, SG Optimizer.
 */
function webmcp_bridge_script_tag( $tag, $handle ) {
    if ( 'webmcp-bridge' !== $handle ) return $tag;

    // These data attributes are recognized by the major optimizer plugins
    $tag = str_replace(
        '<script ',
        '<script data-no-optimize="1" data-no-defer="1" data-cfasync="false" ',
        $tag
    );
    return $tag;
}

/**
 * Autoptimize: exclude webmcp.js from JS aggregation.
 * Filter: autoptimize_filter_js_exclude
 */
add_filter( 'autoptimize_filter_js_exclude', function( $excluded ) {
    return $excluded . ', webmcp.js';
} );

/**
 * WP Rocket: exclude from JS minification/concatenation.
 */
add_filter( 'rocket_exclude_js', function( $excluded ) {
    $excluded[] = '/wp-content/plugins/webmcp-bridge/assets/js/webmcp.js';
    return $excluded;
} );

add_filter( 'rocket_exclude_defer_js', function( $excluded ) {
    $excluded[] = '/wp-content/plugins/webmcp-bridge/assets/js/webmcp.js';
    return $excluded;
} );

/**
 * LiteSpeed Cache: exclude from JS optimization.
 */
add_filter( 'litespeed_optimize_js_excludes', function( $excluded ) {
    $excluded[] = 'webmcp.js';
    return $excluded;
} );

/**
 * W3 Total Cache: exclude from minification.
 */
add_filter( 'w3tc_minify_js_do_tag_minification', function( $do, $script_tag ) {
    if ( false !== strpos( $script_tag, 'webmcp.js' ) ) return false;
    return $do;
}, 10, 2 );

/**
 * SG Optimizer (SiteGround): exclude from JS combination.
 */
add_filter( 'sgo_js_combine_exclude', function( $excluded ) {
    $excluded[] = 'webmcp.js';
    return $excluded;
} );

add_filter( 'sgo_javascript_combine_exclude', function( $excluded ) {
    $excluded[] = 'webmcp-bridge';
    return $excluded;
} );

// i18n — WordPress.org loads translations automatically since WP 4.6

// Privacy policy declaration (GDPR)
function webmcp_bridge_privacy_policy_content() {
    if ( ! function_exists( 'wp_add_privacy_policy_content' ) ) return;
    $content = '<p>' . esc_html__( 'WebMCP Bridge does not collect, store, or transmit any personal data to external servers. All tool execution happens locally within your WordPress installation. No telemetry, analytics, or tracking of any kind is performed.', 'webmcp-bridge' ) . '</p>';
    wp_add_privacy_policy_content( 'WebMCP Bridge', wp_kses_post( $content ) );
}
add_action( 'admin_init', 'webmcp_bridge_privacy_policy_content' );

// Activation hook
register_activation_hook( __FILE__, function() {
    add_option( 'webmcp_bridge_options', [
        'enabled'       => 1,
        'enable_search' => 1,
        'enable_forms'  => 1,
        'enable_woo'    => 1,
        'enable_nav'    => 1,
    ] );
} );

// Deactivation — preserve settings intentionally
register_deactivation_hook( __FILE__, '__return_null' );
// Note: cleanup on deletion is handled by uninstall.php

