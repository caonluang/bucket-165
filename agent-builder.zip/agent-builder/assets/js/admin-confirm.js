/**
 * Reusable accessible confirm dialog for Agent Builder admin (replaces alert/confirm for U1 compliance).
 * Uses existing .agentic-dialog-overlay / .agentic-dialog-box CSS from admin.css.
 * Provides agenticConfirm( message, onConfirm, onCancel? )
 */
(function() {
	'use strict';

	let dialogEl = null;

	function ensureDialog() {
		if ( dialogEl ) return dialogEl;

		dialogEl = document.createElement( 'div' );
		dialogEl.id = 'agentic-confirm-dialog';
		dialogEl.className = 'agentic-dialog-overlay';
		dialogEl.setAttribute( 'role', 'alertdialog' );
		dialogEl.setAttribute( 'aria-modal', 'true' );
		dialogEl.innerHTML = `
			<div class="agentic-dialog-box" style="max-width: 420px;">
				<h2 id="agentic-confirm-title" style="margin-top:0; font-size:1.1em;"></h2>
				<p id="agentic-confirm-message" style="margin: 0.5em 0 1em;"></p>
				<div style="text-align: right;">
					<button type="button" class="button" id="agentic-confirm-cancel">Cancel</button>
					<button type="button" class="button button-primary" id="agentic-confirm-ok" style="margin-left: 8px;">OK</button>
				</div>
			</div>
		`;
		document.body.appendChild( dialogEl );

		// Close on overlay click
		dialogEl.addEventListener( 'click', function( e ) {
			if ( e.target === dialogEl ) {
				hideDialog();
				if ( dialogEl._onCancel ) dialogEl._onCancel();
			}
		});

		// Keyboard escape
		document.addEventListener( 'keydown', function( e ) {
			if ( e.key === 'Escape' && dialogEl.classList.contains( 'active' ) ) {
				hideDialog();
				if ( dialogEl._onCancel ) dialogEl._onCancel();
			}
		});

		return dialogEl;
	}

	function showDialog( message, onConfirm, onCancel ) {
		const d = ensureDialog();
		d._onConfirm = onConfirm;
		d._onCancel = onCancel || null;

		const titleEl = d.querySelector( '#agentic-confirm-title' );
		const msgEl = d.querySelector( '#agentic-confirm-message' );
		const okBtn = d.querySelector( '#agentic-confirm-ok' );
		const cancelBtn = d.querySelector( '#agentic-confirm-cancel' );

		titleEl.textContent = 'Confirm';
		msgEl.textContent = message || 'Are you sure?';

		// Clone buttons to remove old listeners
		const newOk = okBtn.cloneNode( true );
		okBtn.parentNode.replaceChild( newOk, okBtn );
		const newCancel = cancelBtn.cloneNode( true );
		cancelBtn.parentNode.replaceChild( newCancel, cancelBtn );

		newOk.addEventListener( 'click', function() {
			hideDialog();
			if ( d._onConfirm ) d._onConfirm();
		});

		newCancel.addEventListener( 'click', function() {
			hideDialog();
			if ( d._onCancel ) d._onCancel();
		});

		d.classList.add( 'active' );
		// Focus OK for accessibility
		setTimeout( function() { newOk.focus(); }, 10 );
	}

	function hideDialog() {
		if ( dialogEl ) {
			dialogEl.classList.remove( 'active' );
		}
	}

	// Global API
	window.agenticConfirm = function( message, onConfirm, onCancel ) {
		showDialog( message, onConfirm, onCancel );
		return false; // for onclick="return agenticConfirm(...)"
	};

	// Also expose for inline use
	window.agenticAlert = function( message ) {
		// Simple alert replacement using the dialog (single OK)
		window.agenticConfirm( message, function(){}, null );
	};

	// For bulk etc, support returning promise optionally, but sync callback for now.

	// Auto-bind any [data-confirm] elements (links or buttons) for progressive enhancement.
	// Usage: <a href="delete-url" data-confirm="Are you sure you want to delete this?">Delete</a>
	function bindDataConfirms() {
		document.addEventListener( 'click', function( e ) {
			const el = e.target.closest( '[data-confirm]' );
			if ( ! el ) return;

			const msg = el.getAttribute( 'data-confirm' ) || 'Are you sure?';
			// If it's a link or submit, prevent default until confirmed.
			if ( el.tagName === 'A' || el.tagName === 'BUTTON' || el.type === 'submit' ) {
				e.preventDefault();
				window.agenticConfirm( msg, function() {
					// Proceed with original action
					if ( el.tagName === 'A' && el.href ) {
						window.location.href = el.href;
					} else if ( el.form ) {
						el.form.submit();
					} else {
						el.click(); // fallback for other buttons
					}
				} );
			}
		}, true ); // capture
	}

	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', bindDataConfirms );
	} else {
		bindDataConfirms();
	}
})();
