<?php
/**
 * Plugin activation handler.
 *
 * Everything that runs on register_activation_hook.
 *
 * @package Agent_Builder
 * @since   2.3.0
 */

declare(strict_types=1);

namespace Agentic;

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Activator
 *
 * @since 2.3.0
 */
final class Activator {

	/**
	 * Structured log collected throughout activation.
	 * Written to the audit log and to agentic_last_activation_log at the end.
	 *
	 * @var array<int, array{step: string, status: string, details: mixed}>
	 */
	private static array $activation_log = array();

	/**
	 * Append one step to the in-memory activation log.
	 * Errors are also sent to error_log() immediately for PHP debug log visibility.
	 *
	 * @param string $step    Short identifier for the step, e.g. 'create_table'.
	 * @param string $status  'ok', 'skipped', 'warning', or 'error'.
	 * @param mixed  $details Any serialisable value (string, array, etc.).
	 */
	private static function record( string $step, string $status, mixed $details = null ): void {
		self::$activation_log[] = array(
			'step'    => $step,
			'status'  => $status,
			'details' => $details,
			'time'    => gmdate( 'Y-m-d H:i:s' ),
		);

		if ( in_array( $status, array( 'error', 'warning' ), true ) ) {
			// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- Intentional activation debug output.
			error_log( '[Agent Builder activation] ' . $step . ' [' . $status . ']: ' . ( is_string( $details ) ? $details : wp_json_encode( $details ) ) );
		}
	}

	/**
	 * Run all activation tasks.
	 *
	 * @param string $schema_version Current DB_SCHEMA_VERSION from Plugin class.
	 * @return void
	 */
	public static function activate( string $schema_version ): void {
		// Reset collector so repeated activations don't accumulate across requests.
		self::$activation_log = array();

		self::record(
			'activate_start',
			'ok',
			array(
				'schema_version' => $schema_version,
				'wp_version'     => get_bloginfo( 'version' ),
				'php_version'    => PHP_VERSION,
				'fresh_install'  => ( false === get_option( 'agentic_db_schema_version' ) ),
			)
		);

		$fresh_install = ( false === get_option( 'agentic_db_schema_version' ) );

		self::set_flags();
		self::create_tables();  // Security-log table is created here — safe to log after this point.
		self::set_default_options();
		self::activate_bundled_agents();
		self::seed_tools( $schema_version );
		self::seed_skills( $schema_version );
		self::schedule_cron_events();
		self::run_migrations();

		flush_rewrite_rules();

		// Mark schema as current so migrations don't run redundantly.
		update_option( 'agentic_db_schema_version', $schema_version );

		// Persist the full activation log to an option (readable even if tables failed).
		update_option(
			'agentic_last_activation_log',
			array(
				'schema_version' => $schema_version,
				'activated_at'   => gmdate( 'Y-m-d H:i:s' ),
				'steps'          => self::$activation_log,
			)
		);

		// Security log is now available — record the activation event.
		\Agentic\Security_Log::log_system(
			'plugin_activated',
			'agent-builder',
			array(
				'version'        => AGENT_BUILDER_VERSION,
				'schema_version' => $schema_version,
				'fresh_install'  => $fresh_install,
				'wp_version'     => get_bloginfo( 'version' ),
				'php_version'    => PHP_VERSION,
			)
		);
	}

	/**
	 * Run activation tasks only when the stored schema version is behind.
	 *
	 * Called on every request via Plugin::init() so post-update schema changes
	 * are applied without requiring a manual re-activation.
	 *
	 * @param string $schema_version Current DB_SCHEMA_VERSION from Plugin class.
	 * @return void
	 */
	public static function maybe_upgrade( string $schema_version ): void {
		$current = get_option( 'agentic_db_schema_version', '0.0.0' );

		if ( version_compare( $current, $schema_version, '>=' ) ) {
			return;
		}

		$from_version = $current;

		// Log that the upgrade is beginning before running activate(), which
		// can fail mid-way (e.g. dbDelta error). If support sees only this entry
		// with no plugin_upgraded entry after it, they know activate() failed.
		\Agentic\Security_Log::log_system(
			'plugin_upgrade_started',
			'agent-builder',
			array(
				'from_version'   => $from_version,
				'to_version'     => AGENT_BUILDER_VERSION,
				'schema_version' => $schema_version,
			)
		);

		// Re-run the activator to ensure all tables exist with the latest schema.
		self::activate( $schema_version );

		// Log the upgrade separately so support can identify version transitions.
		\Agentic\Security_Log::log_system(
			'plugin_upgraded',
			'agent-builder',
			array(
				'from_version'   => $from_version,
				'to_version'     => AGENT_BUILDER_VERSION,
				'schema_version' => $schema_version,
			)
		);
	}

	/**
	 * Set one-time activation flags.
	 *
	 * @return void
	 */
	private static function set_flags(): void {
		// Welcome admin notice.
		add_option( 'agentic_show_welcome_notice', true );

		self::record(
			'set_flags',
			'ok',
			array(
				'agentic_show_welcome_notice' => 'added',
			)
		);
	}

	/**
	 * Set default plugin options (only if they don't already exist).
	 *
	 * @return void
	 */
	private static function set_default_options(): void {
		$results = array();

		// Read the default model from the provider table (single source of truth).
		$agentic_provider = \Agentic\Provider_Registry::get( 'agentic' );
		$default_model    = $agentic_provider['default_model'] ?? 'gemini-2.5-flash';

		$defaults = array(
			'agentic_agent_mode'              => 'supervised',
			'agentic_audit_enabled'           => true,
			'agentic_llm_provider'            => 'agentic',
			'agentic_model'                   => $default_model,
			// GDPR: default retention to 30 days so data is not kept indefinitely on fresh installs.
			'agentic_chat_tts'                => '1',
			'agentic_retention_conversations' => 30,
			'agentic_retention_audit_log'     => 30,
			\Agentic\Usage_Limits::OPTION_KEY => \Agentic\Usage_Limits::get_install_defaults(),
			// Gutenberg sidebar: enabled by default so new installs have it working out of the box.
			'agentic_editor_sidebar_settings' => array(
				'enabled'         => '1',
				'agent_slug'      => 'content-writer',
				'agent_slugs'     => array( 'content-writer', 'seo-assistant', 'wordpress-assistant' ),
				'post_types'      => array( 'post', 'page' ),
				'inject_context'  => '1',
				'agent_mode'      => 'autonomous',
				'toolbar_enabled' => '1',
			),
		);

		// Options that are large or only read on specific admin/editor screens
		// are not autoloaded on every request (performance).
		$no_autoload = array(
			'agentic_editor_sidebar_settings',
			'agentic_retention_conversations',
			'agentic_retention_audit_log',
			\Agentic\Usage_Limits::OPTION_KEY,
		);

		foreach ( $defaults as $key => $value ) {
			$autoload          = in_array( $key, $no_autoload, true ) ? 'no' : 'yes';
			$results[ $key ]   = add_option( $key, $value, '', $autoload ) ? 'added' : 'already_exists';
		}

		update_option( 'agentic_psi_shared_key_builtin', defined( 'AGENTIC_PSI_SHARED_KEY' ) ? AGENTIC_PSI_SHARED_KEY : '' );
		$results['agentic_psi_shared_key_builtin'] = 'updated';

		self::record( 'set_default_options', 'ok', $results );
	}

	/**
	 * Activate all bundled library agents.
	 *
	 * Scans the library directory and ensures every bundled agent
	 * is present in the agentic_active_agents option.
	 *
	 * @return void
	 */
	private static function activate_bundled_agents(): void {
		$library_dirs  = apply_filters( 'agentic_library_dirs', array( AGENT_BUILDER_DIR . 'library/agents' ) );
		$bundled_slugs = array();

		foreach ( $library_dirs as $library_dir ) {
			if ( ! is_dir( $library_dir ) ) {
				self::record( 'activate_bundled_agents', 'warning', 'library directory not found: ' . $library_dir );
				continue;
			}

			$folders = scandir( $library_dir );

			if ( ! is_array( $folders ) ) {
				self::record( 'activate_bundled_agents', 'error', 'scandir() failed on library directory: ' . $library_dir );
				continue;
			}

			foreach ( $folders as $folder ) {
				if ( '.' === $folder || '..' === $folder || 'README.md' === $folder ) {
					continue;
				}

				$agent_path = $library_dir . '/' . $folder;

				// Must be a directory with an agent.php file.
				if ( is_dir( $agent_path ) && file_exists( $agent_path . '/agent.php' ) ) {
					$bundled_slugs[] = $folder;
				}
			}
		}

		$bundled_slugs = array_unique( $bundled_slugs );

		if ( empty( $bundled_slugs ) ) {
			self::record( 'activate_bundled_agents', 'warning', 'no agent directories found in library' );
			return;
		}

		$active_agents = get_option( 'agentic_active_agents', array() );
		$merged        = array_unique( array_merge( $active_agents, $bundled_slugs ) );
		$newly_added   = array_diff( $bundled_slugs, $active_agents );

		update_option( 'agentic_active_agents', array_values( $merged ) );

		// Generate abilities.json integrity hashes for bundled agents.
		include_once AGENT_BUILDER_DIR . 'includes/class-abilities-manifest.php';
		$hash_results = array();
		foreach ( $bundled_slugs as $slug ) {
			$saved                 = Abilities_Manifest::save_integrity_hash( $slug );
			$hash_results[ $slug ] = $saved ? 'hash_saved' : 'hash_failed';
			if ( ! $saved ) {
				self::record( 'integrity_hash', 'warning', "save_integrity_hash() returned false for agent '$slug'" );
			}
		}

		self::record(
			'activate_bundled_agents',
			'ok',
			array(
				'found'        => $bundled_slugs,
				'newly_added'  => array_values( $newly_added ),
				'total_active' => count( $merged ),
				'hashes'       => $hash_results,
			)
		);
	}

	/**
	 * Create all custom database tables.
	 *
	 * @return void
	 */
	private static function create_tables(): void {
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();

		// Audit log table.
		$sql_audit = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}agentic_audit_log (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            agent_id varchar(64) NOT NULL,
            action varchar(128) NOT NULL,
            target_type varchar(64),
            target_id varchar(128),
            details longtext,
            reasoning text,
            mode varchar(32) DEFAULT '',
            provider varchar(64) DEFAULT '',
            tokens_used int unsigned DEFAULT 0,
            cost decimal(10,6) DEFAULT 0,
            user_id bigint(20) unsigned,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY agent_id (agent_id),
            KEY action (action),
            KEY created_at (created_at),
            KEY user_created (user_id, created_at)
        ) $charset_collate;";

		// Approval queue table.
		$sql_queue = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}agentic_approval_queue (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            agent_id varchar(64) NOT NULL,
            action varchar(128) NOT NULL,
            params longtext NOT NULL,
            reasoning text,
            risk_level varchar(32) DEFAULT 'none',
            status varchar(32) DEFAULT 'pending',
            approved_by bigint(20) unsigned,
            approved_at datetime,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            expires_at datetime,
            executed_at datetime DEFAULT NULL,
            mode varchar(32) DEFAULT '',
            invocation varchar(32) DEFAULT '',
            PRIMARY KEY (id),
            KEY status (status),
            KEY created_at (created_at)
        ) $charset_collate;";

		// Memory table.
		$sql_memory = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}agentic_memory (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            memory_type varchar(50) NOT NULL,
            entity_id varchar(100) NOT NULL,
            memory_key varchar(255) NOT NULL,
            memory_value longtext NOT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            expires_at datetime DEFAULT NULL,
            PRIMARY KEY (id),
            KEY memory_type_entity (memory_type, entity_id),
            KEY memory_type_created (memory_type, created_at),
            KEY memory_key (memory_key)
        ) $charset_collate;";

		// Tools registry table.
		$sql_tools = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}agentic_tools (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            name varchar(128) NOT NULL,
            description text NOT NULL,
            category varchar(64) NOT NULL DEFAULT 'WordPress',
            source varchar(64) NOT NULL DEFAULT 'core',
            enabled tinyint(1) NOT NULL DEFAULT 1,
            risk_level varchar(32) NOT NULL DEFAULT 'none',
            parameters longtext,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY name (name),
            KEY category (category),
            KEY source (source),
            KEY enabled (enabled)
        ) $charset_collate;";

		include_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$table_results = array();
		$table_errors  = array();

		// Helper to run dbDelta and capture any error.
		$run_delta = function ( string $name, string $sql ) use ( $wpdb, &$table_results, &$table_errors ): void {
			$wpdb->last_error       = '';
			$delta                  = dbDelta( $sql );
			$table_results[ $name ] = $delta;
			if ( $wpdb->last_error ) {
				$table_errors[ $name ] = $wpdb->last_error;
			}
		};

		$run_delta( 'agentic_audit_log', $sql_audit );
		$run_delta( 'agentic_approval_queue', $sql_queue );
		$run_delta( 'agentic_memory', $sql_memory );
		$run_delta( 'agentic_tools', $sql_tools );

		// Conversations table — stores each chat turn for efficient session browsing.
		$sql_conversations = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}agentic_conversations (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            session_id varchar(36) NOT NULL,
            user_id bigint(20) unsigned NOT NULL DEFAULT 0,
            agent_id varchar(64) NOT NULL DEFAULT '',
            role varchar(16) NOT NULL DEFAULT 'user',
            content longtext NOT NULL,
            tools_used text NOT NULL DEFAULT '',
            feedback tinyint(1) DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY session_user (session_id, user_id),
            KEY user_agent (user_id, agent_id),
            KEY created_at (created_at)
        ) $charset_collate;";
		$run_delta( 'agentic_conversations', $sql_conversations );

		// Agent settings table.
		$sql_agent_settings = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}agentic_agent_settings (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            agent_slug varchar(128) NOT NULL,
            meta_key varchar(128) NOT NULL,
            meta_value longtext NOT NULL DEFAULT '',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY agent_key (agent_slug, meta_key),
            KEY agent_slug (agent_slug),
            KEY meta_key (meta_key)
        ) $charset_collate;";
		$run_delta( 'agentic_agent_settings', $sql_agent_settings );

		// Providers table — stores LLM provider configuration and Agentic service endpoints.
		$sql_providers = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}agentic_providers (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            slug varchar(100) NOT NULL,
            name varchar(255) NOT NULL DEFAULT '',
            endpoint text NOT NULL DEFAULT '',
            default_model varchar(255) NOT NULL DEFAULT '',
            vision_model varchar(255) NOT NULL DEFAULT '',
            auth_type varchar(50) NOT NULL DEFAULT 'bearer',
            req_format varchar(50) NOT NULL DEFAULT 'openai',
            resp_format varchar(50) NOT NULL DEFAULT 'openai',
            requires_key tinyint(1) NOT NULL DEFAULT 1,
            api_key text NOT NULL DEFAULT '',
            key_url varchar(2048) NOT NULL DEFAULT '',
            icon text NOT NULL DEFAULT '',
            models longtext NOT NULL DEFAULT '[]',
            model_pricing longtext NOT NULL DEFAULT '{}',
            is_builtin tinyint(1) NOT NULL DEFAULT 0,
            sort_order int(11) NOT NULL DEFAULT 99,
            provider_type varchar(32) NOT NULL DEFAULT 'llm',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY slug (slug),
            KEY sort_order (sort_order),
            KEY provider_type (provider_type)
        ) $charset_collate;";
		$run_delta( 'agentic_providers', $sql_providers );

		// Skills table.
		$sql_skills = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}agentic_skills (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            name varchar(255) NOT NULL,
            slug varchar(255) NOT NULL,
            description text NOT NULL DEFAULT '',
            content longtext NOT NULL DEFAULT '',
            agent_slug varchar(128) NOT NULL DEFAULT '',
            source varchar(64) NOT NULL DEFAULT 'local',
            source_id varchar(255) NOT NULL DEFAULT '',
            version varchar(32) NOT NULL DEFAULT '1.0.0',
            author varchar(255) NOT NULL DEFAULT '',
            enabled tinyint(1) NOT NULL DEFAULT 1,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY slug (slug),
            KEY agent_slug (agent_slug),
            KEY source (source),
            KEY enabled (enabled)
        ) $charset_collate;";
		$run_delta( 'agentic_skills', $sql_skills );

		// Orchestration runs table — one row per top-level multi-agent (team) run.
		// Tracks delegation depth, fan-out, accumulated tokens/cost, and a small
		// JSON scratchpad shared across delegated agents within the run.
		$sql_runs = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}agentic_runs (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            run_id varchar(36) NOT NULL,
            root_agent varchar(64) NOT NULL DEFAULT '',
            status varchar(16) NOT NULL DEFAULT 'running',
            delegations int unsigned NOT NULL DEFAULT 0,
            max_depth smallint unsigned NOT NULL DEFAULT 0,
            tokens_used int unsigned NOT NULL DEFAULT 0,
            cost decimal(10,6) NOT NULL DEFAULT 0,
            state longtext,
            started_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            finished_at datetime DEFAULT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY run_id (run_id),
            KEY root_agent (root_agent),
            KEY status (status),
            KEY started_at (started_at)
        ) $charset_collate;";
		$run_delta( 'agentic_runs', $sql_runs );

		// Ensure Job_Manager, Security_Log, and Deployments are available (activation fires early).
		include_once AGENT_BUILDER_DIR . 'includes/class-job-manager.php';
		include_once AGENT_BUILDER_DIR . 'includes/class-security-log.php';
		include_once AGENT_BUILDER_DIR . 'includes/class-deployments.php';

		// Create jobs table.
		$wpdb->last_error = '';
		Job_Manager::create_table();
		if ( $wpdb->last_error ) {
			$table_errors['agentic_jobs'] = $wpdb->last_error;
		} else {
			$table_results['agentic_jobs'] = 'ok';
		}

		// Create security log table.
		$wpdb->last_error = '';
		Security_Log::create_table();
		if ( $wpdb->last_error ) {
			$table_errors['agentic_security_log'] = $wpdb->last_error;
		} else {
			$table_results['agentic_security_log'] = 'ok';
		}

		// Create deployments table.
		$wpdb->last_error = '';
		Deployments::create_table();
		if ( $wpdb->last_error ) {
			$table_errors['agentic_deployments'] = $wpdb->last_error;
		} else {
			$table_results['agentic_deployments'] = 'ok';
		}

		$status = empty( $table_errors ) ? 'ok' : 'warning';
		self::record(
			'create_tables',
			$status,
			array(
				'tables' => $table_results,
				'errors' => $table_errors,
			)
		);
	}

	/**
	 * Run one-time data migrations (idempotent — each migration checks its own flag).
	 */
	private static function run_migrations(): void {
		include_once AGENT_BUILDER_DIR . 'includes/class-deployments-migrator.php';
		Deployments_Migrator::run();

		self::migrate_agent_personas();
		self::migrate_agent_overrides();
	}

	/**
	 * Migrate legacy agentic_agent_personas wp_options data into the agent_settings table.
	 *
	 * Runs once; idempotency is guarded by the agentic_personas_migrated_v1 option.
	 *
	 * @return void
	 */
	private static function migrate_agent_personas(): void {
		if ( get_option( 'agentic_personas_migrated_v1' ) ) {
			self::record( 'migrate_agent_personas', 'skipped', 'already migrated' );
			return;
		}

		$personas = get_option( 'agentic_agent_personas', null );

		if ( ! is_array( $personas ) || empty( $personas ) ) {
			update_option( 'agentic_personas_migrated_v1', true );
			self::record( 'migrate_agent_personas', 'ok', 'no persona data to migrate' );
			return;
		}

		include_once AGENT_BUILDER_DIR . 'includes/class-agent-settings.php';

		$migrated = array();

		foreach ( $personas as $slug => $data ) {
			$slug = sanitize_key( (string) $slug );
			if ( empty( $slug ) || ! is_array( $data ) ) {
				continue;
			}

			$keys = array();

			if ( ! empty( $data['welcome_message'] ) ) {
				Agent_Settings::update( $slug, 'persona_welcome_message', (string) $data['welcome_message'] );
				$keys[] = 'welcome_message';
			}
			if ( ! empty( $data['persona_notes'] ) ) {
				Agent_Settings::update( $slug, 'persona_notes', (string) $data['persona_notes'] );
				$keys[] = 'persona_notes';
			}
			if ( ! empty( $data['response_style'] ) ) {
				Agent_Settings::update( $slug, 'persona_response_style', (string) $data['response_style'] );
				$keys[] = 'response_style';
			}
			if ( ! empty( $data['suggested_prompts'] ) && is_array( $data['suggested_prompts'] ) ) {
				Agent_Settings::update( $slug, 'persona_suggested_prompts', (string) wp_json_encode( array_values( $data['suggested_prompts'] ) ) );
				$keys[] = 'suggested_prompts';
			}

			if ( ! empty( $keys ) ) {
				$migrated[ $slug ] = $keys;
			}
		}

		update_option( 'agentic_personas_migrated_v1', true );

		self::record(
			'migrate_agent_personas',
			'ok',
			array(
				'agents_migrated' => count( $migrated ),
				'detail'          => $migrated,
			)
		);
	}

	/**
	 * Migrate legacy agentic_agent_overrides wp_options data into the agent_settings table.
	 *
	 * Keys migrated per agent slug:
	 *   provider → override_provider, model → override_model,
	 *   vision_model → override_vision_model, mode → override_mode,
	 *   audio/tts/vision/costs/cache → override_{key}
	 *
	 * @return void
	 */
	private static function migrate_agent_overrides(): void {
		if ( get_option( 'agentic_overrides_migrated_v1' ) ) {
			self::record( 'migrate_agent_overrides', 'skipped', 'already migrated' );
			return;
		}

		$overrides = get_option( 'agentic_agent_overrides', null );

		if ( ! is_array( $overrides ) || empty( $overrides ) ) {
			update_option( 'agentic_overrides_migrated_v1', true );
			self::record( 'migrate_agent_overrides', 'ok', 'no override data to migrate' );
			return;
		}

		include_once AGENT_BUILDER_DIR . 'includes/class-agent-settings.php';

		$keys_map = array(
			'provider'     => 'override_provider',
			'model'        => 'override_model',
			'vision_model' => 'override_vision_model',
			'mode'         => 'override_mode',
			'audio'        => 'override_audio',
			'tts'          => 'override_tts',
			'vision'       => 'override_vision',
			'costs'        => 'override_costs',
			'cache'        => 'override_cache',
		);

		$migrated = array();

		foreach ( $overrides as $slug => $data ) {
			$slug = sanitize_key( (string) $slug );
			if ( empty( $slug ) || ! is_array( $data ) ) {
				continue;
			}
			$written = array();
			foreach ( $keys_map as $old_key => $new_key ) {
				if ( isset( $data[ $old_key ] ) && '' !== (string) $data[ $old_key ] ) {
					Agent_Settings::update( $slug, $new_key, (string) $data[ $old_key ] );
					$written[] = $old_key;
				}
			}
			if ( ! empty( $written ) ) {
				$migrated[ $slug ] = $written;
			}
		}

		update_option( 'agentic_overrides_migrated_v1', true );

		self::record(
			'migrate_agent_overrides',
			'ok',
			array(
				'agents_migrated' => count( $migrated ),
				'detail'          => $migrated,
			)
		);
	}

	/**
	 * Seed core tools and sync agent-contributed tools into the registry.
	 *
	 * @param string $schema_version Current DB_SCHEMA_VERSION.
	 * @return void
	 */
	public static function seed_tools( string $schema_version ): void {
		global $wpdb;

		// Skip if already seeded for this version.
		$seeded_version = get_option( 'agentic_tools_seeded_version', '' );
		if ( $seeded_version === $schema_version ) {
			self::record(
				'seed_tools',
				'skipped',
				array(
					'reason'         => 'already_seeded',
					'schema_version' => $schema_version,
				)
			);
			return;
		}

		// Safety: skip if the tools table doesn't exist yet.
		$table = $wpdb->prefix . 'agentic_tools';
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) !== $table ) {
			self::record( 'seed_tools', 'error', 'tools table does not exist — skipping seed' );
			return;
		}

		// Ensure dependencies are loaded (activation fires before init).
		include_once AGENT_BUILDER_DIR . 'includes/class-risk-level.php';
		include_once AGENT_BUILDER_DIR . 'includes/class-tool-base.php';
		include_once AGENT_BUILDER_DIR . 'includes/class-tool-loader.php';
		include_once AGENT_BUILDER_DIR . 'includes/class-tools-registry.php';

		$category_map = array(
			'db_update_option' => 'database',
			'db_create_post'   => 'database',
			'db_update_post'   => 'database',
			'db_delete_post'   => 'database',
			'agents_available' => 'agents',
			'run_wp_cli'       => 'cli',
		);

		$seeded = Tools_Registry::seed_core_tools( $category_map );

		update_option( 'agentic_tools_seeded_version', $schema_version );

		// Sync agent-contributed tools.
		Tool_Loader::get_instance()->sync_to_registry();

		self::record(
			'seed_tools',
			'ok',
			array(
				'seeded'         => $seeded,
				'schema_version' => $schema_version,
			)
		);
	}

	/**
	 * Seed bundled core skills into the database.
	 *
	 * Reads SKILL.md files from library/skills/ and inserts any that are not
	 * already present. Skipped on repeat activations for the same schema version.
	 *
	 * @param string $schema_version Current DB_SCHEMA_VERSION.
	 * @return void
	 */
	public static function seed_skills( string $schema_version ): void {
		global $wpdb;

		$seeded_version = get_option( 'agentic_skills_seeded_version', '' );
		if ( $seeded_version === $schema_version ) {
			self::record(
				'seed_skills',
				'skipped',
				array(
					'reason'         => 'already_seeded',
					'schema_version' => $schema_version,
				)
			);
			return;
		}

		$table = $wpdb->prefix . 'agentic_skills';
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) !== $table ) {
			self::record( 'seed_skills', 'error', 'skills table does not exist — skipping seed' );
			return;
		}

		include_once AGENT_BUILDER_DIR . 'includes/class-skills-registry.php';

		$seeded = Skills_Registry::seed_core_skills();

		update_option( 'agentic_skills_seeded_version', $schema_version );

		self::record(
			'seed_skills',
			'ok',
			array(
				'seeded'         => $seeded,
				'schema_version' => $schema_version,
			)
		);
	}

	/**
	 * Schedule recurring cron events.
	 *
	 * @return void
	 */
	private static function schedule_cron_events(): void {
		$results = array();

		if ( ! wp_next_scheduled( 'agentic_cleanup_audit_log' ) ) {
			wp_schedule_event( time(), 'daily', 'agentic_cleanup_audit_log' );
			$results['agentic_cleanup_audit_log'] = 'scheduled';
		} else {
			$results['agentic_cleanup_audit_log'] = 'already_scheduled';
		}

		if ( ! wp_next_scheduled( 'agentic_costs_check_alerts' ) ) {
			wp_schedule_event( time(), 'daily', 'agentic_costs_check_alerts' );
			$results['agentic_costs_check_alerts'] = 'scheduled';
		} else {
			$results['agentic_costs_check_alerts'] = 'already_scheduled';
		}

		self::record( 'schedule_cron_events', 'ok', $results );
	}
}
