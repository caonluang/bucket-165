<?php
/**
 * Agent Manifest Validator — sanitizes and validates declarative agent.json data.
 *
 * Runtime-created agents are stored as plain-data manifests (never executable
 * PHP). This validator is the trust boundary: it accepts a raw manifest array
 * (typically assembled from LLM-supplied fields) and returns a strictly
 * sanitized manifest, or a WP_Error. Every field is coerced to a safe scalar
 * or list of scalars — there is no field through which code can be injected,
 * and the resulting JSON is only ever read as data by Manifest_Agent.
 *
 * @package    Agent_Builder
 * @subpackage Includes
 * @author     Agent Builder Team <support@agentic-plugin.com>
 * @license    GPL-2.0-or-later https://www.gnu.org/licenses/gpl-2.0.html
 * @link       https://agentic-plugin.com
 * @since      2.10.0
 *
 * php version 8.1
 */

declare(strict_types=1);

namespace Agentic;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Validates and sanitizes agent manifests.
 */
final class Agent_Manifest_Validator {

	/**
	 * Manifest schema version written into every manifest.
	 */
	public const SCHEMA_VERSION = 1;

	/**
	 * Allowed agent categories.
	 *
	 * @var string[]
	 */
	private const ALLOWED_CATEGORIES = array(
		'content',
		'admin',
		'ecommerce',
		'frontend',
		'developer',
		'seo',
		'security',
		'media',
		'support',
	);

	/**
	 * Maximum lengths for free-text fields (defence-in-depth against bloat).
	 */
	private const MAX_NAME        = 100;
	private const MAX_DESCRIPTION = 500;
	private const MAX_PROMPT      = 200;
	private const MAX_PROMPTS     = 6;
	private const MAX_CAPS        = 20;
	private const MAX_ICON        = 16;

	/**
	 * Validate and sanitize a raw manifest.
	 *
	 * @param array<string, mixed> $raw Raw manifest fields.
	 * @return array<string, mixed>|\WP_Error Sanitized manifest, or error.
	 */
	public static function validate( array $raw ) {
		$slug = sanitize_key( (string) ( $raw['slug'] ?? '' ) );
		if ( '' === $slug ) {
			$slug = sanitize_title( (string) ( $raw['name'] ?? '' ) );
		}
		if ( '' === $slug ) {
			return new \WP_Error( 'invalid_slug', __( 'A valid agent slug or name is required.', 'agent-builder' ) );
		}

		$name = self::clean_text( (string) ( $raw['name'] ?? '' ), self::MAX_NAME );
		if ( '' === $name ) {
			return new \WP_Error( 'invalid_name', __( 'Agent name is required.', 'agent-builder' ) );
		}

		$description = self::clean_text( (string) ( $raw['description'] ?? '' ), self::MAX_DESCRIPTION );
		if ( '' === $description ) {
			return new \WP_Error( 'invalid_description', __( 'Agent description is required.', 'agent-builder' ) );
		}

		$category = strtolower( sanitize_key( (string) ( $raw['category'] ?? 'admin' ) ) );
		if ( ! in_array( $category, self::ALLOWED_CATEGORIES, true ) ) {
			$category = 'admin';
		}

		$manifest = array(
			'schema'            => self::SCHEMA_VERSION,
			'slug'              => $slug,
			'name'              => $name,
			'description'       => $description,
			'category'          => $category,
			'icon'              => self::clean_icon( (string) ( $raw['icon'] ?? '🤖' ) ),
			'version'           => self::clean_version( (string) ( $raw['version'] ?? '1.0.0' ) ),
			'author'            => self::clean_text( (string) ( $raw['author'] ?? '' ), self::MAX_NAME ),
			'capabilities'      => self::clean_capabilities( $raw['capabilities'] ?? array() ),
			'tools'             => self::clean_tool_names( $raw['tools'] ?? array() ),
			'suggested_prompts' => self::clean_prompts( $raw['suggested_prompts'] ?? array() ),
			'team'              => ! empty( $raw['team'] ),
		);

		if ( isset( $raw['welcome_message'] ) ) {
			$manifest['welcome_message'] = self::clean_text( (string) $raw['welcome_message'], self::MAX_DESCRIPTION );
		}

		return $manifest;
	}

	/**
	 * Read and validate a manifest from a JSON file.
	 *
	 * @param string $file Absolute path to agent.json.
	 * @return array<string, mixed>|null Sanitized manifest, or null on failure.
	 */
	public static function from_file( string $file ): ?array {
		$contents = File_Manager::get_contents( $file );
		if ( false === $contents || '' === $contents ) {
			return null;
		}
		$decoded = json_decode( $contents, true );
		if ( ! is_array( $decoded ) ) {
			return null;
		}
		$result = self::validate( $decoded );
		return is_wp_error( $result ) ? null : $result;
	}

	/**
	 * Collapse whitespace and strip tags/control chars from a free-text field.
	 *
	 * @param string $value Raw value.
	 * @param int    $max   Maximum length.
	 * @return string
	 */
	private static function clean_text( string $value, int $max ): string {
		$value = sanitize_text_field( $value );
		if ( strlen( $value ) > $max ) {
			$value = substr( $value, 0, $max );
		}
		return trim( $value );
	}

	/**
	 * Keep only a short, safe icon string (emoji or dashicons-* slug).
	 *
	 * @param string $icon Raw icon.
	 * @return string
	 */
	private static function clean_icon( string $icon ): string {
		$icon = trim( wp_strip_all_tags( $icon ) );
		if ( strlen( $icon ) > self::MAX_ICON ) {
			$icon = substr( $icon, 0, self::MAX_ICON );
		}
		return '' !== $icon ? $icon : '🤖';
	}

	/**
	 * Normalize a semver-ish version string.
	 *
	 * @param string $version Raw version.
	 * @return string
	 */
	private static function clean_version( string $version ): string {
		$version = preg_replace( '/[^0-9.]/', '', $version ) ?? '';
		return '' !== $version ? $version : '1.0.0';
	}

	/**
	 * Sanitize capabilities to a list of capability slugs.
	 *
	 * @param mixed $caps Raw capabilities (array or comma list).
	 * @return string[]
	 */
	private static function clean_capabilities( $caps ): array {
		if ( is_string( $caps ) ) {
			$caps = explode( ',', $caps );
		}
		if ( ! is_array( $caps ) ) {
			return array( 'read' );
		}
		$clean = array();
		foreach ( $caps as $cap ) {
			$cap = sanitize_key( (string) $cap );
			if ( '' !== $cap ) {
				$clean[] = $cap;
			}
		}
		$clean = array_values( array_unique( $clean ) );
		if ( empty( $clean ) ) {
			return array( 'read' );
		}
		return array_slice( $clean, 0, self::MAX_CAPS );
	}

	/**
	 * Extract a clean list of tool-name slugs from the tools input.
	 *
	 * Accepts either a list of strings or a list of {name: ...} objects.
	 *
	 * @param mixed $tools Raw tools input.
	 * @return string[]
	 */
	private static function clean_tool_names( $tools ): array {
		if ( ! is_array( $tools ) ) {
			return array();
		}
		$names = array();
		foreach ( $tools as $tool ) {
			if ( is_array( $tool ) ) {
				$name = (string) ( $tool['name'] ?? '' );
			} else {
				$name = (string) $tool;
			}
			$name = sanitize_key( $name );
			if ( '' !== $name ) {
				$names[] = $name;
			}
		}
		return array_values( array_unique( $names ) );
	}

	/**
	 * Sanitize the suggested-prompts list.
	 *
	 * @param mixed $prompts Raw prompts.
	 * @return string[]
	 */
	private static function clean_prompts( $prompts ): array {
		if ( ! is_array( $prompts ) ) {
			return array();
		}
		$clean = array();
		foreach ( $prompts as $prompt ) {
			$prompt = self::clean_text( (string) $prompt, self::MAX_PROMPT );
			if ( '' !== $prompt ) {
				$clean[] = $prompt;
			}
		}
		return array_slice( $clean, 0, self::MAX_PROMPTS );
	}
}
