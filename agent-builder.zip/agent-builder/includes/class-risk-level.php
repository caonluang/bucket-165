<?php
/**
 * Risk Level — defines the five risk tiers for agent tool access
 *
 * Each tool declares a default risk level. Agent abilities.json files declare
 * per-tool risk (can only escalate, never downgrade). Site owners can override
 * risk per-agent-tool from the admin UI.
 *
 * @package    Agent_Builder
 * @subpackage Includes
 * @since      2.4.0
 *
 * php version 8.1
 */

declare(strict_types=1);

namespace Agentic;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Risk level constants and helpers for tool access control.
 */
class Risk_Level {

	/**
	 * Cached registry data from the wp_agentic_tools database table.
	 *
	 * @var array|null
	 */
	private static ?array $registry = null;

	/**
	 * Read-only on non-personal information. No logging beyond normal audit trail.
	 */
	public const NONE = 'none';

	/**
	 * Read operations that may expose personal information. Logged with PII flag.
	 */
	public const LOW = 'low';

	/**
	 * Write operations. Agent pauses for in-chat confirmation (Proposals system).
	 */
	public const MEDIUM = 'medium';

	/**
	 * Significant write or bulk operations. Queued for admin approval at
	 * /wp-admin/admin.php?page=agentic-approvals. Logged with user sign-off.
	 */
	public const HIGH = 'high';

	/**
	 * Destructive operations that neither agent nor user should perform.
	 * Tool is hidden from the LLM entirely; execution is always blocked.
	 */
	public const EXTREME = 'extreme';

	/**
	 * Ordered list of all valid levels (lowest to highest).
	 */
	public const ALL = array(
		self::NONE,
		self::LOW,
		self::MEDIUM,
		self::HIGH,
		self::EXTREME,
	);

	/**
	 * Numeric weight for each level (used for max() comparisons).
	 */
	private const WEIGHTS = array(
		self::NONE    => 0,
		self::LOW     => 1,
		self::MEDIUM  => 2,
		self::HIGH    => 3,
		self::EXTREME => 4,
	);

	/**
	 * Human-readable labels.
	 */
	public const LABELS = array(
		self::NONE    => 'No Risk',
		self::LOW     => 'Low Risk',
		self::MEDIUM  => 'Medium Risk',
		self::HIGH    => 'High Risk',
		self::EXTREME => 'Extreme Risk',
	);

	/**
	 * Check if a given string is a valid risk level.
	 *
	 * @param string $level Risk level to validate.
	 * @return bool
	 */
	public static function is_valid( string $level ): bool {
		return in_array( $level, self::ALL, true );
	}

	/**
	 * Return the higher of two risk levels.
	 *
	 * Used to enforce "can only escalate, never downgrade":
	 *   effective_risk = max( tool_default, abilities_json_risk )
	 *
	 * @param string $a First risk level.
	 * @param string $b Second risk level.
	 * @return string The higher risk level.
	 */
	public static function max( string $a, string $b ): string {
		$wa = self::WEIGHTS[ $a ] ?? 0;
		$wb = self::WEIGHTS[ $b ] ?? 0;
		return $wa >= $wb ? $a : $b;
	}

	/**
	 * Get the numeric weight for a risk level.
	 *
	 * @param string $level Risk level.
	 * @return int Weight (0–4).
	 */
	public static function weight( string $level ): int {
		return self::WEIGHTS[ $level ] ?? 0;
	}

	/**
	 * Get the maximum risk level an agent mode auto-approves.
	 *
	 * Anything above the ceiling requires confirmation or queuing.
	 *
	 * @param string $mode Agent mode ('disabled', 'supervised', 'autonomous').
	 * @return string Maximum auto-approve risk level.
	 */
	public static function mode_ceiling( string $mode ): string {
		return match ( $mode ) {
			'autonomous' => self::LOW,
			'supervised' => self::NONE,
			default      => self::NONE,
		};
	}

	/**
	 * Determine the required enforcement action for a given risk and mode.
	 *
	 * @param string $risk Effective risk level of the tool.
	 * @param string $mode Agent operating mode.
	 * @return string One of: 'allow', 'confirm', 'queue', 'block'.
	 */
	public static function enforcement( string $risk, string $mode ): string {
		if ( self::EXTREME === $risk ) {
			return 'block';
		}

		if ( 'disabled' === $mode ) {
			return 'block';
		}

		$ceiling = self::mode_ceiling( $mode );

		if ( self::weight( $risk ) <= self::weight( $ceiling ) ) {
			return 'allow';
		}

		// Above ceiling: medium → confirm, high → queue.
		if ( self::HIGH === $risk ) {
			return 'queue';
		}

		return 'confirm';
	}

	/**
	 * Load the master risk registry from the wp_agentic_tools database table.
	 *
	 * @return array Flat map of tool_name => entry array with at least 'risk'.
	 */
	private static function load_registry(): array {
		if ( null !== self::$registry ) {
			return self::$registry;
		}

		self::$registry = array();

		$all_tools = Tools_Registry::get_all();
		foreach ( $all_tools as $name => $row ) {
			self::$registry[ $name ] = array(
				'risk'     => $row['risk_level'] ?? self::NONE,
				'category' => $row['category'] ?? 'wordpress',
			);
		}

		return self::$registry;
	}

	/**
	 * Get the authoritative default risk level for a tool.
	 *
	 * Reads from the wp_agentic_tools database table.
	 * Returns NONE if the tool is not listed.
	 *
	 * @param string $tool_name Tool slug (e.g. 'create_post_content' or 'wp-extended/get-posts').
	 * @return string Risk level constant.
	 */
	public static function get_tool_default( string $tool_name ): string {
		$registry = self::load_registry();

		if ( isset( $registry[ $tool_name ]['risk'] ) && self::is_valid( $registry[ $tool_name ]['risk'] ) ) {
			return $registry[ $tool_name ]['risk'];
		}

		return self::NONE;
	}

	/**
	 * Get the full registry entry for a tool (risk, category, writes, pii, etc.).
	 *
	 * @param string $tool_name Tool slug.
	 * @return array|null Entry array or null if not in registry.
	 */
	public static function get_tool_entry( string $tool_name ): ?array {
		$registry = self::load_registry();
		return $registry[ $tool_name ] ?? null;
	}

	/**
	 * Get the entire risk registry as a flat map of tool_name => entry.
	 *
	 * @return array<string, array>
	 */
	public static function get_registry(): array {
		return self::load_registry();
	}

	/**
	 * Clear the cached registry, forcing a fresh read on next access.
	 */
	public static function bust_cache(): void {
		self::$registry = null;
	}
}
