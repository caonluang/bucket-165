<?php
/**
 * Agent Updates
 *
 * Checks for newer versions of AI agents
 * and provides the one-click update installation logic
 *
 * @package    Agent_Builder
 * @subpackage Includes
 * @since      2.4.0
 */

namespace Agentic;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Agent_Updates class.
 */
class Agent_Updates {

	const TRANSIENT     = 'agentic_agent_updates';
	const TTL           = 12 * HOUR_IN_SECONDS;
	const OPT_IN_OPTION = 'agentic_agent_updates_optin';

	/**
	 * Whether the site administrator has opted in to agent update checks.
	 *
	 * Returns true only when the option is explicitly set to 'yes'.
	 * An empty / missing value means the choice has not been made yet.
	 */
	public static function is_opted_in(): bool {
		return 'yes' === get_option( self::OPT_IN_OPTION, '' );
	}

	/**
	 * Whether the consent prompt still needs to be shown (choice not yet made).
	 */
	public static function needs_consent(): bool {
		return '' === get_option( self::OPT_IN_OPTION, '' );
	}

	/**
	 * Check for available agent updates and cache the results.
	 *
	 * Only caches a result on success so that transient expiry triggers a fresh
	 * check — failed checks are retried on the next page load.
	 * Does nothing if the administrator has not opted in.
	 *
	 * @param array $installed Map of slug => agent_data from get_installed_agents().
	 */
	public static function check( array $installed ): void {
		if ( ! self::is_opted_in() ) {
			return;
		}
		$agents = array();
		foreach ( $installed as $slug => $agent ) {
			if ( ! empty( $agent['version'] ) ) {
				$agents[] = array(
					'slug'    => $slug,
					'version' => $agent['version'],
				);
			}
		}

		if ( empty( $agents ) ) {
			set_transient( self::TRANSIENT, array(), self::TTL );
			return;
		}

		$response = wp_remote_post(
			Service_Registry::url( 'agentic-api', '/wp-json/agentic/v1/agents/check-updates' ),
			array(
				'body'    => wp_json_encode( array( 'agents' => $agents ) ),
				'headers' => array( 'Content-Type' => 'application/json' ),
				'timeout' => 10,
			)
		);

		if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
			// Fail-open: don't cache errors so the next page load triggers a retry.
			return;
		}

		$data = json_decode( wp_remote_retrieve_body( $response ), true );
		set_transient( self::TRANSIENT, is_array( $data ) ? $data : array(), self::TTL );
	}

	/**
	 * Get cached update data.
	 *
	 * @return array<string, array{name: string, version: string, package: string, url: string}>
	 */
	public static function get(): array {
		$data = get_transient( self::TRANSIENT );
		return is_array( $data ) ? $data : array();
	}

	/**
	 * Return the number of available updates.
	 */
	public static function count(): int {
		return count( self::get() );
	}

	/**
	 * Bust the updates cache so the next page load triggers a fresh check.
	 */
	public static function bust(): void {
		delete_transient( self::TRANSIENT );
	}

	/**
	 * admin_init handler: process consent form and trigger update check on the Agents page.
	 *
	 * No-ops on all other admin pages. Handles the consent POST before any output
	 * is sent, then triggers a fresh remote check when the transient is stale.
	 *
	 * @return void
	 */
	public static function maybe_check_on_agents_page(): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( ! isset( $_GET['page'] ) || 'agentic-agents' !== $_GET['page'] ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return;
		}

		// Handle consent form POST before any output is sent.
		if (
			isset( $_POST['agentic_updates_consent'], $_POST['_wpnonce_updates_consent'] ) &&
			wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wpnonce_updates_consent'] ) ), 'agentic_updates_consent' ) &&
			current_user_can( 'manage_options' )
		) {
			$agentic_consent_value = 'enable' === sanitize_key( wp_unslash( $_POST['agentic_updates_consent'] ) ) ? 'yes' : 'no';
			update_option( self::OPT_IN_OPTION, $agentic_consent_value );
			wp_safe_redirect( admin_url( 'admin.php?page=agentic-agents' ) );
			exit;
		}

		// Trigger a fresh update check when the cache is stale.
		if ( false !== get_transient( self::TRANSIENT ) ) {
			return;
		}

		self::check( \Agentic_Agent_Registry::get_instance()->get_installed_agents( true ) );
	}

	/**
	 * Download and install an update for a given agent.
	 *
	 * Replicates the zip-upload flow from admin/agents.php but triggered
	 * programmatically.  Existing per-agent files that are NOT inside the new
	 * zip (e.g. .activation, .uploaded) are preserved because WP's unzip_file()
	 * only writes files that are actually in the archive.
	 *
	 * @param string $slug    Agent slug.
	 * @param string $zip_url Direct download URL for the new-version zip.
	 * @return true|\WP_Error
	 */
	public static function do_update( string $slug, string $zip_url ): true|\WP_Error {
		if ( ! current_user_can( 'manage_options' ) ) {
			return new \WP_Error( 'forbidden', __( 'Insufficient permissions.', 'agent-builder' ) );
		}

		// Installing/updating agent packages from a remote archive is an Agent
		// Builder Pro feature. The free plugin never downloads and installs
		// executable agent code (WordPress.org Guideline 8).
		if ( ! class_exists( '\Agentic\License_Client' ) || ! \Agentic\License_Client::get_instance()->is_pro() ) {
			return new \WP_Error( 'pro_required', __( 'Updating installed assistant packages requires Agent Builder Pro.', 'agent-builder' ) );
		}

		// SSRF guard — only allow downloads from our host.
		$allowed_host = 'agentic-plugin.com';
		$url_host     = wp_parse_url( $zip_url, PHP_URL_HOST );
		if ( $url_host !== $allowed_host ) {
			return new \WP_Error( 'invalid_url', __( 'Invalid update source.', 'agent-builder' ) );
		}

		require_once ABSPATH . 'wp-admin/includes/file.php';
		WP_Filesystem();
		global $wp_filesystem;

		$agents_dir = AGENTIC_AGENTS_DIR;

		if ( ! is_dir( $agents_dir ) ) {
			wp_mkdir_p( $agents_dir );
		}

		// Log that the update process is beginning (before any I/O that can fail).
		\Agentic\Security_Log::log_system(
			'agent_update_started',
			'agents',
			array(
				'slug'    => $slug,
				'zip_url' => $zip_url,
			)
		);

		// Download the zip to a temp file.
		$tmp_file = download_url( $zip_url, 30 );
		if ( is_wp_error( $tmp_file ) ) {
			\Agentic\Security_Log::log_system(
				'agent_update_failed',
				'agents',
				array(
					'slug'   => $slug,
					'reason' => 'download_failed',
					'error'  => $tmp_file->get_error_message(),
				)
			);
			return $tmp_file;
		}

		// Extract to a unique temp directory so we can inspect the zip structure
		// before committing to the final destination.  This mirrors the manual-upload
		// flow in admin/agents.php and correctly handles zips that contain a wrapper
		// subdirectory (e.g. ai-radar-1.2/agent.php) as well as flat zips
		// (e.g. agent.php at the archive root).
		$tmp_dir = $agents_dir . '/__update_tmp_' . wp_generate_password( 8, false );
		wp_mkdir_p( $tmp_dir );

		$result = unzip_file( $tmp_file, $tmp_dir );
		wp_delete_file( $tmp_file );

		if ( is_wp_error( $result ) ) {
			$wp_filesystem->delete( $tmp_dir, true );
			\Agentic\Security_Log::log_system(
				'agent_update_failed',
				'agents',
				array(
					'slug'   => $slug,
					'reason' => 'unzip_failed',
					'error'  => $result->get_error_message(),
				)
			);
			return $result;
		}

		// Locate agent.php — either at the archive root or one level deep inside
		// a wrapper folder (the most common GitHub / release-zip layout).
		$agent_root = null;

		if ( file_exists( $tmp_dir . '/agent.php' ) ) {
			$agent_root = $tmp_dir;
		} else {
			$subdirs = glob( $tmp_dir . '/*', GLOB_ONLYDIR );
			if ( $subdirs ) {
				foreach ( $subdirs as $subdir ) {
					if ( file_exists( $subdir . '/agent.php' ) ) {
						$agent_root = $subdir;
						break;
					}
				}
			}
		}

		if ( ! $agent_root ) {
			$wp_filesystem->delete( $tmp_dir, true );
			\Agentic\Security_Log::log_system(
				'agent_update_failed',
				'agents',
				array(
					'slug'   => $slug,
					'reason' => 'no_agent_php',
					'error'  => 'The update zip does not contain a valid agent.php file.',
				)
			);
			return new \WP_Error( 'invalid_agent', __( 'The update zip does not contain a valid agent.php file.', 'agent-builder' ) );
		}

		// Move extracted agent into the canonical slug directory, replacing any
		// existing version (both in agentic-agents/ and effectively shadowing library/).
		$dest_dir = $agents_dir . '/' . sanitize_file_name( $slug );

		if ( is_dir( $dest_dir ) ) {
			$wp_filesystem->delete( $dest_dir, true );
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.rename_rename -- Moving a local directory; WP_Filesystem::move() does not reliably move directories.
		if ( ! rename( $agent_root, $dest_dir ) ) {
			$wp_filesystem->delete( $tmp_dir, true );
			\Agentic\Security_Log::log_system(
				'agent_update_failed',
				'agents',
				array(
					'slug'   => $slug,
					'reason' => 'rename_failed',
					'src'    => $agent_root,
					'dest'   => $dest_dir,
				)
			);
			return new \WP_Error( 'rename_failed', __( 'Failed to move updated agent files into place.', 'agent-builder' ) );
		}

		// Clean up temp extraction dir (may already be empty if agent_root == tmp_dir).
		if ( is_dir( $tmp_dir ) ) {
			$wp_filesystem->delete( $tmp_dir, true );
		}

		// Stamp .uploaded so the registry treats this as a user-installed agent
		// rather than a bundled library agent (giving it load priority over library/).
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents,WordPress.WP.AlternativeFunctions.file_system_read_file_put_contents
		file_put_contents( $dest_dir . '/.uploaded', '1' );

		// Bust both the registry cache and the updates transient.
		\Agentic_Agent_Registry::get_instance()->get_installed_agents( true );
		self::bust();

		\Agentic\Security_Log::log_system(
			'agent_update_succeeded',
			'agents',
			array( 'slug' => $slug )
		);

		return true;
	}
}
