<?php
/**
 * Admin Notice Manager
 *
 * Owns all wp-admin banner notices for the plugin.
 * Extracted from the Plugin class to keep notice logic in one place.
 *
 * @package    Agent_Builder
 * @subpackage Includes
 * @since      2.9.115
 *
 * php version 8.1
 */

declare(strict_types=1);

namespace Agentic;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers and renders all admin banner notices.
 */
class Admin_Notice_Manager {

	/**
	 * Show a one-time banner to finish plugin setup.
	 * Displayed until onboarding is complete or the user explicitly skips.
	 *
	 * @return void
	 */
	public function show_setup_needed_notice(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		if ( get_option( 'agentic_onboarding_complete' ) ) {
			return;
		}

		if ( get_user_meta( get_current_user_id(), 'agentic_setup_notice_dismissed', true ) ) {
			return;
		}

		// Don't show the banner on the signup pages themselves.
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only page identification.
		$current_page = isset( $_GET['page'] ) ? sanitize_key( $_GET['page'] ) : '';
		if ( in_array( $current_page, array( 'agentic-signup', 'agentic-setup' ), true ) ) {
			return;
		}

		$setup_url = admin_url( 'admin.php?page=agentic-signup' );
		$nonce     = wp_create_nonce( 'agentic_dismiss_setup_notice' );
		?>
		<div class="notice notice-info is-dismissible" id="agentic-setup-notice">
			<p>
				<strong><?php esc_html_e( 'Agent Builder is almost ready!', 'agent-builder' ); ?></strong>
				<?php esc_html_e( 'Finish setup to start using your AI agents.', 'agent-builder' ); ?>
				&nbsp;
				<a href="<?php echo esc_url( $setup_url ); ?>" class="button button-primary">
					<?php esc_html_e( 'Finish Setup', 'agent-builder' ); ?>
				</a>
			</p>
		</div>
		<script>
		( function () {
			var notice = document.getElementById( 'agentic-setup-notice' );
			if ( ! notice ) { return; }
			notice.addEventListener( 'click', function ( e ) {
				if ( ! e.target.classList.contains( 'notice-dismiss' ) ) { return; }
				wp.ajax.post( 'agentic_dismiss_setup_notice', { nonce: <?php echo wp_json_encode( $nonce ); ?> } );
			} );
		} () );
		</script>
		<?php
	}

	/**
	 * Show admin notice when a user has reached their free Agentic AI quota.
	 *
	 * @return void
	 */
	public function show_quota_reached_notice(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		if ( ! get_transient( 'agentic_quota_reached_notice' ) ) {
			return;
		}

		// Dismiss handler.
		if ( isset( $_GET['agentic_dismiss_quota_notice'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['agentic_dismiss_quota_notice'] ) ), 'agentic_dismiss_quota' ) ) {
			delete_transient( 'agentic_quota_reached_notice' );
			return;
		}

		$dismiss_url = wp_nonce_url( add_query_arg( 'agentic_dismiss_quota_notice', '' ), 'agentic_dismiss_quota', 'agentic_dismiss_quota_notice' );
		?>
		<div class="notice notice-warning is-dismissible" data-dismiss-url="<?php echo esc_url( $dismiss_url ); ?>">
			<p>
				<strong><?php esc_html_e( 'AI Rate Limit Reached', 'agent-builder' ); ?></strong><br>
				<?php esc_html_e( 'A user has hit a rate limit with your configured AI provider. You can switch providers or review your usage in Settings.', 'agent-builder' ); ?>
			</p>
			<p>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=agentic-settings' ) ); ?>" class="button"><?php esc_html_e( 'Settings', 'agent-builder' ); ?></a>
			</p>
		</div>
		<script>
		(function(){
			var n = document.querySelector('[data-dismiss-url]');
			if (!n) return;
			n.querySelector('.notice-dismiss').addEventListener('click', function(){
				var xhr = new XMLHttpRequest();
				xhr.open('GET', n.dataset.dismissUrl);
				xhr.send();
			});
		})();
		</script>
		<?php
	}
}
