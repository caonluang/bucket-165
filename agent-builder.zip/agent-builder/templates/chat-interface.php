<?php
/**
 * Chat interface template
 *
 * Supports dynamic agent selection - users can chat with any active agent.
 *
 * @package    Agent_Builder
 * @subpackage Templates
 * @author     Agent Builder Team <support@agentic-plugin.com>
 * @license    GPL-2.0-or-later https://www.gnu.org/licenses/gpl-2.0.html
 * @link       https://agentic-plugin.com
 * @since      0.1.0
 *
 * php version 8.1
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$agentic_user = wp_get_current_user();

// Get accessible agents.
$agentic_registry = Agentic_Agent_Registry::get_instance();
$agentic_agents   = $agentic_registry->get_accessible_instances();

// Default to first available agent or passed agent_id.
// Priority: URL parameter → cookie preference → first agent.
// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- No form submission, just URL parameter for agent selection.
$agentic_default_agent_id = isset( $_GET['agent'] ) ? sanitize_key( $_GET['agent'] ) : '';

if ( ! $agentic_default_agent_id && isset( $_COOKIE['agentic_last_agent'] ) ) {
	$agentic_default_agent_id = sanitize_key( $_COOKIE['agentic_last_agent'] );
}

$agentic_current_agent    = null;
$agentic_current_agent_id = '';

if ( $agentic_default_agent_id && isset( $agentic_agents[ $agentic_default_agent_id ] ) ) {
	$agentic_current_agent    = $agentic_agents[ $agentic_default_agent_id ];
	$agentic_current_agent_id = $agentic_default_agent_id;
} elseif ( ! empty( $agentic_agents ) ) {
	$agentic_current_agent    = reset( $agentic_agents );
	$agentic_current_agent_id = $agentic_current_agent->get_id();
}
?>
<style>.agentic-chat-container{opacity:0;transition:opacity .15s ease-in}</style>
<div id="agentic-chat" class="agentic-chat-container" data-agent-id="<?php echo esc_attr( $agentic_current_agent_id ); ?>">
	<div class="agentic-chat-header">
		<div class="agentic-agent-info">
			<?php if ( count( $agentic_agents ) > 1 ) : ?>
			<div class="agentic-agent-selector">
				<select id="agentic-agent-select" class="agentic-agent-dropdown">
				<?php
				// Sort agents by name (case-insensitive).
				$agentic_sorted_agents = $agentic_agents;
				uasort(
					$agentic_sorted_agents,
					function ( $a, $b ) {
						return strcasecmp( $a->get_name(), $b->get_name() );
					}
				);
				?>
				<?php foreach ( $agentic_sorted_agents as $agentic_agent ) : ?>
						<option value="<?php echo esc_attr( $agentic_agent->get_id() ); ?>" 
								data-icon="<?php echo esc_attr( $agentic_agent->get_icon() ); ?>"
								data-welcome="<?php echo esc_attr( $agentic_agent->get_welcome_message() ); ?>"
								<?php selected( $agentic_agent->get_id(), $agentic_current_agent_id ); ?>>
							<?php echo esc_html( $agentic_agent->get_icon() . ' ' . $agentic_agent->get_name() ); ?>
						</option>
					<?php endforeach; ?>
					<?php if ( current_user_can( 'manage_options' ) ) : ?>
					<option value="load-more" data-action="load-more">+ Load more . . .</option>
					<?php endif; ?>
				</select>
			</div>
			<?php else : ?>
			<div class="agentic-agent-avatar">
				<?php echo esc_html( $agentic_current_agent ? $agentic_current_agent->get_icon() : '🤖' ); ?>
			</div>
			<?php endif; ?>
			<div class="agentic-agent-details">
				<?php if ( $agentic_current_agent ) : ?>
					<div class="agentic-agent-meta">
						Version <?php echo esc_html( $agentic_current_agent->get_version() ?? '1.0.0' ); ?>
						<span class="agent-meta-separator">|</span>
						By
						<?php
						$agentic_author     = $agentic_current_agent->get_author() ?? 'Unknown';
						$agentic_author_uri = $agentic_current_agent->get_author_uri();
						if ( $agentic_author_uri ) :
							?>
							<a href="<?php echo esc_url( $agentic_author_uri ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $agentic_author ); ?></a>
						<?php else : ?>
							<?php echo esc_html( $agentic_author ); ?>
						<?php endif; ?>
					</div>
				<?php endif; ?>
			</div>
		</div>
		<div class="agentic-chat-actions">
			<button id="agentic-history-btn" class="agentic-btn-secondary" title="Chat History">
				<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
			</button>
			<button id="agentic-clear-chat" class="agentic-btn-secondary" title="New Chat">
				<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg>
			</button>
		</div>
	</div>

	<div id="agentic-history-panel" class="agentic-history-panel" style="display: none;">
		<div class="agentic-history-header">
			<h3>Chat History</h3>
			<button id="agentic-history-close" class="agentic-history-close" title="Close">&times;</button>
		</div>
		<div id="agentic-history-list" class="agentic-history-list">
			<div class="agentic-history-loading">Loading sessions…</div>
		</div>
	</div>

	<div id="agentic-messages" class="agentic-chat-messages">
		<?php if ( $agentic_current_agent ) : ?>
		<div class="agentic-message agentic-message-agent">
			<div class="agentic-message-content">
				<?php
				$agentic_welcome = $agentic_current_agent->get_welcome_message();
				// Convert markdown bold, links, and list items for display.
				$agentic_welcome = esc_html( $agentic_welcome );
				$agentic_welcome = preg_replace( '/\*\*([^*]+)\*\*/', '<strong>$1</strong>', $agentic_welcome );
				$agentic_welcome = preg_replace( '/\[([^\]]+)\]\(([^)]+)\)/', '<a href="$2" target="_blank">$1</a>', $agentic_welcome );
				$agentic_welcome = preg_replace( '/^- /m', '&bull; ', $agentic_welcome );
				$agentic_welcome = nl2br( $agentic_welcome );
				echo wp_kses_post( $agentic_welcome, 'post' );
			?>
				
			<?php if ( 'wordpress-assistant' === $agentic_current_agent->get_id() ) : ?>
				<?php
				// Build pills from the agent's own shortcut list, filtered to only agents
				// that are actually accessible (active + permitted) on this install.
				$agentic_shortcuts_raw   = method_exists( $agentic_current_agent, 'get_agent_shortcuts' )
					? $agentic_current_agent->get_agent_shortcuts()
					: array();
				$agentic_quick_shortcuts = array_filter(
					$agentic_shortcuts_raw,
					function ( $s ) use ( $agentic_agents ) {
						return isset( $agentic_agents[ $s['agent_id'] ] );
					}
				);
				?>
				<?php if ( ! empty( $agentic_quick_shortcuts ) ) : ?>
				<div class="agentic-quick-actions">
					<?php foreach ( $agentic_quick_shortcuts as $agentic_shortcut ) : ?>
						<a href="<?php echo esc_url( admin_url( 'admin.php?page=agentic-chat&agent=' . $agentic_shortcut['agent_id'] ) ); ?>" class="agentic-quick-action-btn">
							<?php echo esc_html( $agentic_shortcut['label'] ); ?>
						</a>
					<?php endforeach; ?>
				</div>
				<?php endif; ?>
				<?php else : ?>
					<?php
					$agentic_prompts = $agentic_current_agent->get_suggested_prompts();
					if ( ! empty( $agentic_prompts ) ) :
						?>
				<div class="agentic-suggested-prompts">
						<?php foreach ( $agentic_prompts as $agentic_prompt ) : ?>
						<button class="agentic-prompt-btn" data-prompt="<?php echo esc_attr( $agentic_prompt ); ?>">
							<?php echo esc_html( $agentic_prompt ); ?>
						</button>
					<?php endforeach; ?>
				</div>
					<?php endif; ?>
				<?php endif; ?>
			</div>
		</div>
		<?php else : ?>
		<div class="agentic-empty-state">
			<div class="empty-state-icon">🤖</div>
			<h2>No Agents Activated</h2>
			<p>Activate an AI agent to start chatting. Agents can help you with content, SEO, security, and more.</p>
			
			<?php if ( current_user_can( 'manage_options' ) ) : ?>
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=agentic-agents' ) ); ?>" class="activate-agents-btn">
				Activate Agents in Dashboard
			</a>
			<?php else : ?>
			<p class="contact-admin">Contact your site administrator to activate AI agents.</p>
			<?php endif; ?>
		</div>
		<?php endif; ?>
	</div>

	<?php if ( $agentic_current_agent ) : ?>
	<div id="agentic-consent-banner" class="agentic-consent-banner" style="display:none;">
		<p id="agentic-consent-text"></p>
		<button type="button" id="agentic-consent-accept" class="agentic-consent-accept"><?php esc_html_e( 'I Understand', 'agent-builder' ); ?></button>
	</div>
	<div class="agentic-chat-input-container">
		<div class="agentic-typing-indicator" id="agentic-typing" style="display: none;">
			<span></span>
			<span></span>
			<span></span>
			<span id="agentic-typing-text">Agent is thinking...</span>
		</div>
		<div id="agentic-image-preview" class="agentic-image-preview" style="display:none;">
			<img id="agentic-preview-img" src="" alt="Preview" />
			<button type="button" id="agentic-remove-image" class="agentic-remove-image" title="<?php esc_attr_e( 'Remove image', 'agent-builder' ); ?>">&times;</button>
		</div>
		<form id="agentic-chat-form" class="agentic-chat-form">
			<input type="file" id="agentic-file-input" accept="image/jpeg,image/png,image/gif,image/webp" style="display:none;" />
			<button type="button" id="agentic-attach-btn" class="agentic-attach-btn" title="<?php esc_attr_e( 'Attach image', 'agent-builder' ); ?>">
				<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m21.44 11.05-9.19 9.19a6 6 0 0 1-8.49-8.49l8.57-8.57A4 4 0 1 1 18 8.84l-8.59 8.57a2 2 0 0 1-2.83-2.83l8.49-8.48"/></svg>
			</button>
			<textarea 
				id="agentic-input" 
				class="agentic-chat-input" 
				placeholder="Ask <?php echo esc_attr( $agentic_current_agent->get_name() ); ?> a question..."
				rows="1"
			></textarea>
			<button type="button" id="agentic-voice-btn" class="agentic-voice-btn" title="<?php esc_attr_e( 'Voice input', 'agent-builder' ); ?>" style="display:none;">
				<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" x2="12" y1="19" y2="22"/></svg>
			</button>
			<button type="button" id="agentic-tts-btn" class="agentic-tts-btn" title="<?php esc_attr_e( 'Read aloud', 'agent-builder' ); ?>" style="display:none;">
				<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14"/></svg>
			</button>
			<button type="submit" class="agentic-send-btn" id="agentic-send">
				<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
					<line x1="22" x2="11" y1="2" y2="13"/>
					<polygon points="22 2 15 22 11 13 2 9 22 2"/>
				</svg>
			</button>
		</form>
	</div>
	<?php endif; ?>

	<?php
	$agentic_provider_labels = array(
		'openai'    => 'OpenAI',
		'anthropic' => 'Anthropic',
		'xai'       => 'xAI',
		'google'    => 'Google',
		'mistral'   => 'Mistral',
		'ollama'    => 'Ollama',
		'agentic'   => 'Agentic AI',
		'meta'      => 'Meta Llama',
		'cohere'    => 'Cohere',
	);
	$agentic_pm_provider     = get_option( 'agentic_llm_provider', 'agentic' );
	$agentic_pm_model        = get_option( 'agentic_model', '' );
	$agentic_pm_ov_provider  = \Agentic\Agent_Settings::get( $agentic_current_agent_id, 'override_provider' );
	$agentic_pm_ov_model     = \Agentic\Agent_Settings::get( $agentic_current_agent_id, 'override_model' );
	if ( ! empty( $agentic_pm_ov_provider ) ) {
		$agentic_pm_provider = $agentic_pm_ov_provider;
	}
	if ( ! empty( $agentic_pm_ov_model ) ) {
		$agentic_pm_model = $agentic_pm_ov_model;
	}
	$agentic_pm_label      = $agentic_provider_labels[ $agentic_pm_provider ] ?? ucfirst( $agentic_pm_provider );
	$agentic_show_branding = '1' !== get_option( 'agentic_chat_whitelabel', '0' );
	?>
	<div class="agentic-chat-footer">
		<?php if ( $agentic_show_branding ) : ?>
		<span class="agentic-footer-info">
			Powered by Agent Builder
			<?php
			if ( $agentic_pm_label ) :
				?>
				- <?php echo esc_html( $agentic_pm_label ); ?><?php endif; ?>
				<?php
				if ( $agentic_pm_model ) :
					?>
				- <?php echo esc_html( $agentic_pm_model ); ?><?php endif; ?>
		</span>
		<?php endif; ?>
		<span class="agentic-footer-stats" id="agentic-stats"></span>
	</div>
</div>


