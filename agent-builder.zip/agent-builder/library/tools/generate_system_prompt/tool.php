<?php
/**
 * Tool: generate_system_prompt
 *
 * @package    Agent_Builder
 * @subpackage Tools
 * @since      2.0.0
 *
 * php version 8.1
 */

declare(strict_types=1);

namespace Agentic\Tools;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Agentic\Tool_Base;

class Generate_System_Prompt extends Tool_Base {

	public function get_name(): string {
		return 'generate_system_prompt';
	}

	public function get_description(): string {
		return 'Generate a system prompt for an agent given its purpose.';
	}

	public function get_category(): string {
		return 'assistant-trainer';
	}

	public function get_risk_level(): string {
		return 'none';
	}

	public function get_annotations(): array {
		return array(
			'read_only'   => true,
			'destructive' => false,
		);
	}

	public function get_parameters(): array {
		return array(
			'agent_name'  => array(
				'type'        => 'string',
				'description' => 'Agent display name.',
				'required'    => true,
			),
			'purpose'     => array(
				'type'        => 'string',
				'description' => 'What the agent does.',
				'required'    => true,
			),
			'personality' => array(
				'type'        => 'string',
				'description' => 'Personality tone.',
				'required'    => false,
			),
			'constraints' => array(
				'type'        => 'array',
				'description' => 'Things the agent should never do.',
				'required'    => false,
			),
			'tool_names'  => array(
				'type'        => 'array',
				'description' => 'Names of available tools.',
				'required'    => false,
			),
		);
	}

	public function execute( array $args ): array {
		$agent_name  = $args['agent_name'] ?? '';
		$purpose     = $args['purpose'] ?? '';
		$personality = $args['personality'] ?? 'helpful and professional';
		$constraints = $args['constraints'] ?? array();
		$tool_names  = $args['tool_names'] ?? array();

		if ( empty( $agent_name ) || empty( $purpose ) ) {
			return array( 'error' => 'agent_name and purpose are required' );
		}

		$constraints_section = '';
		if ( ! empty( $constraints ) ) {
			$constraints_list    = array_map( fn( $c ) => "- {$c}", $constraints );
			$constraints_section = "\n\nYou should NEVER:\n" . implode( "\n", $constraints_list );
		}

		$tools_section = '';
		if ( ! empty( $tool_names ) ) {
			$tools_list    = array_map( fn( $t ) => "- {$t}", $tool_names );
			$tools_section = "\n\nYou have these tools available:\n" . implode( "\n", $tools_list );
		}

		$prompt = 'You are the ' . $agent_name . ' agent for WordPress. You are an expert in:' . "\n\n" .
			$purpose . "\n\n" .
			'Your personality: ' . $personality . "\n\n" .
			"When working:\n1. Always confirm destructive actions before executing\n2. Provide clear feedback on what you've done\n3. Suggest improvements when you notice issues\n4. Follow WordPress best practices\n5. Be concise but thorough in explanations" . $constraints_section . $tools_section;

		return array(
			'system_prompt' => $prompt,
			'agent_name'    => $agent_name,
			'char_count'    => strlen( $prompt ),
		);
	}
}

return new Generate_System_Prompt();
