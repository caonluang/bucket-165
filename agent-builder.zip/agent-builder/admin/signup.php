<?php
/**
 * Agentic AI sign-up page.
 *
 * Shown once after plugin activation. The user registers for a free
 * Agentic AI API key (which enables all built-in agents immediately)
 * and configures the essential settings for their installation.
 *
 * @package Agent_Builder
 * @since   2.9.8
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! current_user_can( 'manage_options' ) ) {
	wp_die( esc_html__( 'You do not have permission to access this page.', 'agent-builder' ) );
}

$agentic_signup_site_url = home_url();
$agentic_signup_name     = get_bloginfo( 'name' );
$agentic_signup_email    = get_option( 'admin_email', '' );
$agentic_signup_version  = AGENT_BUILDER_VERSION;
$agentic_signup_nonce    = wp_create_nonce( 'agentic_signup' );

// Pricing endpoint — used by JS to fetch live model lists.
$agentic_pricing_url = \Agentic\Service_Registry::url( 'agentic-api' ) . '/wp-json/agentic/v1/model-pricing';

// Static fallback model list rendered before the endpoint responds.
$agentic_fallback_llm_models = array(
	'gemini-2.5-flash'      => 'Gemini 2.5 Flash',
	'gemini-2.5-flash-lite' => 'Gemini 2.5 Flash Lite',
	'gemini-2.5-pro'        => 'Gemini 2.5 Pro',
);

$agentic_fallback_video_models = array(
	'veo-2' => 'Veo 2',
	'veo-3' => 'Veo 3',
);

$agentic_signup_tts_voices = array(
	'journey-f'  => 'Journey Female',
	'journey-d'  => 'Journey Male',
	'journey-o'  => 'Journey Neutral',
	'neural2-c'  => 'Neural2 Female',
	'neural2-d'  => 'Neural2 Male',
	'standard-f' => 'Standard Female',
	'standard-b' => 'Standard Male',
);
?>
<div class="agentic-signup-wrap">
	<div class="agentic-signup-card">
		<div class="agentic-logo">
			<img src="<?php echo esc_url( AGENT_BUILDER_URL . 'assets/icon.svg' ); ?>" alt="<?php esc_attr_e( 'Agent Builder', 'agent-builder' ); ?>">
			<span>Agent Builder</span>
		</div>

		<h1><?php esc_html_e( 'Connect to Agentic AI', 'agent-builder' ); ?></h1>
		<p class="subtitle">
			<?php esc_html_e( 'Set Agentic AI as your default LLM Provider and connect your AI agents with just one click — free daily credits, no payment info required.', 'agent-builder' ); ?>
		</p>

		<form id="agentic-signup-form" method="post">
			<input type="hidden" name="_wpnonce" value="<?php echo esc_attr( $agentic_signup_nonce ); ?>">
			<input type="hidden" name="plugin_version" value="<?php echo esc_attr( $agentic_signup_version ); ?>">

			<!-- ── Registration ─────────────────────────────── -->
			<h3 class="agentic-signup-section-heading"><?php esc_html_e( 'Registration', 'agent-builder' ); ?></h3>

			<div class="agentic-signup-field">
				<label for="agentic-signup-email"><?php esc_html_e( 'Email Address', 'agent-builder' ); ?></label>
				<input type="email" id="agentic-signup-email" name="email" value="<?php echo esc_attr( $agentic_signup_email ); ?>">
				<p class="agentic-field-note"><?php esc_html_e( 'Daily free credits and license key will be sent to this email address.', 'agent-builder' ); ?></p>
			</div>

			<div class="agentic-signup-field">
				<label for="agentic-signup-sitename"><?php esc_html_e( 'Site Name', 'agent-builder' ); ?></label>
				<input type="text" id="agentic-signup-sitename" name="site_name" value="<?php echo esc_attr( $agentic_signup_name ); ?>">
			</div>

			<div class="agentic-signup-field">
				<label for="agentic-signup-siteurl"><?php esc_html_e( 'Site URL', 'agent-builder' ); ?></label>
				<input type="url" id="agentic-signup-siteurl" name="site_url" value="<?php echo esc_attr( $agentic_signup_site_url ); ?>">
				<p class="agentic-field-note"><?php esc_html_e( 'Set this to the production domain you are registering for.', 'agent-builder' ); ?></p>
			</div>

			<!-- ── Configuration ────────────────────────────── -->
			<h3 class="agentic-signup-section-heading"><?php esc_html_e( 'Configuration', 'agent-builder' ); ?></h3>

			<div class="agentic-signup-field">
				<label for="agentic-signup-agent-mode"><?php esc_html_e( 'Security Mode', 'agent-builder' ); ?></label>
				<select id="agentic-signup-agent-mode" name="agent_mode">
					<option value="supervised" selected><?php esc_html_e( 'Supervised — Agent actions require approval (recommended)', 'agent-builder' ); ?></option>
					<option value="autonomous"><?php esc_html_e( 'Autonomous — agents act immediately without approval', 'agent-builder' ); ?></option>
					<option value="disabled"><?php esc_html_e( 'Disabled — chat only, no site actions or tool calling', 'agent-builder' ); ?></option>
				</select>
				<p class="agentic-field-note" id="agentic-mode-note">
					<?php esc_html_e( 'Agents propose actions which are queued for your review.', 'agent-builder' ); ?>
				</p>
			</div>

			<div class="agentic-signup-field">
				<label for="agentic-signup-model">
					<?php esc_html_e( 'Default Chat Model', 'agent-builder' ); ?>
					<span id="agentic-models-loading" class="agentic-model-loading-badge"><?php esc_html_e( 'Loading…', 'agent-builder' ); ?></span>
				</label>
				<select id="agentic-signup-model" name="chat_model">
					<?php foreach ( $agentic_fallback_llm_models as $agentic_m_id => $agentic_m_label ) : ?>
					<option value="<?php echo esc_attr( $agentic_m_id ); ?>"><?php echo esc_html( $agentic_m_label ); ?></option>
					<?php endforeach; ?>
				</select>
			</div>

			<div class="agentic-signup-field">
				<label for="agentic-signup-vision-model"><?php esc_html_e( 'Vision Model', 'agent-builder' ); ?></label>
				<select id="agentic-signup-vision-model" name="vision_model">
					<?php foreach ( $agentic_fallback_llm_models as $agentic_m_id => $agentic_m_label ) : ?>
					<option value="<?php echo esc_attr( $agentic_m_id ); ?>"><?php echo esc_html( $agentic_m_label ); ?></option>
					<?php endforeach; ?>
				</select>
				<p class="agentic-field-note"><?php esc_html_e( 'Used when users attach images to their messages.', 'agent-builder' ); ?></p>
			</div>

			<div class="agentic-signup-field">
				<label for="agentic-signup-tts-voice"><?php esc_html_e( 'Text-to-Speech Voice', 'agent-builder' ); ?></label>
				<select id="agentic-signup-tts-voice" name="tts_voice">
					<?php foreach ( $agentic_signup_tts_voices as $agentic_voice_id => $agentic_voice_label ) : ?>
					<option value="<?php echo esc_attr( $agentic_voice_id ); ?>"><?php echo esc_html( $agentic_voice_label ); ?></option>
					<?php endforeach; ?>
				</select>
				<p class="agentic-field-note"><?php esc_html_e( 'Neural voice used to read agent responses aloud.', 'agent-builder' ); ?></p>
			</div>

			<div class="agentic-signup-field">
				<label for="agentic-signup-video-model"><?php esc_html_e( 'Default Video Model', 'agent-builder' ); ?></label>
				<select id="agentic-signup-video-model" name="video_model">
					<?php foreach ( $agentic_fallback_video_models as $agentic_v_id => $agentic_v_label ) : ?>
					<option value="<?php echo esc_attr( $agentic_v_id ); ?>"><?php echo esc_html( $agentic_v_label ); ?></option>
					<?php endforeach; ?>
				</select>
				<p class="agentic-field-note"><?php esc_html_e( 'Used by the generate_video tool when no model is specified by the agent.', 'agent-builder' ); ?></p>
			</div>

			<!-- ── Consent ──────────────────────────────────── -->
			<div class="agentic-signup-consent">
				<label>
					<input type="checkbox" id="agentic-agree-terms" name="agree_terms" value="1">
					<?php
					printf(
						/* translators: 1: opening link tag, 2: closing link tag */
						esc_html__( 'I agree to the %1$sTerms & Conditions%2$s', 'agent-builder' ),
						'<a href="https://agentic-plugin.com/terms-of-service/" target="_blank" rel="noopener">',
						'</a>'
					);
					?>
				</label>
				<label>
					<input type="checkbox" id="agentic-agree-privacy" name="agree_privacy" value="1">
					<?php
					printf(
						/* translators: 1: opening link tag, 2: closing link tag */
						esc_html__( 'I agree to the %1$sPrivacy Policy%2$s', 'agent-builder' ),
						'<a href="https://agentic-plugin.com/privacy-policy/" target="_blank" rel="noopener">',
						'</a>'
					);
					?>
				</label>
			</div>

			<div class="agentic-signup-actions">
				<button type="submit" id="agentic-signup-btn" class="button button-primary">
					<?php esc_html_e( 'Register', 'agent-builder' ); ?>
				</button>
			</div>

			<div class="agentic-signup-msg" id="agentic-signup-msg"></div>
		</form>

		<div class="agentic-signup-skip">
			<?php
			printf(
				/* translators: 1: opening link tag, 2: closing link tag */
				esc_html__( '%1$sSkip — I will pay for tokens with my own LLM Provider.%2$s', 'agent-builder' ),
				'<a href="' . esc_url( admin_url( 'admin.php?page=agentic-setup' ) ) . '">',
				'</a>'
			);
			?>
			<br><small><?php esc_html_e( '(xAI, OpenAI, Anthropic etc.)', 'agent-builder' ); ?></small>
		</div>
	</div>

	<div class="agentic-signup-footer">
		<?php esc_html_e( 'Agent Builder supports multiple AI providers. You can add as many as you like later.', 'agent-builder' ); ?>
	</div>
</div>

<script>
(function () {
	var form        = document.getElementById( 'agentic-signup-form' );
	var btn         = document.getElementById( 'agentic-signup-btn' );
	var msgEl       = document.getElementById( 'agentic-signup-msg' );
	var terms       = document.getElementById( 'agentic-agree-terms' );
	var privacy     = document.getElementById( 'agentic-agree-privacy' );
	var modeSelect  = document.getElementById( 'agentic-signup-agent-mode' );
	var modeNote    = document.getElementById( 'agentic-mode-note' );
	var loadingBadge = document.getElementById( 'agentic-models-loading' );

	// ── Security mode descriptions ───────────────────────────────────────────

	var modeDescriptions = {
		supervised : <?php echo wp_json_encode( __( 'Agents propose actions which are queued for your review.', 'agent-builder' ) ); ?>,
		autonomous : '',
		disabled   : <?php echo wp_json_encode( __( 'Agents can only chat with users. Tools and skills are completely disabled.', 'agent-builder' ) ); ?>
	};

	modeSelect.addEventListener( 'change', function () {
		modeNote.textContent = modeDescriptions[ modeSelect.value ] || '';
	} );

	// ── Dynamic model lists from pricing endpoint ─────────────────────────────

	var pricingUrl = <?php echo wp_json_encode( $agentic_pricing_url ); ?>;

	// Human-readable labels for known LLM model IDs.
	var llmLabels = {
		'gemini-2.5-flash'      : 'Gemini 2.5 Flash — Fast & capable (recommended)',
		'gemini-2.5-flash-lite' : 'Gemini 2.5 Flash Lite — Fastest, most efficient',
		'gemini-2.5-pro'        : 'Gemini 2.5 Pro — Most powerful (higher credit usage)',
	};

	// Endpoint uses veo2/veo3 (no hyphen); tool expects veo-2/veo-3.
	var videoIdNormalise = { 'veo2': 'veo-2', 'veo3': 'veo-3' };
	var videoLabels = {
		'veo-2' : 'Veo 2 — 50 credits/sec usage, visual only (recommended)',
		'veo-3' : 'Veo 3 — 85 credits/sec usage, includes native audio',
	};

	function repopulateSelect( selectEl, options, defaultVal ) {
		var prev = selectEl.value;
		selectEl.innerHTML = '';
		options.forEach( function ( opt ) {
			var o = document.createElement( 'option' );
			o.value       = opt.value;
			o.textContent = opt.label;
			selectEl.appendChild( o );
		} );
		// Restore previous choice if still available, else use defaultVal.
		var ids    = options.map( function ( o ) { return o.value; } );
		selectEl.value = ids.indexOf( prev ) !== -1 ? prev
		               : ids.indexOf( defaultVal ) !== -1 ? defaultVal
		               : ( ids[0] || '' );
	}

	fetch( pricingUrl, { cache: 'no-store' } )
		.then( function ( r ) { return r.ok ? r.json() : Promise.reject( r.status ); } )
		.then( function ( data ) {
			// ── LLM models (chat + vision selects) ───────────────────────────
			var agenticModels = Object.keys( ( data.providers || {} ).agentic || {} );
			if ( agenticModels.length ) {
				var llmOptions = agenticModels.map( function ( id ) {
					return { value: id, label: llmLabels[ id ] || id };
				} );
				repopulateSelect(
					document.getElementById( 'agentic-signup-model' ),
					llmOptions,
					'gemini-2.5-flash'
				);
				repopulateSelect(
					document.getElementById( 'agentic-signup-vision-model' ),
					llmOptions,
					'gemini-2.5-flash'
				);
			}

			// ── Video models ─────────────────────────────────────────────────
			var videoOps = ( data.operations || {} ).video || {};
			var videoKeys = Object.keys( videoOps );
			if ( videoKeys.length ) {
				var videoOptions = videoKeys.map( function ( rawId ) {
					var normId = videoIdNormalise[ rawId ] || rawId;
					return { value: normId, label: videoLabels[ normId ] || normId };
				} );
				repopulateSelect(
					document.getElementById( 'agentic-signup-video-model' ),
					videoOptions,
					'veo-2'
				);
			}

			if ( loadingBadge ) {
				loadingBadge.style.display = 'none';
			}
		} )
		.catch( function () {
			// Endpoint unreachable — PHP fallbacks remain, badge hidden silently.
			if ( loadingBadge ) {
				loadingBadge.style.display = 'none';
			}
		} );

	// ── Form submission ───────────────────────────────────────────────────────

	form.addEventListener( 'submit', function ( e ) {
		e.preventDefault();
		msgEl.textContent = '';
		msgEl.className   = 'agentic-signup-msg';

		if ( ! terms.checked || ! privacy.checked ) {
			msgEl.textContent = <?php echo wp_json_encode( __( 'Please agree to the Terms & Conditions and Privacy Policy.', 'agent-builder' ) ); ?>;
			msgEl.className   = 'agentic-signup-msg error';
			return;
		}

		var email = document.getElementById( 'agentic-signup-email' ).value.trim();
		if ( ! email ) {
			msgEl.textContent = <?php echo wp_json_encode( __( 'Please enter your email address.', 'agent-builder' ) ); ?>;
			msgEl.className   = 'agentic-signup-msg error';
			return;
		}

		btn.disabled    = true;
		btn.textContent = <?php echo wp_json_encode( __( 'Registering…', 'agent-builder' ) ); ?>;

		fetch( ajaxurl, {
			method : 'POST',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
			body   : new URLSearchParams( {
				action        : 'agentic_signup_api_key',
				_ajax_nonce   : form.querySelector( '[name="_wpnonce"]' ).value,
				email         : email,
				site_name     : document.getElementById( 'agentic-signup-sitename' ).value.trim(),
				site_url      : document.getElementById( 'agentic-signup-siteurl' ).value.trim(),
				plugin_version: form.querySelector( '[name="plugin_version"]' ).value,
				agent_mode    : modeSelect.value,
				chat_model    : document.getElementById( 'agentic-signup-model' ).value,
				vision_model  : document.getElementById( 'agentic-signup-vision-model' ).value,
				tts_voice     : document.getElementById( 'agentic-signup-tts-voice' ).value,
				video_model   : document.getElementById( 'agentic-signup-video-model' ).value,
			} )
		} )
		.then( function ( r ) { return r.json(); } )
		.then( function ( data ) {
			if ( data.success ) {
				msgEl.textContent = <?php echo wp_json_encode( __( 'API key saved — redirecting…', 'agent-builder' ) ); ?>;
				msgEl.className   = 'agentic-signup-msg success';
				setTimeout( function () {
					window.location.href = <?php echo wp_json_encode( admin_url( 'admin.php?page=agentic-chat&agent=wordpress-assistant' ) ); ?>;
				}, 800 );
			} else {
				btn.disabled    = false;
				btn.textContent = <?php echo wp_json_encode( __( 'Get Free API Key', 'agent-builder' ) ); ?>;
				msgEl.textContent = ( data.data && data.data.message ) ? data.data.message : <?php echo wp_json_encode( __( 'Registration failed. Please try again.', 'agent-builder' ) ); ?>;
				msgEl.className   = 'agentic-signup-msg error';
			}
		} )
		.catch( function () {
			btn.disabled    = false;
			btn.textContent = <?php echo wp_json_encode( __( 'Get Free API Key', 'agent-builder' ) ); ?>;
			msgEl.textContent = <?php echo wp_json_encode( __( 'Connection error. Please try again.', 'agent-builder' ) ); ?>;
			msgEl.className   = 'agentic-signup-msg error';
		} );
	} );
}());
</script>
