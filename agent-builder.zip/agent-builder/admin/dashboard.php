<?php
/**
 * Agentic Admin Dashboard
 *
 * @package    Agent_Builder
 * @subpackage Admin
 * @author     Agent Builder Team <support@agentic-plugin.com>
 * @license    GPL-2.0-or-later https://www.gnu.org/licenses/gpl-2.0.html
 * @link       https://agentic-plugin.com
 * @since      0.1.0
 *
 * php version 8.1
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Agentic\Audit_Log;
use Agentic\Channels\WhatsApp_Channel;
use Agentic\LLM_Client;

if ( ! current_user_can( 'manage_options' ) ) {
	wp_die( esc_html__( 'You do not have permission to access this page.', 'agent-builder' ) );
}

\Agentic\Plugin::get_instance()->load_chat_components();

$agentic_audit         = new Audit_Log();
$agentic_stats         = $agentic_audit->get_stats( 'week' );
$agentic_llm           = new LLM_Client();
$agentic_is_configured = $agentic_llm->is_configured();
$agentic_provider      = $agentic_llm->get_provider();
$agentic_model         = $agentic_llm->get_model();

$agentic_registry_inst = \Agentic_Agent_Registry::get_instance();
$agentic_all_agents    = $agentic_registry_inst->get_installed_agents();

// Active count should reflect currently installed + active agents only.
$agentic_active_count = 0;
$agentic_active_slugs = $agentic_registry_inst->get_active_agents();
if ( is_array( $agentic_active_slugs ) ) {
	$agentic_active_slugs = array_unique( array_filter( array_map( 'sanitize_key', $agentic_active_slugs ) ) );
	foreach ( $agentic_active_slugs as $agentic_slug ) {
		if ( isset( $agentic_all_agents[ $agentic_slug ] ) ) {
			++$agentic_active_count;
		}
	}
}

// Split non-bundled agents into uploaded (.uploaded marker) vs user-created (no marker).
$agentic_uploaded_count     = 0;
$agentic_user_created_count = 0;
foreach ( $agentic_all_agents as $agentic_agent_info ) {
	if ( empty( $agentic_agent_info['bundled'] ) && ! empty( $agentic_agent_info['directory'] ) ) {
		if ( file_exists( $agentic_agent_info['directory'] . '/.uploaded' ) ) {
			++$agentic_uploaded_count;
		} else {
			++$agentic_user_created_count;
		}
	}
}

// Count community agents available in the marketplace (cached).
$agentic_community_count = get_transient( 'agentic_dashboard_marketplace_agent_count' );
if ( false === $agentic_community_count ) {
	$agentic_api_base = class_exists( '\\Agentic\\Service_Registry' )
		? \Agentic\Service_Registry::url( 'agentic-api' )
		: 'https://agentic-plugin.com';
	$agentic_response = wp_remote_get(
		trailingslashit( untrailingslashit( $agentic_api_base ) ) . 'wp-json/agentic/v1/agents?per_page=1',
		array(
			'timeout'   => 3,
			'sslverify' => true,
		)
	);
	if ( ! is_wp_error( $agentic_response ) ) {
		$agentic_body            = json_decode( wp_remote_retrieve_body( $agentic_response ), true );
		$agentic_community_count = isset( $agentic_body['total'] ) ? (int) $agentic_body['total'] : 0;
	}
	if ( ! is_numeric( $agentic_community_count ) ) {
		$agentic_community_count = 0;
	}
	set_transient( 'agentic_dashboard_marketplace_agent_count', (int) $agentic_community_count, HOUR_IN_SECONDS );
}

// Build list of all configured providers using the registry.
$agentic_all_keys             = get_option( 'agentic_llm_api_keys', array() );
$agentic_ollama_url           = get_option( 'agentic_ollama_url', '' );
$agentic_configured_providers = array();
foreach ( \Agentic\Provider_Registry::get_all() as $agentic_prov_entry ) {
	$agentic_prov_key = $agentic_prov_entry['slug'];
	if ( 'none' === $agentic_prov_entry['auth_type'] ) {
		// URL-based (Ollama) — configured when URL option is set.
		if ( ! empty( $agentic_ollama_url ) ) {
			$agentic_configured_providers[ $agentic_prov_key ] = $agentic_prov_entry['name'];
		}
	} elseif ( ! $agentic_prov_entry['requires_key'] || ! empty( $agentic_prov_entry['api_key'] ) ) {
		$agentic_configured_providers[ $agentic_prov_key ] = $agentic_prov_entry['name'];
	}
}

// Channel availability (provided by add-on when present via class detection).
$agentic_has_channels = class_exists( '\Agentic\Channels\WhatsApp_Channel' );

// Base shows the plugin's OSS license; add-on provides commercial license status UI when active.
$agentic_license_status  = 'free';
$agentic_license_display = 'GPL-2.0-or-later';
if ( \Agentic\License_Client::get_instance()->is_pro() ) {
	$agentic_license_display = '';
	$agentic_td_provider     = \Agentic\Provider_Registry::get( 'agentic' );
	if ( ! empty( $agentic_td_provider['api_key'] ) && class_exists( '\Agentic\License_Client' ) ) {
		$agentic_lc_instance    = \Agentic\License_Client::get_instance();
		$agentic_lc_status      = $agentic_lc_instance->get_status();
		$agentic_license_status = $agentic_lc_status['status'] ?? 'free';
		$agentic_tier           = $agentic_lc_status['type'] ?? 'free';

		switch ( $agentic_license_status ) {
			case 'active':
				$agentic_license_display = '<span class="agentic-status-active">● ' . ucfirst( $agentic_tier ) . '</span>';
				break;
			case 'grace_period':
				$agentic_license_display = '<span class="agentic-status-expiring">⚠ ' . ucfirst( $agentic_tier ) . ' (Expiring)</span>';
				break;
			case 'expired':
			case 'license_expired':
			case 'revoked':
			case 'license_revoked':
			case 'invalid':
			case 'invalid_key':
				$agentic_license_display = '<span class="agentic-status-error">✕ ' . ucfirst( str_replace( '_', ' ', $agentic_license_status ) ) . '</span> <a href="https://agentic-plugin.com/pricing/" target="_blank">Renew</a>';
				break;
			case 'free':
				$agentic_license_display = '<span class="agentic-status-active">● Free</span> <a href="https://agentic-plugin.com/pricing/" target="_blank" rel="noopener">Upgrade</a>';
				break;
			default:
				$agentic_license_display = ucfirst( $agentic_tier );
				break;
		}
	}
}

// Lightweight System Health (Item 4 P0 stabilization) — schema + job queue status.
$agentic_schema_version = get_option( 'agentic_db_schema_version', AGENT_BUILDER_DB_VERSION );
$agentic_job_health     = ( class_exists( '\Agentic\Job_Manager' ) && method_exists( '\Agentic\Job_Manager', 'get_health' ) ) ? \Agentic\Job_Manager::get_health() : array(
	'stats'             => array(
		'pending'    => 0,
		'processing' => 0,
	),
	'stuck_processing'  => 0,
	'abandoned_pending' => 0,
);
?>
<div class="wrap agentic-admin">
	<h1>
		<img src="<?php echo esc_url( AGENT_BUILDER_URL . 'assets/icon.svg' ); ?>" width="30" height="30" class="agentic-icon-sm" alt="<?php esc_attr_e( 'Agent Builder logo', 'agent-builder' ); ?>">
		Agent Builder
	</h1>

	<?php
	$agentic_nudge_dismissed = get_user_meta( get_current_user_id(), 'agentic_pro_nudge_dismissed', true );
	$agentic_show_nudge      = ! $agentic_nudge_dismissed
		&& isset( $agentic_license_status ) && 'free' === $agentic_license_status
		&& ! $agentic_has_channels;
	if ( $agentic_show_nudge ) :
		?>
	<div class="agentic-pro-nudge" id="agentic-pro-nudge">
		<span class="agentic-pro-nudge-text">
			<strong>Unlock Pro:</strong>
			Connect WhatsApp, Slack &amp; Email channels &mdash;
			download community contributed AI agents &mdash;
			remove all daily usage limits.
			<a href="https://agentic-plugin.com/pricing/" target="_blank" rel="noopener">See plans &rarr;</a>
		</span>
		<button type="button" class="agentic-pro-nudge-dismiss" id="agentic-pro-nudge-dismiss" title="Dismiss">&#x2715;</button>
	</div>
	<script>
	document.getElementById('agentic-pro-nudge-dismiss').addEventListener('click', function() {
		document.getElementById('agentic-pro-nudge').style.display = 'none';
		var xhr = new XMLHttpRequest();
		xhr.open('POST', ajaxurl);
		xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
		xhr.send('action=agentic_dismiss_pro_nudge&_ajax_nonce=<?php echo esc_js( wp_create_nonce( 'agentic_dismiss_pro_nudge' ) ); ?>');
	});
	</script>
	<?php endif; ?>

	<div class="agentic-dashboard-grid">
		<div class="agentic-card">
			<h2>Status</h2>
			<div class="agentic-status-grid">
				<?php if ( ! empty( $agentic_license_display ) ) : ?>
				<div class="agentic-status-item">
					<div class="agentic-status-label"><?php esc_html_e( 'License', 'agent-builder' ); ?></div>
					<div class="agentic-status-value"><?php echo wp_kses_post( $agentic_license_display ); ?></div>
				</div>
				<?php endif; ?>
				<div class="agentic-status-item">
					<div class="agentic-status-label">Version</div>
					<div class="agentic-status-value">
						<?php echo esc_html( AGENT_BUILDER_VERSION ); ?>
						<?php
						$agentic_show_update_script = false;
						$agentic_update_ui          = AGENT_BUILDER_DIR . 'includes/pro/dashboard-update-ui.php';
						if ( file_exists( $agentic_update_ui ) ) {
							include $agentic_update_ui;
						}
						?>
					</div>
				</div>
				<div class="agentic-status-item">
					<div class="agentic-status-label">Schema</div>
					<div class="agentic-status-value">
						<span class="agentic-status-active">●</span> <?php echo esc_html( $agentic_schema_version ); ?>
					</div>
				</div>
				<div class="agentic-status-item">
					<div class="agentic-status-label">Jobs</div>
					<div class="agentic-status-value">
						<?php
						$agentic_jh          = $agentic_job_health;
						$agentic_pending     = (int) ( $agentic_jh['stats']['pending'] ?? 0 );
						$agentic_processing  = (int) ( $agentic_jh['stats']['processing'] ?? 0 );
						$agentic_stuck       = (int) ( $agentic_jh['stuck_processing'] ?? 0 );
						$agentic_abandoned   = (int) ( $agentic_jh['abandoned_pending'] ?? 0 );
						$agentic_job_class   = ( $agentic_stuck > 0 || $agentic_abandoned > 0 ) ? 'agentic-status-error' : 'agentic-status-active';
						$agentic_job_summary = $agentic_pending . ' pending, ' . $agentic_processing . ' running';
						echo '<span class="' . esc_attr( $agentic_job_class ) . '">●</span> ' . esc_html( $agentic_job_summary );
						if ( $agentic_stuck > 0 ) {
							echo ' <span class="agentic-status-error">(' . (int) $agentic_stuck . ' stuck — auto-recovered)</span>';
						} elseif ( $agentic_abandoned > 0 ) {
							echo ' <span class="agentic-status-expiring">(' . (int) $agentic_abandoned . ' abandoned — auto-recovered)</span>';
						} else {
							echo ' <span class="agentic-text-muted">(healthy)</span>';
						}
						?>
					</div>
				</div>
			</div>
			<?php if ( ! empty( $agentic_show_update_script ) ) : ?>
			<script>
			jQuery(document).ready(function($) {
				$('#agentic-check-update').on('click', function() {
					var $btn = $(this), $result = $('#agentic-update-result');
					$btn.prop('disabled', true).text('Checking...');
					$result.text('');
					$.post(ajaxurl, {
						action: 'agentic_check_plugin_update',
						_ajax_nonce: '<?php echo esc_js( wp_create_nonce( 'agentic_check_update' ) ); ?>'
					}, function(resp) {
						$btn.prop('disabled', false).text('Check for Updates');
						if (resp.success) {
							var color = resp.data.status === 'update_available' ? '#dba617' : '#00a32a';
							$result.html('<span>' + resp.data.message + '</span>');
							if (resp.data.status === 'update_available') {
								$result.append(' <a href="<?php echo esc_url( admin_url( 'plugins.php' ) ); ?>">Go to Plugins</a>');
							}
						} else {
							$result.html('<span class="agentic-status-error">Check failed.</span>');
						}
					}).fail(function() {
						$btn.prop('disabled', false).text('Check for Updates');
						$result.html('<span class="agentic-status-error">Network error.</span>');
					});
				});
			});
			</script>
			<?php endif; ?>

		</div>

		<?php
		$agentic_da_asset_file = AGENT_BUILDER_DIR . 'build/dashboard-activity.asset.php';
		if ( file_exists( $agentic_da_asset_file ) ) {
			$agentic_da_asset = require $agentic_da_asset_file;
			wp_enqueue_script(
				'agentic-dashboard-activity',
				AGENT_BUILDER_URL . 'build/dashboard-activity.js',
				$agentic_da_asset['dependencies'],
				$agentic_da_asset['version'],
				true
			);
			wp_enqueue_style( 'wp-components' );
			wp_set_script_translations( 'agentic-dashboard-activity', 'agent-builder', AGENT_BUILDER_DIR . 'languages' );
			wp_localize_script(
				'agentic-dashboard-activity',
				'agenticDashboard',
				array(
					'adminUrl' => admin_url(),
					'isPro'    => \Agentic\License_Client::get_instance()->is_pro(),
				)
			);
		}
		$agentic_is_pro_dash = \Agentic\License_Client::get_instance()->is_pro();
		$agentic_usage_link  = $agentic_is_pro_dash
			? admin_url( 'admin.php?page=agentic-costs' )
			: admin_url( 'admin.php?page=agentic-audit-log' );
		$agentic_total_cost  = (float) ( $agentic_stats['total_cost'] ?? 0 );
		?>
		<div class="agentic-card" id="agentic-dashboard-activity-root">
			<?php // Server-rendered fallback (also the pre-hydration view); the React island replaces this with a live, period-aware version. ?>
			<h2>Weekly Statistics</h2>
			<div class="agentic-metrics-grid">
				<div class="agentic-metric">
					<div class="agentic-metric-value"><?php echo esc_html( number_format( (int) ( $agentic_stats['total_actions'] ?? 0 ) ) ); ?></div>
					<div class="agentic-metric-label"><a href="<?php echo esc_url( admin_url( 'admin.php?page=agentic-audit-log' ) ); ?>">Total Actions</a></div>
				</div>
				<div class="agentic-metric">
					<div class="agentic-metric-value"><?php echo esc_html( number_format( (int) ( $agentic_stats['total_tokens'] ?? 0 ) ) ); ?></div>
					<div class="agentic-metric-label"><a href="<?php echo esc_url( $agentic_usage_link ); ?>">Tokens Used</a></div>
				</div>
				<?php if ( $agentic_total_cost > 0 ) : ?>
				<div class="agentic-metric">
					<div class="agentic-metric-value">$<?php echo esc_html( number_format( $agentic_total_cost, 4 ) ); ?></div>
					<div class="agentic-metric-label"><a href="<?php echo esc_url( $agentic_usage_link ); ?>"><?php echo $agentic_is_pro_dash ? 'Est. Cost' : 'Estimated Usage'; ?></a></div>
				</div>
				<?php endif; ?>
				<div class="agentic-metric">
					<div class="agentic-metric-value"><?php echo esc_html( $agentic_active_count ); ?></div>
					<div class="agentic-metric-label"><a href="<?php echo esc_url( admin_url( 'admin.php?page=agentic-agents' ) ); ?>">Active Agents</a></div>
				</div>
				<div class="agentic-metric">
					<div class="agentic-metric-value"><?php echo esc_html( $agentic_uploaded_count ); ?></div>
					<div class="agentic-metric-label"><a href="<?php echo esc_url( admin_url( 'admin.php?page=agentic-agents' ) ); ?>">Uploaded Agents</a></div>
				</div>
				<div class="agentic-metric">
					<div class="agentic-metric-value"><?php echo esc_html( $agentic_user_created_count ); ?></div>
					<div class="agentic-metric-label"><a href="<?php echo esc_url( admin_url( 'admin.php?page=agentic-agents' ) ); ?>">User-Created Agents</a></div>
				</div>
				<div class="agentic-metric">
					<div class="agentic-metric-value"><?php echo esc_html( number_format_i18n( (int) $agentic_community_count ) ); ?></div>
					<div class="agentic-metric-label"><a href="https://agentic-plugin.com/community-agents/" target="_blank" rel="noopener noreferrer">Community Agents</a></div>
				</div>
			</div>
		</div>

		<div class="agentic-card">
			<h2>Connected Providers</h2>
			<?php if ( ! empty( $agentic_configured_providers ) ) : ?>
				<div class="agentic-provider-list">
					<?php foreach ( $agentic_configured_providers as $agentic_p_slug => $agentic_p_name ) : ?>
						<div class="agentic-provider-row<?php echo esc_attr( $agentic_p_slug === $agentic_provider ? ' agentic-provider-active' : '' ); ?>">
							<span class="agentic-provider-dot">●</span>
							<span class="agentic-provider-name"><?php echo esc_html( $agentic_p_name ); ?></span>
							<?php if ( $agentic_p_slug === $agentic_provider ) : ?>
								<span class="agentic-provider-badge">Default</span>
							<?php endif; ?>
						</div>
					<?php endforeach; ?>
				</div>
				<p class="agentic-mt-8 agentic-text-xs">
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=agentic-settings&tab=providers' ) ); ?>">Manage Providers</a>
				</p>
			<?php else : ?>
				<p class="agentic-mt-12">
					No AI providers connected. <a href="<?php echo esc_url( admin_url( 'admin.php?page=agentic-setup' ) ); ?>">Run the Setup Wizard</a> to get started.
				</p>
			<?php endif; ?>
		</div>

		<div class="agentic-card">
			<h2>Quick Actions</h2>
			<?php if ( ! $agentic_is_configured ) : ?>
				<p class="agentic-mb-12">
					<span class="dashicons dashicons-no-alt agentic-btn-danger agentic-icon-align"></span>
					Chatbot offline &mdash; <a href="<?php echo esc_url( admin_url( 'admin.php?page=agentic-settings' ) ); ?>">Configure now</a>
				</p>
			<?php endif; ?>
			<?php $agentic_wizard_done = get_option( 'agentic_onboarding_complete', false ); ?>
			<div class="agentic-quick-actions">
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=agentic-chat' ) ); ?>" class="button<?php echo $agentic_is_configured ? ' button-primary' : ''; ?>">Agent Chat</a>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=agentic-agent-wizard' ) ); ?>" class="button">Train an Agent</a>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=agentic-agents' ) ); ?>" class="button">Agents</a>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=agentic-train-data' ) ); ?>" class="button">Knowledge</a>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=agentic-setup' ) ); ?>" class="button<?php echo ! $agentic_wizard_done ? ' button-primary' : ''; ?>">Setup Wizard</a>
			</div>
			<?php if ( \Agentic\Admin_Menu_Handler::is_advanced_mode() ) : ?>
			<div class="agentic-quick-actions agentic-quick-actions-secondary agentic-mt-8">
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=agentic-approvals' ) ); ?>" class="button">Approvals</a>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=agentic-tools' ) ); ?>" class="button">Tools</a>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=agentic-skills' ) ); ?>" class="button">Skills</a>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=agentic-deployment' ) ); ?>" class="button">Publish</a>
				<?php if ( \Agentic\License_Client::get_instance()->is_pro() ) : ?>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=agentic-costs' ) ); ?>" class="button">Usage</a>
				<?php endif; ?>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=agentic-settings' ) ); ?>" class="button">Settings</a>
			</div>
			<?php endif; ?>
		</div>

		<?php if ( '0' !== get_option( 'agentic_show_onboarding', '1' ) ) : ?>
		<div class="agentic-card agentic-card-wide">
			<h2><?php esc_html_e( 'Getting Started', 'agent-builder' ); ?></h2>
			<?php
			$agentic_steps = array(
				array(
					'done'  => $agentic_is_configured,
					'label' => __( 'Connect an AI provider', 'agent-builder' ),
					'url'   => admin_url( 'admin.php?page=agentic-settings&tab=providers' ),
					'cta'   => __( 'Connect', 'agent-builder' ),
				),
				array(
					'done'  => $agentic_active_count > 0,
					'label' => __( 'Activate your first agent', 'agent-builder' ),
					'url'   => admin_url( 'admin.php?page=agentic-agents' ),
					'cta'   => __( 'Browse agents', 'agent-builder' ),
				),
				array(
					'done'  => (bool) get_option( 'agentic_has_knowledge', false ),
					'label' => __( 'Add knowledge (optional)', 'agent-builder' ),
					'url'   => admin_url( 'admin.php?page=agentic-train-data' ),
					'cta'   => __( 'Add knowledge', 'agent-builder' ),
				),
				array(
					'done'  => (int) ( $agentic_stats['total_actions'] ?? 0 ) > 0,
					'label' => __( 'Start a conversation', 'agent-builder' ),
					'url'   => admin_url( 'admin.php?page=agentic-chat' ),
					'cta'   => __( 'Open chat', 'agent-builder' ),
				),
			);
			$agentic_done_count = count( array_filter( wp_list_pluck( $agentic_steps, 'done' ) ) );
			?>
			<p class="agentic-text-muted agentic-mb-12">
				<?php
				echo esc_html(
					sprintf(
						/* translators: 1: completed step count, 2: total step count */
						__( '%1$d of %2$d steps complete', 'agent-builder' ),
						$agentic_done_count,
						count( $agentic_steps )
					)
				);
				?>
			</p>
			<ul class="agentic-onboarding-list">
				<?php foreach ( $agentic_steps as $agentic_step ) : ?>
				<li class="agentic-onboarding-item<?php echo $agentic_step['done'] ? ' is-done' : ''; ?>">
					<span class="agentic-onboarding-check dashicons <?php echo $agentic_step['done'] ? 'dashicons-yes-alt' : 'dashicons-marker'; ?>"></span>
					<span class="agentic-onboarding-label"><?php echo esc_html( $agentic_step['label'] ); ?></span>
					<?php if ( ! $agentic_step['done'] ) : ?>
					<a href="<?php echo esc_url( $agentic_step['url'] ); ?>" class="button button-small"><?php echo esc_html( $agentic_step['cta'] ); ?></a>
					<?php endif; ?>
				</li>
				<?php endforeach; ?>
			</ul>
		</div>
		<?php endif; ?>

		<div class="agentic-card agentic-card-wide agentic-mode-card">
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="agentic-mode-toggle">
				<?php wp_nonce_field( 'agentic_set_ui_mode' ); ?>
				<input type="hidden" name="action" value="agentic_set_ui_mode" />
				<span class="agentic-mode-label"><?php esc_html_e( 'Interface:', 'agent-builder' ); ?></span>
				<?php $agentic_mode_now = \Agentic\Admin_Menu_Handler::is_advanced_mode() ? 'advanced' : 'basic'; ?>
				<button type="submit" name="agentic_ui_mode" value="basic" class="button<?php echo 'basic' === $agentic_mode_now ? ' button-primary' : ''; ?>"><?php esc_html_e( 'Basic', 'agent-builder' ); ?></button>
				<button type="submit" name="agentic_ui_mode" value="advanced" class="button<?php echo 'advanced' === $agentic_mode_now ? ' button-primary' : ''; ?>"><?php esc_html_e( 'Advanced', 'agent-builder' ); ?></button>
				<span class="agentic-mode-hint agentic-text-muted"><?php esc_html_e( 'Advanced reveals developer tools (Skills, APIs, Endpoints).', 'agent-builder' ); ?></span>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=agentic-settings&tab=interface' ) ); ?>" class="agentic-mode-more agentic-text-muted"><?php esc_html_e( 'More interface settings →', 'agent-builder' ); ?></a>
			</form>
		</div>
	</div>
</div>
