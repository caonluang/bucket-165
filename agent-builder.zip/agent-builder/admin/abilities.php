<?php
/**
 * Admin page: Abilities (F3 productized bridge).
 *
 * Shows:
 * - Outbound: Agent Builder tools registered as WP Abilities (for MCP, Command Palette, other plugins).
 * - Inbound: Third-party WP Abilities available as tools to our agents.
 *
 * @package Agent_Builder
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$agentic_bridge = null;
if ( class_exists( '\Agentic\Abilities_Bridge' ) ) {
	$agentic_bridge = new \Agentic\Abilities_Bridge();
}

$agentic_has_api = function_exists( 'wp_get_abilities' ) && function_exists( 'wp_register_ability' );
?>
<div class="wrap">
	<h1><?php esc_html_e( 'WordPress Abilities', 'agent-builder' ); ?></h1>

	<?php if ( $agentic_has_api ) : ?>
		<div class="notice notice-success">
			<p>
				<?php esc_html_e( 'Connected to WordPress Abilities API (native). Agent Builder acts as the orchestration, approval, audit, and multi-agent layer on top — the cockpit over core AI.', 'agent-builder' ); ?>
				<?php if ( function_exists( 'wp_ai_client_prompt' ) ) : ?>
					<?php esc_html_e( 'Native AI Client + Connectors also detected.', 'agent-builder' ); ?>
				<?php endif; ?>
			</p>
		</div>
	<?php else : ?>
		<div class="notice notice-warning">
			<p>
				<?php
				/* translators: WP version */
				printf(
					esc_html__( 'The WordPress Abilities API is available on WordPress 6.9+. You are on %s. Agent Builder provides the full bridge and tools today; upgrade to unlock native discovery in Command Palette / REST / MCP.', 'agent-builder' ),
					esc_html( get_bloginfo( 'version' ) )
				);
				?>
			</p>
		</div>
	<?php endif; ?>

	<p class="description">
		<?php esc_html_e( 'Agent Builder exposes its tools as native WordPress Abilities (outbound) and can consume Abilities registered by other plugins/themes (inbound). This is the foundation of the WordPress 7 AI bridge.', 'agent-builder' ); ?>
	</p>

	<h2><?php esc_html_e( 'Outbound — Agent Builder tools as Abilities', 'agent-builder' ); ?></h2>
	<?php
	$agentic_outbound = array();
	if ( $agentic_bridge && method_exists( $agentic_bridge, 'get_outbound_ability_names' ) ) {
		// If bridge exposes, use it; else fall back to scanning registered.
	}
	if ( $agentic_has_api ) {
		// phpcs:ignore WordPress.WP.Functions, WordPress.WP.Capabilities -- guarded by function_exists check for WP >=6.9; min supported is 6.4 with bridge
		$agentic_all = wp_get_abilities();
		foreach ( $agentic_all as $agentic_ability ) {
			if ( 0 === strpos( $agentic_ability->get_name(), 'agent-builder/' ) ) {
				$agentic_outbound[] = array(
					'name'        => $agentic_ability->get_name(),
					'label'       => $agentic_ability->get_label(),
					'description' => $agentic_ability->get_description(),
					'category'    => $agentic_ability->get_category(),
				);
			}
		}
	} else {
		// Fallback: list from our tool loader (approximate).
		$agentic_loader = \Agentic\Tool_Loader::get_instance();
		$agentic_loader->load();
		foreach ( $agentic_loader->get_all() as $agentic_name => $agentic_tool ) {
			$agentic_outbound[] = array(
				'name'        => 'agent-builder/' . str_replace( '_', '-', $agentic_name ),
				'label'       => ucwords( str_replace( '_', ' ', $agentic_name ) ),
				'description' => $agentic_tool->get_description(),
				'category'    => 'agent-builder',
			);
		}
	}
	?>
	<table class="widefat striped">
		<thead>
			<tr>
				<th><?php esc_html_e( 'Name', 'agent-builder' ); ?></th>
				<th><?php esc_html_e( 'Label', 'agent-builder' ); ?></th>
				<th><?php esc_html_e( 'Description', 'agent-builder' ); ?></th>
			</tr>
		</thead>
		<tbody>
		<?php if ( empty( $agentic_outbound ) ) : ?>
			<tr><td colspan="3"><?php esc_html_e( 'No outbound abilities registered yet (or WP < 6.9).', 'agent-builder' ); ?></td></tr>
		<?php else : ?>
			<?php foreach ( $agentic_outbound as $agentic_o ) : ?>
				<tr>
					<td><code><?php echo esc_html( $agentic_o['name'] ); ?></code></td>
					<td><?php echo esc_html( $agentic_o['label'] ); ?></td>
					<td><?php echo esc_html( $agentic_o['description'] ); ?></td>
				</tr>
			<?php endforeach; ?>
		<?php endif; ?>
		</tbody>
	</table>

	<h2><?php esc_html_e( 'Inbound — Third-party Abilities available to agents', 'agent-builder' ); ?></h2>
	<?php
	$agentic_inbound = array();
	if ( $agentic_has_api && $agentic_bridge && method_exists( $agentic_bridge, 'get_third_party_abilities_as_tools' ) ) {
		$agentic_tools = $agentic_bridge->get_third_party_abilities_as_tools();
		foreach ( $agentic_tools as $agentic_t ) {
			$agentic_inbound[] = array(
				'name'        => $agentic_t['_ability_name'] ?? ( $agentic_t['function']['name'] ?? '' ),
				'description' => $agentic_t['function']['description'] ?? '',
			);
		}
	}
	?>
	<table class="widefat striped">
		<thead>
			<tr>
				<th><?php esc_html_e( 'Ability Name', 'agent-builder' ); ?></th>
				<th><?php esc_html_e( 'Description', 'agent-builder' ); ?></th>
			</tr>
		</thead>
		<tbody>
		<?php if ( empty( $agentic_inbound ) ) : ?>
			<tr><td colspan="2"><?php esc_html_e( 'No third-party abilities detected. Install abilities-aware plugins to expand your agents automatically.', 'agent-builder' ); ?></td></tr>
		<?php else : ?>
			<?php foreach ( $agentic_inbound as $agentic_i ) : ?>
				<tr>
					<td><code><?php echo esc_html( $agentic_i['name'] ); ?></code></td>
					<td><?php echo esc_html( $agentic_i['description'] ); ?></td>
				</tr>
			<?php endforeach; ?>
		<?php endif; ?>
		</tbody>
	</table>

	<p class="description">
		<?php
		esc_html_e( 'On WordPress 7+ with the core AI Client and Connectors configured, these abilities become available to any MCP client or the native AI surface. Agent Builder remains the orchestration, approval, and audit layer on top.', 'agent-builder' );
		?>
	</p>
</div>
