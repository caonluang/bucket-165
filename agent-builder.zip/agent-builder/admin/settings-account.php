<?php
/**
 * Settings — Account Tab (read-only)
 *
 * Shows the plan/license status and which AI providers are connected. This is a
 * READ-ONLY view: it never renders, localizes, or logs a raw API key — only a
 * boolean "configured" state and a masked last-4 hint derived server-side.
 *
 * Pro extends this view via the `agentic_after_account_tab` action to list the
 * WordPress application passwords used by its MCP connectors.
 *
 * @package    Agent_Builder
 * @subpackage Admin/Settings
 * @since      2.16.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! current_user_can( 'manage_options' ) ) {
	return;
}

/**
 * Mask a secret to a non-reversible hint (last 4 characters only).
 *
 * @param string $secret Raw secret (never echoed).
 * @return string e.g. "••••1a2b", or '' when empty.
 */
$agentic_mask_secret = static function ( string $secret ): string {
	$secret = trim( $secret );
	if ( '' === $secret ) {
		return '';
	}
	$last4 = substr( $secret, -4 );
	return '••••' . $last4;
};

// ── License / plan status ──────────────────────────────────────────────
$agentic_is_pro       = false;
$agentic_license_text = __( 'Free', 'agent-builder' );
$agentic_license_note = __( 'You are using the free Agent Builder plugin.', 'agent-builder' );
$agentic_license_key  = '';

if ( class_exists( '\Agentic\License_Client' ) ) {
	$agentic_lc     = \Agentic\License_Client::get_instance();
	$agentic_is_pro = $agentic_lc->is_pro();
	$agentic_status = $agentic_lc->get_status();

	if ( $agentic_is_pro ) {
		$agentic_type         = $agentic_lc->get_type();
		$agentic_license_text = '' !== $agentic_type && 'free' !== $agentic_type
			? ucfirst( $agentic_type )
			: __( 'Pro', 'agent-builder' );
		$agentic_license_note = ! empty( $agentic_status['message'] )
			? (string) $agentic_status['message']
			: __( 'Pro features are active on this site.', 'agent-builder' );
		// get_status() already masks the key for us.
		$agentic_license_key = (string) ( $agentic_status['license_key'] ?? '' );
	}
}

// ── Provider connection status (derived; raw keys never leave the server) ─
$agentic_provider_rows = array();
if ( class_exists( '\Agentic\Provider_Registry' ) ) {
	foreach ( \Agentic\Provider_Registry::get_all() as $agentic_p ) {
		$agentic_requires = ! empty( $agentic_p['requires_key'] );
		$agentic_has_key  = '' !== trim( (string) ( $agentic_p['api_key'] ?? '' ) );

		if ( ! $agentic_requires ) {
			$agentic_state = 'none_needed';
			$agentic_hint  = '';
		} elseif ( $agentic_has_key ) {
			$agentic_state = 'connected';
			$agentic_hint  = $agentic_mask_secret( (string) $agentic_p['api_key'] );
		} else {
			$agentic_state = 'missing';
			$agentic_hint  = '';
		}

		$agentic_provider_rows[] = array(
			'name'  => (string) ( $agentic_p['name'] ?? $agentic_p['slug'] ?? '' ),
			'state' => $agentic_state,
			'hint'  => $agentic_hint,
		);
	}
}
?>

<h2 class="agentic-settings-h2"><?php esc_html_e( 'Plan', 'agent-builder' ); ?></h2>
<table class="form-table" role="presentation">
	<tr>
		<th scope="row"><?php esc_html_e( 'Current plan', 'agent-builder' ); ?></th>
		<td>
			<span class="agentic-account-badge <?php echo $agentic_is_pro ? 'is-pro' : 'is-free'; ?>">
				<?php echo esc_html( $agentic_license_text ); ?>
			</span>
			<p class="description"><?php echo esc_html( $agentic_license_note ); ?></p>
		</td>
	</tr>
	<?php if ( $agentic_is_pro && '' !== $agentic_license_key ) : ?>
	<tr>
		<th scope="row"><?php esc_html_e( 'License key', 'agent-builder' ); ?></th>
		<td><code><?php echo esc_html( $agentic_license_key ); ?></code></td>
	</tr>
	<?php endif; ?>
	<?php if ( ! $agentic_is_pro ) : ?>
	<tr>
		<th scope="row"><?php esc_html_e( 'Upgrade', 'agent-builder' ); ?></th>
		<td>
			<a class="button button-secondary" href="https://agentwp.com/pro/" target="_blank" rel="noopener noreferrer">
				<?php esc_html_e( 'Explore Agent Builder Pro', 'agent-builder' ); ?>
			</a>
			<p class="description"><?php esc_html_e( 'Workflows, channels, governance, observability and more.', 'agent-builder' ); ?></p>
		</td>
	</tr>
	<?php endif; ?>
</table>

<h2 class="agentic-settings-h2"><?php esc_html_e( 'AI provider connections', 'agent-builder' ); ?></h2>
<p>
	<?php esc_html_e( 'Which AI providers have an API key configured. Keys are encrypted and never shown in full.', 'agent-builder' ); ?>
	<a href="<?php echo esc_url( admin_url( 'admin.php?page=agentic-settings&tab=providers' ) ); ?>"><?php esc_html_e( 'Manage providers →', 'agent-builder' ); ?></a>
</p>

<?php if ( empty( $agentic_provider_rows ) ) : ?>
	<p class="description"><?php esc_html_e( 'No AI providers are configured yet.', 'agent-builder' ); ?></p>
<?php else : ?>
<table class="widefat striped agentic-account-providers">
	<thead>
		<tr>
			<th scope="col"><?php esc_html_e( 'Provider', 'agent-builder' ); ?></th>
			<th scope="col"><?php esc_html_e( 'Status', 'agent-builder' ); ?></th>
			<th scope="col"><?php esc_html_e( 'Key', 'agent-builder' ); ?></th>
		</tr>
	</thead>
	<tbody>
		<?php foreach ( $agentic_provider_rows as $agentic_row ) : ?>
			<tr>
				<td><?php echo esc_html( $agentic_row['name'] ); ?></td>
				<td>
					<?php if ( 'connected' === $agentic_row['state'] ) : ?>
						<span class="agentic-account-status is-ok"><?php esc_html_e( 'Connected', 'agent-builder' ); ?></span>
					<?php elseif ( 'none_needed' === $agentic_row['state'] ) : ?>
						<span class="agentic-account-status is-neutral"><?php esc_html_e( 'No key needed', 'agent-builder' ); ?></span>
					<?php else : ?>
						<span class="agentic-account-status is-warn"><?php esc_html_e( 'Not configured', 'agent-builder' ); ?></span>
					<?php endif; ?>
				</td>
				<td>
					<?php if ( '' !== $agentic_row['hint'] ) : ?>
						<code><?php echo esc_html( $agentic_row['hint'] ); ?></code>
					<?php else : ?>
						<span aria-hidden="true">—</span>
					<?php endif; ?>
				</td>
			</tr>
		<?php endforeach; ?>
	</tbody>
</table>
<?php endif; ?>

<?php
/**
 * Allow Pro to append account information (e.g. MCP connector credentials /
 * WordPress application passwords) below the free account view.
 *
 * @since 2.16.0
 */
do_action( 'agentic_after_account_tab' );
