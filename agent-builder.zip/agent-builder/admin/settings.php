<?php
/**
 * Agentic Settings Page
 *
 * @package    Agent_Builder
 * @subpackage Admin
 * @author     Agent Builder Team <support@agentic-plugin.com>
 * @license    GPL-2.0-or-later https://www.gnu.org/licenses/gpl-2.0.html
 * @link       https://agentic-plugin.com
 * @since      0.1.0
 *
 * php version 8.1
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Handle form submission.
if ( ! current_user_can( 'manage_options' ) ) {
	wp_die( esc_html__( 'You do not have permission to access this page.', 'agent-builder' ) );
}

\Agentic\Plugin::get_instance()->load_chat_components();

// Handle third-party API key save/delete (PRG pattern — redirect after action).
if ( isset( $_POST['agentic_api_action'] ) && check_admin_referer( 'agentic_api_key_nonce' ) ) {
	$agentic_api_action      = sanitize_key( wp_unslash( $_POST['agentic_api_action'] ) );
	$agentic_api_slug        = sanitize_key( wp_unslash( $_POST['agentic_api_slug'] ?? '' ) );
	$agentic_api_audit_acted = false;

	// Map slug → option key (whitelist approach).
	$agentic_api_option_map = array(
		'google_psi' => 'agentic_psi_api_key',
	);

	if ( isset( $agentic_api_option_map[ $agentic_api_slug ] ) ) {
		$agentic_api_option = $agentic_api_option_map[ $agentic_api_slug ];

		if ( 'save' === $agentic_api_action ) {
			$agentic_api_key_val_raw = sanitize_text_field( wp_unslash( $_POST['agentic_api_key_value'] ?? '' ) );
			if ( ! empty( $agentic_api_key_val_raw ) ) {
				update_option( $agentic_api_option, $agentic_api_key_val_raw );
				delete_option( 'agentic_psi_notice_dismissed' );
				$agentic_api_audit_acted = true;
			}
		} elseif ( 'delete' === $agentic_api_action ) {
			delete_option( $agentic_api_option );
			$agentic_api_audit_acted = true;
		}
	}

	if ( $agentic_api_audit_acted ) {
		\Agentic\Security_Log::log_system(
			'settings_changed',
			'api_keys',
			array(
				'setting' => 'api_key_' . $agentic_api_action,
				'changes' => array(
					'api_slug' => $agentic_api_slug,
					'action'   => $agentic_api_action,
				),
			)
		);
	}

	wp_safe_redirect( admin_url( 'admin.php?page=agentic-settings&tab=apis&saved=1' ) );
	exit;
}

// Handle Provider CRUD actions (PRG pattern — redirect after save/delete).
if ( isset( $_POST['agentic_provider_action'] ) && check_admin_referer( 'agentic_provider_nonce' ) ) {
	$agentic_prov_action = sanitize_key( wp_unslash( $_POST['agentic_provider_action'] ?? '' ) );

	if ( 'save' === $agentic_prov_action ) {
		$agentic_prov_slug       = sanitize_key( wp_unslash( $_POST['provider_slug'] ?? '' ) );
		$agentic_prov_auth_type  = sanitize_key( wp_unslash( $_POST['provider_auth_type'] ?? 'bearer' ) );
		$agentic_prov_req_format = sanitize_key( wp_unslash( $_POST['provider_req_format'] ?? 'openai' ) );

		$agentic_prov_models_raw = sanitize_textarea_field( wp_unslash( $_POST['provider_models'] ?? '' ) );
		$agentic_prov_models     = array_values(
			array_filter(
				array_map( 'trim', explode( "\n", $agentic_prov_models_raw ) )
			)
		);

		\Agentic\Provider_Registry::upsert(
			array(
				'slug'          => $agentic_prov_slug,
				'name'          => sanitize_text_field( wp_unslash( $_POST['provider_name'] ?? '' ) ),
				'endpoint'      => sanitize_text_field( wp_unslash( $_POST['provider_endpoint'] ?? '' ) ),
				'default_model' => sanitize_text_field( wp_unslash( $_POST['provider_default_model'] ?? '' ) ),
				'auth_type'     => $agentic_prov_auth_type,
				'req_format'    => $agentic_prov_req_format,
				'resp_format'   => sanitize_key( wp_unslash( $_POST['provider_resp_format'] ?? 'openai' ) ),
				'api_key'       => sanitize_text_field( wp_unslash( $_POST['provider_api_key'] ?? '' ) ),
				'key_url'       => sanitize_text_field( wp_unslash( $_POST['provider_key_url'] ?? '' ) ),
				'icon'          => sanitize_text_field( wp_unslash( $_POST['provider_icon'] ?? '' ) ),
				'models'        => $agentic_prov_models,
				'vision_model'  => sanitize_text_field( wp_unslash( $_POST['provider_vision_model'] ?? '' ) ),
				'requires_key'  => 'none' !== $agentic_prov_auth_type,
				'sort_order'    => absint( wp_unslash( $_POST['provider_sort_order'] ?? 99 ) ),
			)
		);
	} elseif ( 'delete' === $agentic_prov_action ) {
		$agentic_prov_slug = sanitize_key( wp_unslash( $_POST['provider_slug'] ?? '' ) );
		\Agentic\Provider_Registry::delete( $agentic_prov_slug );
	} elseif ( 'set_default' === $agentic_prov_action ) {
		$agentic_prov_slug = sanitize_key( wp_unslash( $_POST['provider_slug'] ?? '' ) );
		if ( \Agentic\Provider_Registry::is_valid( $agentic_prov_slug ) ) {
			$agentic_def_entry = \Agentic\Provider_Registry::get( $agentic_prov_slug );
			update_option( 'agentic_llm_provider', $agentic_prov_slug );
			update_option( 'agentic_model', $agentic_def_entry['default_model'] ?? '' );
		}
	}

	\Agentic\Security_Log::log_system(
		'settings_changed',
		'providers',
		array(
			'setting' => 'provider_' . $agentic_prov_action,
			'changes' => array(
				'provider_slug' => $agentic_prov_slug,
				'action'        => $agentic_prov_action,
			),
		)
	);

	wp_safe_redirect( admin_url( 'admin.php?page=agentic-settings&tab=providers&saved=1' ) );
	exit;
}

if ( isset( $_POST['agentic_save_settings'] ) && check_admin_referer( 'agentic_settings_nonce' ) ) {
	$agentic_save_tab      = sanitize_text_field( wp_unslash( $_POST['tab'] ?? 'agents' ) );
	$agentic_reset_section = sanitize_key( wp_unslash( $_POST['agentic_reset_section'] ?? '' ) );

	// ── Reset to Defaults ────────────────────────────────────────────────────
	if ( '' !== $agentic_reset_section ) {
		$agentic_reset_defaults = array(
			'agents_llm'      => array( // Reset global provider to Agentic AI and clear per-agent overrides.
				'handler' => static function () {
					global $wpdb;
					// Reset global provider to Agentic AI (fresh-install default).
					$agentic_prov  = \Agentic\Provider_Registry::get( 'agentic' );
					$default_model = $agentic_prov['default_model'] ?? 'gemini-2.5-flash';
					update_option( 'agentic_llm_provider', 'agentic' );
					update_option( 'agentic_model', $default_model );
					delete_option( 'agentic_vision_model' );
					// Clear per-agent provider/model/mode overrides from agent_settings table.
					$agentic_llm_keys = array( 'override_provider', 'override_model', 'override_vision_model', 'override_mode', 'weak_model_tool_guidance', 'max_tool_retries' );
					foreach ( $agentic_llm_keys as $agentic_ok ) {
						// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- custom indexed table
						$wpdb->delete( $wpdb->prefix . 'agentic_agent_settings', array( 'meta_key' => $agentic_ok ), array( '%s' ) );
					}
					\Agentic\Agent_Settings::bust_cache();
				},
			),
			'agents_features' => array( // Clear per-agent chat feature overrides.
				'handler' => static function () {
					global $wpdb;
					$agentic_feat_keys = array( 'override_audio', 'override_tts', 'override_vision', 'override_costs', 'override_cache' );
					foreach ( $agentic_feat_keys as $agentic_ok ) {
						// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- custom indexed table
						$wpdb->delete( $wpdb->prefix . 'agentic_agent_settings', array( 'meta_key' => $agentic_ok ), array( '%s' ) );
					}
					\Agentic\Agent_Settings::bust_cache();
				},
			),
			'styles_chat'     => array( // Global chat settings defaults.
				'handler' => static function () {
					update_option( 'agentic_chat_audio', '1' );
					update_option( 'agentic_chat_tts', '1' );
					update_option( 'agentic_chat_vision', '1' );
					if ( defined( 'AGENTIC_PRO' ) && AGENTIC_PRO ) {
						update_option( 'agentic_chat_costs', '1' );
						update_option( 'agentic_chat_whitelabel', '1' );
					}
					update_option( 'agentic_response_cache_enabled', true );
					update_option( 'agentic_response_cache_ttl', 3600 );
				},
			),
			'styles_theme'    => array( // Theme default.
				'handler' => static function () {
					update_option( 'agentic_chat_theme', 'dark' );
				},
			),
			'security'        => array( // Security tab defaults.
				'handler' => static function () {
					update_option( 'agentic_agent_mode', 'supervised' );
					update_option( 'agentic_security_enabled', true );
					update_option( 'agentic_turnstile_site_key', '' );
					update_option( 'agentic_turnstile_secret_key', '' );
					update_option( 'agentic_turnstile_require_anonymous', true );
					update_option( 'agentic_turnstile_require_all', false );
					update_option( 'agentic_ip_anonymize', true );
					update_option( 'agentic_retention_conversations', 30 );
					update_option( 'agentic_retention_audit_log', 30 );
					update_option( 'agentic_chat_consent_enabled', false );
					update_option( 'agentic_chat_consent_text', 'By chatting you agree to your messages being processed by an AI. We do not share your data with third parties.' );
				},
			),
			'users'           => array( // Users tab defaults.
				'handler' => static function () {
					update_option( 'agentic_allow_anonymous_chat', false );
					update_option( 'agentic_rate_limit_authenticated', 30 );
					update_option( 'agentic_rate_limit_anonymous', 10 );
					update_option( \Agentic\Usage_Limits::OPTION_KEY, \Agentic\Usage_Limits::get_install_defaults() );
					delete_option( \Agentic\User_Roles::OPTION_KEY ); // Reverts to computed defaults.
				},
			),
			'personas'        => array( // Clear all persona customisations.
				'handler' => static function () {
					global $wpdb;
					$agentic_persona_keys = array( 'persona_welcome_message', 'persona_notes', 'persona_response_style', 'persona_suggested_prompts' );
					foreach ( $agentic_persona_keys as $agentic_pk ) {
						// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- custom indexed table
						$wpdb->delete( $wpdb->prefix . 'agentic_agent_settings', array( 'meta_key' => $agentic_pk ), array( '%s' ) );
					}
					\Agentic\Agent_Settings::bust_cache();
				},
			),
		);

		if ( isset( $agentic_reset_defaults[ $agentic_reset_section ] ) ) {
			$agentic_reset_defaults[ $agentic_reset_section ]['handler']();
			\Agentic\Security_Log::log_system( 'settings_changed', 'reset_defaults', array( 'section' => $agentic_reset_section ) );
			echo '<div class="notice notice-success"><p>' . esc_html__( 'Settings reset to defaults.', 'agent-builder' ) . '</p></div>';
		}
	}

	// Only save settings for the active tab to avoid overwriting other tabs with defaults.
	if ( '' === $agentic_reset_section && 'agents' === $agentic_save_tab ) {
		// Save per-agent overrides (provider, model, mode per agent slug).
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Each field is sanitized individually in the foreach loop below.
		$agentic_raw_overrides   = isset( $_POST['agentic_agent_overrides'] ) && is_array( $_POST['agentic_agent_overrides'] )
			? wp_unslash( $_POST['agentic_agent_overrides'] ) // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			: array();
		$agentic_valid_modes     = array( '', 'disabled', 'supervised', 'autonomous' );
		$agentic_valid_providers = array_merge( array( '' ), \Agentic\Provider_Registry::get_slugs() );
		foreach ( $agentic_raw_overrides as $agentic_slug => $agentic_ov ) {
			$agentic_slug = sanitize_key( $agentic_slug );
			if ( empty( $agentic_slug ) ) {
				continue;
			}
			$agentic_ov_provider     = sanitize_text_field( $agentic_ov['provider'] ?? '' );
			$agentic_ov_model        = sanitize_text_field( $agentic_ov['model'] ?? '' );
			$agentic_ov_vision_model = sanitize_text_field( $agentic_ov['vision_model'] ?? '' );
			$agentic_ov_mode         = sanitize_text_field( $agentic_ov['mode'] ?? '' );
			// Only store if provider and mode are valid values.
			if (
				in_array( $agentic_ov_provider, $agentic_valid_providers, true )
				&& in_array( $agentic_ov_mode, $agentic_valid_modes, true )
			) {
				\Agentic\Agent_Settings::update( $agentic_slug, 'override_provider', $agentic_ov_provider );
				\Agentic\Agent_Settings::update( $agentic_slug, 'override_model', $agentic_ov_model );
				\Agentic\Agent_Settings::update( $agentic_slug, 'override_vision_model', $agentic_ov_vision_model );
				\Agentic\Agent_Settings::update( $agentic_slug, 'override_mode', $agentic_ov_mode );
				\Agentic\Agent_Settings::update( $agentic_slug, 'override_audio', isset( $agentic_ov['audio'] ) ? '1' : '' );
				\Agentic\Agent_Settings::update( $agentic_slug, 'override_tts', isset( $agentic_ov['tts'] ) ? '1' : '' );
				\Agentic\Agent_Settings::update( $agentic_slug, 'override_vision', isset( $agentic_ov['vision'] ) ? '1' : '' );
				\Agentic\Agent_Settings::update( $agentic_slug, 'override_costs', isset( $agentic_ov['costs'] ) ? '1' : '' );
				\Agentic\Agent_Settings::update( $agentic_slug, 'override_cache', isset( $agentic_ov['cache'] ) ? '1' : '' );

				// P0 Item 3: Tool reliability controls for weaker models
				\Agentic\Agent_Settings::update( $agentic_slug, 'weak_model_tool_guidance', isset( $agentic_ov['weak_model_tool_guidance'] ) ? '1' : '' );
				$agentic_ov_retries = isset( $agentic_ov['max_tool_retries'] ) ? sanitize_text_field( $agentic_ov['max_tool_retries'] ) : '';
				\Agentic\Agent_Settings::update( $agentic_slug, 'max_tool_retries', $agentic_ov_retries );
			}
		}
	}

	if ( '' === $agentic_reset_section && ( 'global' === $agentic_save_tab || 'cache' === $agentic_save_tab ) ) {
		$agentic_cache_bef = array(
			'response_cache_enabled' => (bool) get_option( 'agentic_response_cache_enabled', true ),
			'response_cache_ttl'     => (int) get_option( 'agentic_response_cache_ttl', 3600 ),
		);

		update_option( 'agentic_response_cache_enabled', isset( $_POST['agentic_response_cache_enabled'] ) );
		update_option( 'agentic_response_cache_ttl', absint( $_POST['agentic_response_cache_ttl'] ?? 3600 ) );

		// Handle cache clear.
		if ( isset( $_POST['agentic_clear_cache'] ) ) {
			$agentic_cleared = \Agentic\Response_Cache::clear_all();
			echo '<div class="notice notice-info"><p>Cleared ' . esc_html( $agentic_cleared ) . ' cached responses.</p></div>';
		}

		$agentic_cache_aft  = array(
			'response_cache_enabled' => (bool) get_option( 'agentic_response_cache_enabled' ),
			'response_cache_ttl'     => (int) get_option( 'agentic_response_cache_ttl' ),
		);
		$agentic_cache_diff = array();
		foreach ( $agentic_cache_aft as $agentic_ck => $agentic_cv ) {
			if ( $agentic_cache_bef[ $agentic_ck ] !== $agentic_cv ) {
				$agentic_cache_diff[ $agentic_ck ] = array(
					'before' => $agentic_cache_bef[ $agentic_ck ],
					'after'  => $agentic_cv,
				);
			}
		}
		if ( ! empty( $agentic_cache_diff ) ) {
			\Agentic\Security_Log::log_system(
				'settings_changed',
				'cache_settings',
				array(
					'setting' => 'cache_tab',
					'changes' => $agentic_cache_diff,
				)
			);
		}
	}

	if ( '' === $agentic_reset_section && 'security' === $agentic_save_tab ) {
		// Capture previous values before saving so we can log what changed.
		$agentic_sec_before = array(
			'agent_mode'                  => (string) get_option( 'agentic_agent_mode', 'supervised' ),
			'security_enabled'            => (bool) get_option( 'agentic_security_enabled', false ),
			'turnstile_require_anonymous' => (bool) get_option( 'agentic_turnstile_require_anonymous', false ),
			'turnstile_require_all'       => (bool) get_option( 'agentic_turnstile_require_all', false ),
			'ip_anonymize'                => (bool) get_option( 'agentic_ip_anonymize', true ),
			'retention_conversations'     => (int) get_option( 'agentic_retention_conversations', 30 ),
			'retention_audit_log'         => (int) get_option( 'agentic_retention_audit_log', 30 ),
			'chat_consent_enabled'        => (bool) get_option( 'agentic_chat_consent_enabled', false ),
			'chat_consent_text'           => (string) get_option( 'agentic_chat_consent_text', '' ),
		);

		$agentic_valid_modes = array( 'disabled', 'supervised', 'autonomous' );
		$agentic_new_mode    = sanitize_key( wp_unslash( $_POST['agentic_agent_mode'] ?? 'supervised' ) );
		if ( in_array( $agentic_new_mode, $agentic_valid_modes, true ) ) {
			update_option( 'agentic_agent_mode', $agentic_new_mode );
		}
		update_option( 'agentic_security_enabled', isset( $_POST['agentic_security_enabled'] ) );
		update_option( 'agentic_turnstile_site_key', sanitize_text_field( wp_unslash( $_POST['agentic_turnstile_site_key'] ?? '' ) ) );
		update_option( 'agentic_turnstile_secret_key', sanitize_text_field( wp_unslash( $_POST['agentic_turnstile_secret_key'] ?? '' ) ) );
		update_option( 'agentic_turnstile_require_anonymous', isset( $_POST['agentic_turnstile_require_anonymous'] ) );
		update_option( 'agentic_turnstile_require_all', isset( $_POST['agentic_turnstile_require_all'] ) );
		// GDPR settings.
		update_option( 'agentic_ip_anonymize', isset( $_POST['agentic_ip_anonymize'] ) );
		update_option( 'agentic_retention_conversations', absint( $_POST['agentic_retention_conversations'] ?? 0 ) );
		update_option( 'agentic_retention_audit_log', absint( $_POST['agentic_retention_audit_log'] ?? 0 ) );
		update_option( 'agentic_chat_consent_enabled', isset( $_POST['agentic_chat_consent_enabled'] ) );
		update_option( 'agentic_chat_consent_text', sanitize_textarea_field( wp_unslash( $_POST['agentic_chat_consent_text'] ?? '' ) ) );

		// Log any changes to the audit log.
		$agentic_sec_after = array(
			'agent_mode'                  => (string) get_option( 'agentic_agent_mode' ),
			'security_enabled'            => (bool) get_option( 'agentic_security_enabled' ),
			'turnstile_require_anonymous' => (bool) get_option( 'agentic_turnstile_require_anonymous' ),
			'turnstile_require_all'       => (bool) get_option( 'agentic_turnstile_require_all' ),
			'ip_anonymize'                => (bool) get_option( 'agentic_ip_anonymize' ),
			'retention_conversations'     => (int) get_option( 'agentic_retention_conversations' ),
			'retention_audit_log'         => (int) get_option( 'agentic_retention_audit_log' ),
			'chat_consent_enabled'        => (bool) get_option( 'agentic_chat_consent_enabled' ),
			'chat_consent_text'           => (string) get_option( 'agentic_chat_consent_text' ),
		);
		$agentic_sec_diff  = array();
		foreach ( $agentic_sec_after as $agentic_sec_key => $agentic_sec_val ) {
			if ( $agentic_sec_before[ $agentic_sec_key ] !== $agentic_sec_val ) {
				$agentic_sec_diff[ $agentic_sec_key ] = array(
					'before' => $agentic_sec_before[ $agentic_sec_key ],
					'after'  => $agentic_sec_val,
				);
			}
		}
		if ( ! empty( $agentic_sec_diff ) ) {
			\Agentic\Security_Log::log_system(
				'settings_changed',
				'security_settings',
				array(
					'setting' => 'security_tab',
					'changes' => $agentic_sec_diff,
				)
			);
		}
	}

	if ( '' === $agentic_reset_section && 'users' === $agentic_save_tab ) {
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitised per-field inside save_settings()
		$agentic_roles_raw = isset( $_POST['agentic_user_roles'] ) && is_array( $_POST['agentic_user_roles'] )
			? wp_unslash( $_POST['agentic_user_roles'] ) // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			: array();
		\Agentic\User_Roles::save_settings( $agentic_roles_raw );

		// Per-role usage limits.
		$agentic_limits_raw = isset( $_POST['agentic_usage_limits'] ) && is_array( $_POST['agentic_usage_limits'] )
			? wp_unslash( $_POST['agentic_usage_limits'] ) // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			: array();
		\Agentic\Usage_Limits::save_limits( $agentic_limits_raw );

		// Anonymous frontend chat access (checkbox lives in the AI Agents merged table).
		$agentic_users_bef = array(
			'allow_anonymous_chat'     => (bool) get_option( 'agentic_allow_anonymous_chat', false ),
			'rate_limit_authenticated' => (int) get_option( 'agentic_rate_limit_authenticated', 30 ),
			'rate_limit_anonymous'     => (int) get_option( 'agentic_rate_limit_anonymous', 10 ),
		);
		update_option( 'agentic_allow_anonymous_chat', isset( $_POST['agentic_allow_anonymous_chat'] ) );

		// Per-minute rate limits (IP-based, applied before role-based daily limits).
		update_option( 'agentic_rate_limit_authenticated', absint( $_POST['agentic_rate_limit_authenticated'] ?? 30 ) );
		update_option( 'agentic_rate_limit_anonymous', absint( $_POST['agentic_rate_limit_anonymous'] ?? 10 ) );

		$agentic_users_aft  = array(
			'allow_anonymous_chat'     => (bool) get_option( 'agentic_allow_anonymous_chat' ),
			'rate_limit_authenticated' => (int) get_option( 'agentic_rate_limit_authenticated' ),
			'rate_limit_anonymous'     => (int) get_option( 'agentic_rate_limit_anonymous' ),
		);
		$agentic_users_diff = array();
		foreach ( $agentic_users_aft as $agentic_uk => $agentic_uv ) {
			if ( $agentic_users_bef[ $agentic_uk ] !== $agentic_uv ) {
				$agentic_users_diff[ $agentic_uk ] = array(
					'before' => $agentic_users_bef[ $agentic_uk ],
					'after'  => $agentic_uv,
				);
			}
		}
		if ( ! empty( $agentic_users_diff ) ) {
			\Agentic\Security_Log::log_system(
				'settings_changed',
				'user_settings',
				array(
					'setting' => 'users_tab',
					'changes' => $agentic_users_diff,
				)
			);
		}
	}

	if ( '' === $agentic_reset_section && in_array( $agentic_save_tab, array( 'personas', 'instructions' ), true ) ) {
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitised per-field below
		$agentic_personas_raw     = isset( $_POST['agentic_agent_personas'] ) && is_array( $_POST['agentic_agent_personas'] )
			? wp_unslash( $_POST['agentic_agent_personas'] ) // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			: array();
		$agentic_personas_changed = false;
		foreach ( $agentic_personas_raw as $agentic_p_slug => $agentic_p_data ) {
			$agentic_p_slug = sanitize_key( $agentic_p_slug );
			if ( empty( $agentic_p_slug ) || ! is_array( $agentic_p_data ) ) {
				continue;
			}

			$agentic_p_welcome = sanitize_textarea_field( $agentic_p_data['welcome_message'] ?? '' );
			$agentic_p_notes   = sanitize_textarea_field( $agentic_p_data['persona_notes'] ?? '' );
			$agentic_p_style   = sanitize_key( $agentic_p_data['response_style'] ?? '' );
			$agentic_p_prompts = array_values( array_filter( array_map( 'sanitize_text_field', (array) ( $agentic_p_data['suggested_prompts'] ?? array() ) ) ) );

			// Detect changes before writing.
			$agentic_p_old_welcome  = \Agentic\Agent_Settings::get( $agentic_p_slug, 'persona_welcome_message' );
			$agentic_p_old_notes    = \Agentic\Agent_Settings::get( $agentic_p_slug, 'persona_notes' );
			$agentic_p_old_style    = \Agentic\Agent_Settings::get( $agentic_p_slug, 'persona_response_style' );
			$agentic_p_prompts_json = (string) wp_json_encode( $agentic_p_prompts );
			$agentic_p_old_prompts  = \Agentic\Agent_Settings::get( $agentic_p_slug, 'persona_suggested_prompts' );

			\Agentic\Agent_Settings::update( $agentic_p_slug, 'persona_welcome_message', $agentic_p_welcome );
			\Agentic\Agent_Settings::update( $agentic_p_slug, 'persona_notes', $agentic_p_notes );
			\Agentic\Agent_Settings::update( $agentic_p_slug, 'persona_response_style', $agentic_p_style );
			\Agentic\Agent_Settings::update( $agentic_p_slug, 'persona_suggested_prompts', $agentic_p_prompts_json );

			if ( $agentic_p_old_welcome !== $agentic_p_welcome
				|| $agentic_p_old_notes !== $agentic_p_notes
				|| $agentic_p_old_style !== $agentic_p_style
				|| $agentic_p_old_prompts !== $agentic_p_prompts_json ) {
				$agentic_personas_changed = true;
			}

			// Save knowledge file and update abilities.json.
			$agentic_p_knowledge = sanitize_textarea_field( $agentic_p_data['knowledge'] ?? '' );
			$agentic_p_kn_dir    = AGENTIC_KNOWLEDGE_DIR . '/';
			$agentic_p_kn_file   = $agentic_p_kn_dir . $agentic_p_slug . '-knowledge.txt';
			$agentic_p_kn_rel    = $agentic_p_slug . '-knowledge.txt';

			\Agentic\File_Manager::mkdir( $agentic_p_kn_dir );

			// Load the agent's abilities.json manifest.
			$agentic_p_manifest_path = \Agentic\Abilities_Manifest::resolve_path( $agentic_p_slug );

			if ( ! empty( trim( $agentic_p_knowledge ) ) ) {
				// Write the knowledge file.
				\Agentic\File_Manager::put_contents( $agentic_p_kn_file, $agentic_p_knowledge );

				// Add to abilities.json if not already present.
				if ( $agentic_p_manifest_path ) {
					// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
					$agentic_p_manifest = json_decode( file_get_contents( $agentic_p_manifest_path ), true );
					if ( is_array( $agentic_p_manifest ) ) {
						$agentic_p_kn_files = $agentic_p_manifest['knowledge_files'] ?? array();
						if ( ! in_array( $agentic_p_kn_rel, $agentic_p_kn_files, true ) ) {
							$agentic_p_kn_files[]                  = $agentic_p_kn_rel;
							$agentic_p_manifest['knowledge_files'] = array_values( $agentic_p_kn_files );
							\Agentic\File_Manager::put_contents( $agentic_p_manifest_path, wp_json_encode( $agentic_p_manifest, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ) );
							\Agentic\Abilities_Manifest::clear_cache( $agentic_p_slug );
							\Agentic\Abilities_Manifest::save_integrity_hash( $agentic_p_slug );
						}
					}
				}
			} else {
				// Knowledge cleared — remove file and abilities.json entry.
				if ( \Agentic\File_Manager::exists( $agentic_p_kn_file ) ) {
					\Agentic\File_Manager::delete( $agentic_p_kn_file );
				}
				if ( $agentic_p_manifest_path ) {
					// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
					$agentic_p_manifest = json_decode( file_get_contents( $agentic_p_manifest_path ), true );
					if ( is_array( $agentic_p_manifest ) && ! empty( $agentic_p_manifest['knowledge_files'] ) ) {
						$agentic_p_kn_files = array_filter(
							$agentic_p_manifest['knowledge_files'],
							function ( $f ) use ( $agentic_p_kn_rel ) {
								return $f !== $agentic_p_kn_rel;
							}
						);
						if ( count( $agentic_p_kn_files ) !== count( $agentic_p_manifest['knowledge_files'] ) ) {
							if ( empty( $agentic_p_kn_files ) ) {
								unset( $agentic_p_manifest['knowledge_files'] );
							} else {
								$agentic_p_manifest['knowledge_files'] = array_values( $agentic_p_kn_files );
							}
							\Agentic\File_Manager::put_contents( $agentic_p_manifest_path, wp_json_encode( $agentic_p_manifest, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ) );
							\Agentic\Abilities_Manifest::clear_cache( $agentic_p_slug );
							\Agentic\Abilities_Manifest::save_integrity_hash( $agentic_p_slug );
						}
					}
				}
			}
		}
		if ( $agentic_personas_changed ) {
			\Agentic\Security_Log::log_system(
				'settings_changed',
				'personas_settings',
				array(
					'setting' => 'personas_tab',
					'changes' => array( 'personas_updated' => true ),
				)
			);
		}
	}

	if ( '' === $agentic_reset_section && 'global' === $agentic_save_tab ) {
		$agentic_styles_bef = array(
			'chat_theme'      => (string) get_option( 'agentic_chat_theme', 'dark' ),
			'chat_audio'      => (string) get_option( 'agentic_chat_audio', '0' ),
			'chat_tts'        => (string) get_option( 'agentic_chat_tts', '1' ),
			'chat_vision'     => (string) get_option( 'agentic_chat_vision', '0' ),
			'chat_whitelabel' => (string) get_option( 'agentic_chat_whitelabel', '0' ),
		);
		if ( defined( 'AGENTIC_PRO' ) && AGENTIC_PRO ) {
			$agentic_styles_bef['chat_costs'] = (string) get_option( 'agentic_chat_costs', '0' );
		}

		$agentic_valid_themes = array( 'dark', 'light', 'midnight', 'ocean' );
		$agentic_chosen_theme = sanitize_key( wp_unslash( $_POST['agentic_chat_theme'] ?? 'dark' ) );
		if ( in_array( $agentic_chosen_theme, $agentic_valid_themes, true ) ) {
			update_option( 'agentic_chat_theme', $agentic_chosen_theme );
		}

		update_option( 'agentic_chat_audio', isset( $_POST['agentic_chat_audio'] ) ? '1' : '0' );
		update_option( 'agentic_chat_tts', isset( $_POST['agentic_chat_tts'] ) ? '1' : '0' );
		update_option( 'agentic_chat_vision', isset( $_POST['agentic_chat_vision'] ) ? '1' : '0' );
		update_option( 'agentic_chat_whitelabel', isset( $_POST['agentic_chat_whitelabel'] ) ? '1' : '0' );
		if ( defined( 'AGENTIC_PRO' ) && AGENTIC_PRO ) {
			update_option( 'agentic_chat_costs', isset( $_POST['agentic_chat_costs'] ) ? '1' : '0' );
		}

		// Item 3: Tool reliability for weaker models (global)
		update_option( 'agentic_enable_weak_model_tool_guidance', isset( $_POST['agentic_enable_weak_model_tool_guidance'] ) ? '1' : '0' );
		update_option( 'agentic_max_tool_retries', max(1, absint( $_POST['agentic_max_tool_retries'] ?? 3 )) );

		$agentic_styles_aft = array(
			'chat_theme'      => (string) get_option( 'agentic_chat_theme', 'dark' ),
			'chat_audio'      => (string) get_option( 'agentic_chat_audio', '0' ),
			'chat_tts'        => (string) get_option( 'agentic_chat_tts', '1' ),
			'chat_vision'     => (string) get_option( 'agentic_chat_vision', '0' ),
			'chat_whitelabel' => (string) get_option( 'agentic_chat_whitelabel', '0' ),
		);
		if ( defined( 'AGENTIC_PRO' ) && AGENTIC_PRO ) {
			$agentic_styles_aft['chat_costs'] = (string) get_option( 'agentic_chat_costs', '0' );
		}
		$agentic_styles_diff = array();
		foreach ( $agentic_styles_aft as $agentic_sk => $agentic_sv ) {
			if ( $agentic_styles_bef[ $agentic_sk ] !== $agentic_sv ) {
				$agentic_styles_diff[ $agentic_sk ] = array(
					'before' => $agentic_styles_bef[ $agentic_sk ],
					'after'  => $agentic_sv,
				);
			}
		}
		if ( ! empty( $agentic_styles_diff ) ) {
			\Agentic\Security_Log::log_system(
				'settings_changed',
				'style_settings',
				array(
					'setting' => 'styles_tab',
					'changes' => $agentic_styles_diff,
				)
			);
		}
	}

	// Handle system check completion flag.
	if ( isset( $_POST['agentic_system_check_done'] ) ) {
		update_option( 'agentic_system_check_done', true );
	}

	if ( '' === $agentic_reset_section ) {
		if ( 'agents' === $agentic_save_tab ) {
			$agentic_global_provider      = get_option( 'agentic_llm_provider', 'agentic' );
			$agentic_global_prov_reg      = \Agentic\Provider_Registry::get( $agentic_global_provider );
			$agentic_global_provider_name = $agentic_global_prov_reg['name'] ?? ucfirst( $agentic_global_provider );
			/* translators: %s is the name of the LLM provider set as global default. */
			echo '<div class="notice notice-success"><p>' . sprintf( esc_html__( 'Settings saved with %s as Global provider.', 'agent-builder' ), '<strong>' . esc_html( $agentic_global_provider_name ) . '</strong>' ) . '</p></div>';
		} else {
			echo '<div class="notice notice-success"><p>' . esc_html__( 'Settings saved.', 'agent-builder' ) . '</p></div>';
		}
	}
}

// Get current values.
$agentic_llm_provider_val = get_option( 'agentic_llm_provider', 'agentic' );
$agentic_api_key_val      = \Agentic\Provider_Registry::get( $agentic_llm_provider_val )['api_key'] ?? '';
$agentic_model_val        = get_option( 'agentic_model', 'gpt-4o' );
$agentic_vision_model_val = get_option( 'agentic_vision_model', $agentic_model_val );
$agentic_agent_mode_val   = get_option( 'agentic_agent_mode', 'supervised' );
$agentic_ollama_url_val   = get_option( 'agentic_ollama_url', 'http://localhost:11434' );

// Cache settings.
$agentic_cache_enabled = get_option( 'agentic_response_cache_enabled', true );
$agentic_cache_ttl     = get_option( 'agentic_response_cache_ttl', 3600 );
$agentic_cache_stats   = \Agentic\Response_Cache::get_stats();

// Security settings.
$agentic_security_enabled       = get_option( 'agentic_security_enabled', true );
$agentic_allow_anon_chat        = get_option( 'agentic_allow_anonymous_chat', false );
$agentic_turnstile_site_key     = get_option( 'agentic_turnstile_site_key', '' );
$agentic_turnstile_secret_key   = get_option( 'agentic_turnstile_secret_key', '' );
$agentic_turnstile_require_anon = get_option( 'agentic_turnstile_require_anonymous', true );
$agentic_turnstile_require_all  = get_option( 'agentic_turnstile_require_all', false );
// GDPR settings.
$agentic_ip_anonymize            = get_option( 'agentic_ip_anonymize', true );

// Item 3: Tool reliability for weaker models (global defaults)
$agentic_weak_guidance_global = get_option( 'agentic_enable_weak_model_tool_guidance', '1' );
$agentic_max_retries_global   = get_option( 'agentic_max_tool_retries', '3' );
$agentic_retention_conversations = get_option( 'agentic_retention_conversations', 30 );
$agentic_retention_audit_log     = get_option( 'agentic_retention_audit_log', 30 );
$agentic_chat_consent_enabled    = get_option( 'agentic_chat_consent_enabled', false );
$agentic_chat_consent_text       = get_option( 'agentic_chat_consent_text', 'By chatting you agree to your messages being processed by an AI. We do not share your data with third parties.' );
// Rate limit settings (read near Users tab).
$agentic_rate_limit_auth = get_option( 'agentic_rate_limit_authenticated', 30 );
$agentic_rate_limit_anon = get_option( 'agentic_rate_limit_anonymous', 10 );
?>
<div class="wrap">
	<h1>Settings</h1>

	<?php
	$agentic_active_tab = isset( $_GET['tab'] ) ? sanitize_text_field( wp_unslash( $_GET['tab'] ) ) : 'agents';
	?>

	<h2 class="nav-tab-wrapper">
		<a href="?page=agentic-settings&tab=agents" class="nav-tab <?php echo esc_attr( 'agents' === $agentic_active_tab ? 'nav-tab-active' : '' ); ?>">Agents</a>
		<a href="?page=agentic-settings&tab=providers" class="nav-tab <?php echo esc_attr( 'providers' === $agentic_active_tab ? 'nav-tab-active' : '' ); ?>">Providers</a>
		<a href="?page=agentic-settings&tab=global" class="nav-tab <?php echo esc_attr( 'global' === $agentic_active_tab ? 'nav-tab-active' : '' ); ?>">Global</a>
		<a href="?page=agentic-settings&tab=instructions" class="nav-tab <?php echo esc_attr( 'instructions' === $agentic_active_tab ? 'nav-tab-active' : '' ); ?>">Instructions</a>
		<a href="?page=agentic-settings&tab=memory" class="nav-tab <?php echo esc_attr( 'memory' === $agentic_active_tab ? 'nav-tab-active' : '' ); ?>">Memory</a>
		<a href="?page=agentic-settings&tab=security" class="nav-tab <?php echo esc_attr( 'security' === $agentic_active_tab ? 'nav-tab-active' : '' ); ?>">Security</a>
		<a href="?page=agentic-settings&tab=users" class="nav-tab <?php echo esc_attr( 'users' === $agentic_active_tab ? 'nav-tab-active' : '' ); ?>">Users</a>
		<a href="?page=agentic-settings&tab=apis" class="nav-tab <?php echo esc_attr( 'apis' === $agentic_active_tab ? 'nav-tab-active' : '' ); ?>">APIs</a>
		<?php if ( file_exists( AGENT_BUILDER_DIR . 'includes/pro/health/settings-health.php' ) ) : ?>
		<a href="?page=agentic-settings&tab=health" class="nav-tab <?php echo esc_attr( 'health' === $agentic_active_tab ? 'nav-tab-active' : '' ); ?>">Health</a>
		<?php endif; ?>
		<a href="?page=agentic-settings&tab=endpoints" class="nav-tab <?php echo esc_attr( 'endpoints' === $agentic_active_tab ? 'nav-tab-active' : '' ); ?>">Endpoints</a>
		<a href="?page=agentic-settings&tab=license" class="nav-tab <?php echo esc_attr( 'license' === $agentic_active_tab ? 'nav-tab-active' : '' ); ?>">License</a>
	</h2>

	<?php if ( 'providers' === $agentic_active_tab ) : ?>
		<?php include AGENT_BUILDER_DIR . 'admin/providers.php'; ?>
	<?php elseif ( 'apis' === $agentic_active_tab ) : ?>
		<?php include AGENT_BUILDER_DIR . 'admin/apis.php'; ?>
	<?php elseif ( 'health' === $agentic_active_tab && file_exists( AGENT_BUILDER_DIR . 'includes/pro/health/settings-health.php' ) ) : ?>
		<?php require AGENT_BUILDER_DIR . 'includes/pro/health/settings-health.php'; ?>
	<?php elseif ( 'endpoints' === $agentic_active_tab ) : ?>
		<?php require_once __DIR__ . '/settings-endpoints.php'; ?>
	<?php elseif ( 'memory' === $agentic_active_tab ) : ?>
		<?php require_once __DIR__ . '/settings-memory.php'; ?>
	<?php else : // all other tabs use the outer settings form. ?>
	<form method="post" action="">
		<?php wp_nonce_field( 'agentic_settings_nonce' ); ?>
		<input type="hidden" name="tab" value="<?php echo esc_attr( $agentic_active_tab ); ?>" />
		<input type="hidden" name="agentic_reset_section" id="agentic-reset-section" value="" />

		<?php
		$agentic_settings_form_tabs = array( 'license', 'agents', 'security', 'users', 'global', 'instructions' );
		if ( in_array( $agentic_active_tab, $agentic_settings_form_tabs, true ) ) {
			require __DIR__ . '/settings/tab-' . $agentic_active_tab . '.php';
		}
		?>

		<p class="submit">
			<input type="submit" name="agentic_save_settings" class="button-primary" value="Save Settings" />
		</p>
	</form>
	<?php endif; // end providers vs settings form. ?>

</div>
<script>
document.querySelectorAll('.agentic-reset-defaults').forEach(function(link) {
	link.addEventListener('click', function(e) {
		e.preventDefault();
		var section = this.getAttribute('data-section');
		var doReset = function() {
			document.getElementById('agentic-reset-section').value = section;
			this.closest('form').querySelector('[name="agentic_save_settings"]').click();
		}.bind(this);
		if ( window.agenticConfirm ) {
			window.agenticConfirm( 'Reset these settings to their fresh-install defaults? This cannot be undone.', doReset );
			return;
		}
		var resetMsg = 'Reset these settings to their fresh-install defaults? This cannot be undone.';
		if (window.agenticConfirm) {
			window.agenticConfirm( resetMsg, doReset );
			return;
		}
		if ( ! confirm( resetMsg ) ) return;
		doReset();
	});
});
</script>
