<?php
/**
 * Settings — Global Chat Tab
 *
 * Chat theme selector and global feature flags.
 * Variables from parent settings.php scope:
 *   $agentic_cache_enabled, $agentic_cache_ttl, $agentic_cache_stats
 *
 * @package    Agent_Builder
 * @subpackage Admin/Settings
 * @since      2.10.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$agentic_current_theme = get_option( 'agentic_chat_theme', 'dark' );
$agentic_theme_presets = array(
	'dark'     => array(
		'label'  => 'Dark',
		'desc'   => 'Deep purple dark theme — the default.',
		'bg'     => '#1a1a2e',
		'accent' => '#8b5cf6',
		'text'   => '#f0f0f0',
		'msg'    => 'rgba(139,92,246,0.15)',
	),
	'light'    => array(
		'label'  => 'Light',
		'desc'   => 'Clean white with WordPress blue accents.',
		'bg'     => '#ffffff',
		'accent' => '#2271b1',
		'text'   => '#1d2327',
		'msg'    => '#f0f0f1',
	),
	'midnight' => array(
		'label'  => 'Midnight',
		'desc'   => 'Pure dark with emerald green accents.',
		'bg'     => '#0f172a',
		'accent' => '#10b981',
		'text'   => '#e2e8f0',
		'msg'    => 'rgba(16,185,129,0.12)',
	),
	'ocean'    => array(
		'label'  => 'Ocean',
		'desc'   => 'Deep blue with teal highlights.',
		'bg'     => '#0c1222',
		'accent' => '#06b6d4',
		'text'   => '#e0f2fe',
		'msg'    => 'rgba(6,182,212,0.12)',
	),
);

$agentic_ui_audio      = get_option( 'agentic_chat_audio', '1' );
$agentic_ui_tts        = get_option( 'agentic_chat_tts', '1' );
$agentic_ui_vision     = get_option( 'agentic_chat_vision', '1' );
$agentic_ui_costs      = get_option( 'agentic_chat_costs', '1' );
$agentic_ui_whitelabel = get_option( 'agentic_chat_whitelabel', '0' );
?>
<h2>Chat Theme</h2>
<p>Choose a visual theme for the agent chat interface. This applies to both the admin chat page and frontend shortcode.</p>

<div class="agentic-theme-grid">
	<?php foreach ( $agentic_theme_presets as $agentic_theme_key => $agentic_theme_def ) : ?>
	<label class="agentic-theme-card" style="cursor: pointer; border: 2px solid <?php echo esc_attr( $agentic_current_theme === $agentic_theme_key ? '#2271b1' : '#dcdcde' ); ?>; border-radius: 12px; overflow: hidden; transition: border-color 0.2s; display: block;">
		<input type="radio" name="agentic_chat_theme" value="<?php echo esc_attr( $agentic_theme_key ); ?>" <?php checked( $agentic_current_theme, $agentic_theme_key ); ?> style="position: absolute; opacity: 0; pointer-events: none;" />
		<!-- Preview swatch -->
		<div style="background: <?php echo esc_attr( $agentic_theme_def['bg'] ); ?>; padding: 16px; min-height: 100px;">
			<div class="agentic-flex-gap-8 agentic-mb-12">
				<div style="width: 28px; height: 28px; border-radius: 6px; background: <?php echo esc_attr( $agentic_theme_def['accent'] ); ?>;"></div>
				<span style="color: <?php echo esc_attr( $agentic_theme_def['text'] ); ?>; font-weight: 600; font-size: 13px;">AI Assistant</span>
			</div>
			<div style="background: <?php echo esc_attr( $agentic_theme_def['msg'] ); ?>; border-radius: 8px; padding: 8px 10px; margin-bottom: 6px;">
				<span style="color: <?php echo esc_attr( $agentic_theme_def['text'] ); ?>; font-size: 11px;">Hello! How can I help?</span>
			</div>
			<div style="margin-left: auto; max-width: 70%; background: <?php echo esc_attr( $agentic_theme_def['accent'] ); ?>33; border-radius: 8px; padding: 8px 10px;">
				<span style="color: <?php echo esc_attr( $agentic_theme_def['text'] ); ?>; font-size: 11px;">Update my homepage</span>
			</div>
		</div>
		<!-- Label -->
		<div class="agentic-theme-card-footer">
			<strong class="agentic-theme-label"><?php echo esc_html( $agentic_theme_def['label'] ); ?></strong>
			<span class="agentic-text-xs agentic-text-muted"><?php echo esc_html( $agentic_theme_def['desc'] ); ?></span>
		</div>
	</label>
	<?php endforeach; ?>
</div>

<h2 class="agentic-settings-h2">Global Chat Settings</h2>
<p>Features globally available to users in the Agent chat interface. Override per agent <a href="<?php echo esc_url( admin_url( 'admin.php?page=agentic-settings&tab=agents' ) ); ?>">here</a>.</p>

<table class="form-table" role="presentation">
	<tr>
		<th scope="row">Voice Input</th>
		<td>
			<label>
				<input type="checkbox" name="agentic_chat_audio" value="1" <?php checked( $agentic_ui_audio, '1' ); ?> />
				Enable audio input (microphone button)
			</label>
			<p class="description">Allow users to send messages using their microphone. Uses compatible browsers built-in speech recognition.</p>
		</td>
	</tr>
	<tr>
		<th scope="row">Text-to-Speech</th>
		<td>
			<label>
				<input type="checkbox" name="agentic_chat_tts" value="1" <?php checked( $agentic_ui_tts, '1' ); ?> />
				Enable audio output (speaker button)
			</label>
			<p class="description">Allow user to listen to agent responses using neural TTS voices. Requires prepaid credits.</p>
		</td>
	</tr>
	<tr>
		<th scope="row">Vision</th>
		<td>
			<label>
				<input type="checkbox" name="agentic_chat_vision" value="1" <?php checked( $agentic_ui_vision, '1' ); ?> />
				Enable image uploads (paperclip button)
			</label>
			<p class="description">Allow users to attach images for the assistant to analyze.</p>
		</td>
	</tr>
	<?php if ( \Agentic\License_Client::get_instance()->is_pro() ) : ?>
	<tr>
		<th scope="row">Costs</th>
		<td>
			<label>
				<input type="checkbox" name="agentic_chat_costs" value="1" <?php checked( $agentic_ui_costs, '1' ); ?> />
				Show token &amp; cost data in chat footer
			</label>
			<p class="description">Display token usage and estimated cost after each message.</p>
		</td>
	</tr>
	<?php endif; ?>
	<tr>
		<th scope="row">Response Cache</th>
		<td>
			<label>
				<input type="checkbox" name="agentic_response_cache_enabled" value="1" <?php checked( $agentic_cache_enabled ); ?> />
				Cache identical messages to avoid repeated LLM calls
			</label>
			<p class="description">Exact-match queries return cached responses. Saves tokens and improves response time.</p>
		</td>
	</tr>
	<tr>
		<th scope="row">Cache TTL</th>
		<td>
			<select name="agentic_response_cache_ttl" id="agentic_response_cache_ttl">
				<option value="900" <?php selected( $agentic_cache_ttl, 900 ); ?>>15 minutes</option>
				<option value="1800" <?php selected( $agentic_cache_ttl, 1800 ); ?>>30 minutes</option>
				<option value="3600" <?php selected( $agentic_cache_ttl, 3600 ); ?>>1 hour (Recommended)</option>
				<option value="7200" <?php selected( $agentic_cache_ttl, 7200 ); ?>>2 hours</option>
				<option value="21600" <?php selected( $agentic_cache_ttl, 21600 ); ?>>6 hours</option>
				<option value="86400" <?php selected( $agentic_cache_ttl, 86400 ); ?>>24 hours</option>
			</select>
			<p class="description">How long to keep cached responses before they expire.</p>
		</td>
	</tr>
	<tr>
		<th scope="row">Clear Cache</th>
		<td>
			<label>
				<input type="checkbox" name="agentic_clear_cache" value="1" />
				Clear all cached responses on save
			</label>
			<p class="description">
				<strong>Cached entries:</strong> <?php echo esc_html( $agentic_cache_stats['entry_count'] ); ?> —
				<strong>Status:</strong>
				<?php
				if ( $agentic_cache_stats['enabled'] ) {
					echo '<span class="agentic-status-active">Active</span>';
				} else {
					echo '<span class="agentic-text-danger">Disabled</span>';
				}
				?>
			</p>
		</td>
	</tr>
	<tr>
		<th scope="row">Branding</th>
		<td>
			<label>
				<input type="checkbox" name="agentic_chat_whitelabel" id="agentic_chat_whitelabel" value="1" <?php checked( $agentic_ui_whitelabel, '1' ); ?> />
				Hide &ldquo;Powered by Agent Builder&rdquo; branding
			</label>
			<p class="description">When unchecked, a small credit line appears in the chat footer.</p>
		</td>
	</tr>
</table>

<p class="agentic-mt-8"><a href="#" class="agentic-reset-defaults" data-section="styles_chat">Reset chat settings to defaults</a></p>
