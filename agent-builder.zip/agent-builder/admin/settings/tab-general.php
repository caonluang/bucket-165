<?php
/**
 * Settings — General Tab
 *
 * Global personalization that applies to every agent: how agents address
 * administrators and frontend visitors, shared site context ("Instructions
 * for Agents"), and global appearance defaults for the chat surfaces.
 *
 * These are GLOBAL settings. Per-agent persona and instructions live on the
 * Instructions tab and always take precedence over the values here.
 *
 * @package    Agent_Builder
 * @subpackage Admin/Settings
 * @since      2.15.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$agentic_admin_address      = (string) get_option( 'agentic_admin_address', '' );
$agentic_frontend_address   = (string) get_option( 'agentic_frontend_address', '' );
$agentic_global_instructions = (string) get_option( 'agentic_global_instructions', '' );
$agentic_global_font        = (string) get_option( 'agentic_global_font', '' );
$agentic_global_accent      = (string) get_option( 'agentic_global_accent', '' );

// Site tagline is used as placeholder guidance for the instructions box so the
// admin can see a sensible starting point without it being stored twice (the
// tagline is already injected into every prompt via the site-context block).
$agentic_site_tagline = (string) get_bloginfo( 'description' );

// Curated, safe global font choices. Empty value = theme default.
$agentic_font_choices = array(
	''                                            => __( 'Theme default', 'agent-builder' ),
	'system-ui, sans-serif'                       => __( 'System UI', 'agent-builder' ),
	'Arial, Helvetica, sans-serif'                => 'Arial / Helvetica',
	'Georgia, serif'                              => 'Georgia',
	'"Times New Roman", Times, serif'             => 'Times New Roman',
	'"Courier New", Courier, monospace'           => 'Courier New (monospace)',
	'Verdana, Geneva, sans-serif'                 => 'Verdana',
);
?>

<h2 class="agentic-settings-h2"><?php esc_html_e( 'Personalization', 'agent-builder' ); ?></h2>
<p><?php esc_html_e( 'Global defaults applied to every agent. Per-agent settings on the Instructions tab always take precedence.', 'agent-builder' ); ?></p>

<table class="form-table" role="presentation">
	<tr>
		<th scope="row">
			<label for="agentic_admin_address"><?php esc_html_e( 'What should agents call administrators?', 'agent-builder' ); ?></label>
		</th>
		<td>
			<input type="text" id="agentic_admin_address" name="agentic_admin_address" class="regular-text" maxlength="60" value="<?php echo esc_attr( $agentic_admin_address ); ?>" placeholder="<?php esc_attr_e( 'e.g. Sam, or “the site owner”', 'agent-builder' ); ?>" />
			<p class="description"><?php esc_html_e( 'How agents address signed-in administrators in conversation. Leave blank to use the WordPress display name.', 'agent-builder' ); ?></p>
		</td>
	</tr>
	<tr>
		<th scope="row">
			<label for="agentic_frontend_address"><?php esc_html_e( 'What should agents call frontend visitors?', 'agent-builder' ); ?></label>
		</th>
		<td>
			<input type="text" id="agentic_frontend_address" name="agentic_frontend_address" class="regular-text" maxlength="60" value="<?php echo esc_attr( $agentic_frontend_address ); ?>" placeholder="<?php esc_attr_e( 'e.g. there, or “valued customer”', 'agent-builder' ); ?>" />
			<p class="description"><?php esc_html_e( 'How agents address visitors using a chat shortcode or block on the public site. Leave blank for a neutral greeting.', 'agent-builder' ); ?></p>
		</td>
	</tr>
	<tr>
		<th scope="row">
			<label for="agentic_global_instructions"><?php esc_html_e( 'Instructions for Agents', 'agent-builder' ); ?></label>
		</th>
		<td>
			<textarea id="agentic_global_instructions" name="agentic_global_instructions" rows="6" class="large-text code" placeholder="<?php echo esc_attr( '' !== $agentic_site_tagline ? $agentic_site_tagline : __( 'Describe this site so every agent has shared context — what it does, who it serves, your tone, and anything agents should always keep in mind.', 'agent-builder' ) ); ?>"><?php echo esc_textarea( $agentic_global_instructions ); ?></textarea>
			<p class="description"><?php esc_html_e( 'Shared context every agent receives about this site — what it is, who it serves, and any standing guidance. Applied on top of each agent’s own instructions.', 'agent-builder' ); ?></p>
		</td>
	</tr>
</table>

<h2 class="agentic-settings-h2"><?php esc_html_e( 'Appearance', 'agent-builder' ); ?></h2>
<p>
	<?php esc_html_e( 'Global look and feel for the chat surfaces.', 'agent-builder' ); ?>
	<a href="<?php echo esc_url( admin_url( 'admin.php?page=agentic-settings&tab=global' ) ); ?>"><?php esc_html_e( 'Fine-tune chat themes →', 'agent-builder' ); ?></a>
</p>

<table class="form-table" role="presentation">
	<tr>
		<th scope="row">
			<label for="agentic_global_font"><?php esc_html_e( 'Chat font', 'agent-builder' ); ?></label>
		</th>
		<td>
			<select id="agentic_global_font" name="agentic_global_font">
				<?php foreach ( $agentic_font_choices as $agentic_font_value => $agentic_font_label ) : ?>
					<option value="<?php echo esc_attr( $agentic_font_value ); ?>" <?php selected( $agentic_global_font, $agentic_font_value ); ?>><?php echo esc_html( $agentic_font_label ); ?></option>
				<?php endforeach; ?>
			</select>
			<p class="description"><?php esc_html_e( 'Font used across the chat interface. Choose “Theme default” to inherit from the selected theme.', 'agent-builder' ); ?></p>
		</td>
	</tr>
	<tr>
		<th scope="row">
			<label for="agentic_global_accent"><?php esc_html_e( 'Accent colour', 'agent-builder' ); ?></label>
		</th>
		<td>
			<input type="color" id="agentic_global_accent" name="agentic_global_accent" value="<?php echo esc_attr( '' !== $agentic_global_accent ? $agentic_global_accent : '#8b5cf6' ); ?>" />
			<label class="agentic-inline-ml-8">
				<input type="checkbox" name="agentic_global_accent_clear" value="1" />
				<?php esc_html_e( 'Use theme accent (ignore the colour above)', 'agent-builder' ); ?>
			</label>
			<p class="description"><?php esc_html_e( 'Overrides the accent colour of the chat theme on every chat surface. Tick the box to fall back to the theme’s own accent.', 'agent-builder' ); ?></p>
		</td>
	</tr>
</table>
