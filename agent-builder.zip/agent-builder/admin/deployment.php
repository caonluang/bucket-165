<?php
/**
 * Agentic Agent Deployment Page
 *
 * Unified management of all agent invocation methods: Scheduled Tasks,
 * Event Listeners, and Shortcodes. Each method is presented as a tab.
 *
 * @package    Agent_Builder
 * @subpackage Admin
 * @author     Agent Builder Team <support@agentic-plugin.com>
 * @license    GPL-2.0-or-later https://www.gnu.org/licenses/gpl-2.0.html
 * @link       https://agentic-plugin.com
 * @since      1.7.0
 *
 * php version 8.1
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! current_user_can( 'manage_options' ) ) {
	wp_die( esc_html__( 'You do not have permission to access this page.', 'agent-builder' ) );
}

// Determine active tab.
$agentic_active_tab = sanitize_text_field( wp_unslash( $_GET['tab'] ?? 'admin-ui' ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only tab switch, not a form submission.
if ( ! in_array( $agentic_active_tab, array( 'admin-ui', 'shortcodes', 'gutenberg-blocks', 'website', 'admin-bar', 'scheduled-tasks', 'event-listeners', 'cli' ), true ) ) {
	$agentic_active_tab = 'admin-ui';
}
?>
<div class="wrap">
	<h1><?php esc_html_e( 'Agent Deployment', 'agent-builder' ); ?></h1>
	<p><?php esc_html_e( 'Manage how assistants are invoked: embed them on your site with shortcodes, schedule recurring tasks, or react to WordPress events.', 'agent-builder' ); ?></p>

	<?php
	\Agentic\Admin_Vnav::open(
		array(
			'active'     => $agentic_active_tab,
			'items'      => array(
				array(
					'slug'  => 'admin-ui',
					'label' => __( 'Editor', 'agent-builder' ),
					'url'   => admin_url( 'admin.php?page=agentic-deployment&tab=admin-ui' ),
				),
				array(
					'slug'  => 'shortcodes',
					'label' => __( 'Shortcodes', 'agent-builder' ),
					'url'   => admin_url( 'admin.php?page=agentic-deployment&tab=shortcodes' ),
				),
				array(
					'slug'  => 'gutenberg-blocks',
					'label' => __( 'Gutenberg Blocks', 'agent-builder' ),
					'url'   => admin_url( 'admin.php?page=agentic-deployment&tab=gutenberg-blocks' ),
				),
				array(
					'slug'  => 'website',
					'label' => __( 'Modal', 'agent-builder' ),
					'url'   => admin_url( 'admin.php?page=agentic-deployment&tab=website' ),
				),
				array(
					'slug'  => 'admin-bar',
					'label' => __( 'Admin Bar', 'agent-builder' ),
					'url'   => admin_url( 'admin.php?page=agentic-deployment&tab=admin-bar' ),
				),
				array(
					'slug'  => 'scheduled-tasks',
					'label' => __( 'Scheduled Tasks', 'agent-builder' ),
					'url'   => admin_url( 'admin.php?page=agentic-deployment&tab=scheduled-tasks' ),
				),
				array(
					'slug'  => 'event-listeners',
					'label' => __( 'Event Listeners', 'agent-builder' ),
					'url'   => admin_url( 'admin.php?page=agentic-deployment&tab=event-listeners' ),
				),
				array(
					'slug'  => 'cli',
					'label' => __( 'CLI', 'agent-builder' ),
					'url'   => admin_url( 'admin.php?page=agentic-deployment&tab=cli' ),
				),
			),
			'aria_label' => __( 'Deployment methods', 'agent-builder' ),
			'id'         => 'agentic-deployment-nav',
		)
	);

	switch ( $agentic_active_tab ) {
		case 'scheduled-tasks':
			include AGENT_BUILDER_DIR . 'admin/deployment/deployment-scheduled-tasks.php';
			break;

		case 'event-listeners':
			include AGENT_BUILDER_DIR . 'admin/deployment/deployment-event-listeners.php';
			break;

		case 'gutenberg-blocks':
			include AGENT_BUILDER_DIR . 'admin/deployment/deployment-gutenberg-blocks.php';
			break;

		case 'cli':
			include AGENT_BUILDER_DIR . 'admin/deployment/deployment-cli.php';
			break;

		case 'admin-ui':
			include AGENT_BUILDER_DIR . 'admin/deployment/deployment-admin-ui.php';
			break;

		case 'website':
			include AGENT_BUILDER_DIR . 'admin/deployment/deployment-modal.php';
			break;

		case 'admin-bar':
			include AGENT_BUILDER_DIR . 'admin/deployment/deployment-admin-bar.php';
			break;

		case 'shortcodes':
		default:
			include AGENT_BUILDER_DIR . 'admin/deployment/deployment-shortcodes.php';
			break;
	}

	\Agentic\Admin_Vnav::close();
	?>
</div>
