<?php
/**
 * Admin page → documentation URL map.
 *
 * Returned as an array with two keys:
 *   'tabs'  — keyed by 'page:tab' or 'page:section', checked first.
 *   'pages' — keyed by page slug, used as fallback.
 *
 * To add or change a mapping, edit this file only — no need to touch agent-builder.php.
 *
 * @package Agent_Builder
 * @since   2.10.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(

	// -------------------------------------------------------------------------
	// Page level (page slug => url)
	// Used when no tab match is found.
	// -------------------------------------------------------------------------
	'pages' => array(
		'agent-builder'        => 'https://agentic-plugin.com/the-dashboard/',
		'agentic-chat'         => 'https://agentic-plugin.com/chat-interface/',
		'agentic-agents'       => 'https://agentic-plugin.com/installed-agents/',
		'agentic-deployment'   => 'https://agentic-plugin.com/agent-deployment/',
		'agentic-tools'        => 'https://agentic-plugin.com/agent-tools/',
		'agentic-skills'       => 'https://agentic-plugin.com/skills/',
		'agentic-integrations' => 'https://agentic-plugin.com/channels/',
		'agentic-audit-log'    => 'https://agentic-plugin.com/audit-log/',
		'agentic-approvals'    => 'https://agentic-plugin.com/code-proposals/',
		'agentic-costs'        => 'https://agentic-plugin.com/api-credits/',
		'agentic-settings'     => 'https://agentic-plugin.com/settings/',
		'agentic-train-data'   => 'https://agentic-plugin.com/ai-data-training/',
		'agentic-run-task'     => 'https://agentic-plugin.com/scheduled-tasks/',
	),

	// -------------------------------------------------------------------------
	// Tab / section level  (page:tab => url)
	// Checked before the page-level fallback.
	// -------------------------------------------------------------------------
	'tabs'  => array(

		// Settings tabs.
		'agentic-settings:agents'             => 'https://agentic-plugin.com/settings/',
		'agentic-settings:providers'          => 'https://agentic-plugin.com/manage-llm-providers/',
		'agentic-settings:global'             => 'https://agentic-plugin.com/global-chat-settings/',
		'agentic-settings:instructions'       => 'https://agentic-plugin.com/agent-instructions/',
		'agentic-settings:memory'             => 'https://agentic-plugin.com/agent-memory/',
		'agentic-settings:security'           => 'https://agentic-plugin.com/important-security-settings/',
		'agentic-settings:users'              => 'https://agentic-plugin.com/user-roles-and-privileges/',
		'agentic-settings:apis'               => 'https://agentic-plugin.com/connecting-an-ai-provider/',
		'agentic-settings:health'             => 'https://agentic-plugin.com/troubleshooting/',
		'agentic-settings:license'            => 'https://agentic-plugin.com/licensing-and-pricing/',
		'agentic-settings:styles'             => 'https://agentic-plugin.com/chat-styles-and-themes/',
		'agentic-settings:mcp'                => 'https://agentic-plugin.com/mcp-integration/',

		// Deployment tabs.
		'agentic-deployment:admin-ui'         => 'https://agentic-plugin.com/admin-sidebar-deployment/',
		'agentic-deployment:shortcodes'       => 'https://agentic-plugin.com/agent-deployment/',
		'agentic-deployment:gutenberg-blocks' => 'https://agentic-plugin.com/gutenberg-blocks/',
		'agentic-deployment:website'          => 'https://agentic-plugin.com/frontend-chat-security/',
		'agentic-deployment:admin-bar'        => 'https://agentic-plugin.com/admin-bar-deployment/',
		'agentic-deployment:scheduled-tasks'  => 'https://agentic-plugin.com/scheduled-tasks/',
		'agentic-deployment:event-listeners'  => 'https://agentic-plugin.com/event-automation/',
		'agentic-deployment:cli'              => 'https://agentic-plugin.com/wp-cli-commands/',

		// Tools sections.
		'agentic-tools:tools'                 => 'https://agentic-plugin.com/agent-tools/',
		'agentic-tools:abilities'             => 'https://agentic-plugin.com/capabilities/',

		// Integrations sections.
		'agentic-integrations:channels'       => 'https://agentic-plugin.com/channels/',
		'agentic-integrations:mcp'            => 'https://agentic-plugin.com/mcp-integration/',

		// Logs tabs.
		'agentic-audit-log:audit'             => 'https://agentic-plugin.com/audit-log/',
		'agentic-audit-log:conversations'     => 'https://agentic-plugin.com/audit-log/',
		'agentic-audit-log:security'          => 'https://agentic-plugin.com/important-security-settings/',

		// Approvals tabs.
		'agentic-approvals:approvals'         => 'https://agentic-plugin.com/code-proposals/',
		'agentic-approvals:backups'           => 'https://agentic-plugin.com/backups/',
	),
);
