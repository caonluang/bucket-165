=== Agent Builder ===
Contributors: agenticplugin
Tags: ai, chatbot, automation, agents, llm
Requires at least: 6.4
Tested up to: 7.0
Requires PHP: 8.1
Stable tag: 2.9.254
Donate link: https://agentic-plugin.com/donate/
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Orchestrate role-based AI agents and teams with simple job descriptions.

== Description ==

**Agent Builder** lets you orchestrate AI agents and teams directly in WordPress using plain job descriptions.

No coding. No complex prompts. Just describe the role you need, and your AI employee starts working.

= Your First AI Team – 3 Powerful Agents Included Free =

🏗️ **Assistant Trainer**
Create unlimited custom AI assistants from plain-English job descriptions. In the free version it builds focused agents using only the safe built-in tools (analysis, content, media, etc.). Pro unlocks full custom tool code generation and advanced capabilities.

✍️ **Content Writer**
Writes, edits, and publishes high-quality posts and pages. Give it a topic and tone — it delivers ready-to-publish drafts.

🧭 **WordPress Assistant**
Your always-available guide to WordPress. Ask questions about settings, plugins, code, or get recommendations for the right AI agent for the task.

= Key Features =

* Create unlimited role-based AI agents using natural language — including 5 vertical quick-start templates (Support Triage, Content Ops, Site Health Sentinel, SEO Auditor, Comment Moderator)
* **Multi-agent orchestration in the free build** — delegate sub-tasks between agents with shared run context, delegation depth limits, and per-run budgets (F1)
* **Local memory & facts (zero external calls)** — per-user and per-conversation persistent facts + short-term summaries are injected into every prompt (F2). Full privacy, works with no RAG provider.
* **WordPress 7 bridge, fully productized** — bidirectional Abilities API (outbound tools as native abilities, inbound third-party abilities as agent tools), dedicated Abilities admin page, WP7 readiness banners, and thin passthrough adapter for the native AI Client + Connectors when present (F3)
* Multi-LLM support (OpenAI, Anthropic, xAI, Google, local models via Ollama, and more) with automatic preference for WP7 native client on 7.0+
* 250+ built-in tools and skills let your agents take real actions inside WordPress
* Secure sandboxed execution with 5-tier risk system, approval workflows, and full audit logs
* Shortcodes, Gutenberg blocks, REST, WP-CLI, scheduled tasks, and event listeners

**WordPress 7 + Full Backward Compatibility — The Bridge**

WordPress 7.0 ("Armstrong") ships the new native AI substrate: AI Client (`wp_ai_client_prompt()`), Connectors (central credential management), matured Abilities API, and official MCP Adapter.

**Agent Builder is the cockpit on top of the engine** — on WP 7.0+ you get seamless native integration plus everything you already love (real multi-agent teams with delegation and shared context, safety/approvals/audit, 250+ tools, channels, visual deployments, governance, marketplace, etc.).

On the millions of sites still on 6.4–6.9 (the global reality for years), you get **everything WP7 offers for AI agents — and more**:
- Production-grade sequential multi-agent handoffs (delegate_to_agent + router patterns in the controller + shared `Agent_Run` context)
- Local memory/facts with zero external calls for continuity and privacy
- Full Abilities bridge (your agents discover and use native abilities; AB tools appear as discoverable abilities)
- The same beautiful orchestration UI, weak-model reliability, approval flows, and audit depth

**Free ships the complete bridge and orchestration primitives today.** No waiting for core upgrades. Works fully on WordPress 6.4+. On 6.9+ the native surfaces light up automatically. Configure once in the new WordPress Connectors screen on WP7 and Agent Builder uses it automatically (graceful fallback everywhere else).

Free feels powerful and complete on any supported WordPress. Pro adds the premium surfaces and advanced capabilities.

= Upgrade to Agent Builder Pro — Immediate Delights =

Activate the separate Pro add-on and everything unlocks instantly (no restart, no re-training):

* **Full-power Assistant Trainer** — The free trainer is limited to composing agents from the 250+ pre-audited safe tools (high-risk approval still applies). Pro upgrades it to *extreme* risk: arbitrary new tool code generation, remote plugin/theme installs via URL, git pull/push, full email/Sheets integrations, and auto-activation of everything it scaffolds. Your existing safe custom agents keep working; new specs can now include extreme tools.

* **+7 Specialized Bundled Agents** — SEO Assistant, Security Assistant, AI Radar (visibility), Site Doctor, Media Assistant (images/video), Theme Assistant, and Plugin Assistant appear automatically in Agents and Chat. They are pre-trained with deep prompts and Pro-only tools.

* **Extreme Risk Tools Available Everywhere** — `git_pull`, `install_plugin_from_url`, full `send_email` / form integrations, and other high-power operations become usable by *any* custom agent (including ones you created in free) and by the trainer itself. Free keeps them out for WP.org safety.

* **Advanced Channels & Reach** — WhatsApp, Slack, Email, Google Sheets, Discord, Telegram, SMS/Twilio, and more. One agent, many surfaces, shared memory and approvals.

* **Outbound MCP Client (P1)** — Register any external MCP server (GitHub, Linear, Stripe, databases, your own tools) and its capabilities appear as first-class tools for your agents, risk-gated and audited like native ones.

* **Governance, Cost Control & Observability at Scale** — Hard per-agent/user/site budget caps with auto-throttle, DLP/egress allowlists, full trace timelines, eval harnesses, prompt A/B, signed audit exports, and role-scoped permissions. Safe where raw core AI is risky.

* **Durable Workflows & Visual Builder** — Parallel fan-out/fan-in, resumable runs, triggers (webhooks, WP events, channels), human-in-the-loop pauses tied to approval queue, and a canvas for complex automations. Free only does sequential delegation with shared run context.

* **Marketplace, Voice, Slash Commands, and More** — One-click community agents, voice assistant (telephony), slash commands, health dashboards, priority support, and dedicated Pro-only agent for your site.

Pro is a separate plugin (off .org). Free is always 100% functional, directory-legal, and useful standalone. Upgrade is pure delight — the same `assistant-trainer`, `create_agent_files`, delegation, and run context just become dramatically more powerful the moment Pro loads (via filter precedence for full versions + risk maxing).

== Free vs Pro (at a glance) ==

| Capability                        | Free (WP.org)                          | Pro (add-on)                              |
|-----------------------------------|----------------------------------------|-------------------------------------------|
| 3 bundled agents + safe trainer   | ✅ (unlimited custom via safe tools)  | +7 specialized (SEO, Security, etc.)     |
| Sequential delegation + shared runs | ✅ (F1)                               | + parallel, visual workflows, resumable  |
| Local memory/facts (zero external)| ✅ (F2) + cloud RAG option            | + Vertex-scale RAG + persistent memory   |
| Abilities bridge + WP7 anchor     | ✅ visible (F3)                       | — (same, plus deeper integrations)       |
| Vertical templates (5)            | ✅ quick-start JSON configs (F4)      | + one-click install + marketplace        |
| Extreme tools (git, install, etc) | ❌ (removed for compliance)           | ✅ usable by trainer + any custom agent  |
| Outbound MCP client               | ❌                                    | ✅ (P1) register any external MCP server |
| Channels (WhatsApp/Slack/...)     | Web + shortcode + block only          | + full channels + voice + handoff        |
| Cost hard-caps / DLP / export     | Basic alerts                          | ✅ hard caps, egress lists, SIEM export  |
| Observability / evals             | Audit + traces                        | ✅ full timeline, eval harness, A/B      |
| Marketplace + revenue share       | Browse only                           | ✅ install, publish your agents, share   |

All Pro features degrade gracefully: no disabled stubs in Free, clear "Pro" labels, nav items only appear when the add-on is active.

All bundled agents (free and Pro) are fully informed of WP 7.0 capabilities and how Agent Builder bridges them for earlier versions.

Agent Builder turns WordPress into a smarter, autonomous platform — perfect for bloggers, agencies, and business owners who want to scale without hiring more staff.

Visit [agentic-plugin.com](https://agentic-plugin.com/) for premium extensions, community agents, and additional templates.

== Installation ==

= Minimum Requirements =

* WordPress 6.4 or higher — **full feature set works on 6.4+**. On 6.9+ you get native Abilities API discovery and on 7.0+ the core AI Client + Connectors are used preferentially. Agent Builder is the complete bridge that gives pre-7 sites the full modern AI agent experience (and more) today.
* PHP 8.1 or higher
* MySQL 8.0 or MariaDB 10.6+

= Automatic installation =

Automatic installation is the easiest -- WordPress handles everything. To do an automatic install of Agent Builder, log in to your WordPress dashboard, navigate to the Plugins menu, and click “Add New.”

In the search field type “Agent Builder,” then click “Search Plugins.” Once found you can view details about the plugin. More importantly you can install it by clicking “Install Now”.

= Manual installation =

Manual installation method requires [downloading Agent Builder](https://agentic-plugin.com/download/) and then uploading it to your web server. The WordPress codex contains [instructions on how to do this here](https://wordpress.org/support/article/managing-plugins/#manual-plugin-installation).

= Activation =
1. Find Agent Builder and click **Activate** at the WordPress Plugins page.
2. **Agent Builder → Quick Start.** Connect Agentic AI as your default LLM Provider with free daily credits.
3. Once connected you land directly on the **Agent Builder → Chat** page — ready to go.

Navigate to **Agent Builder → Settings** to configure more LLM Providers and models.
Navigate to **Agent Builder → Agents** to activate or deactivate your AI agents.

= Updating =

Plugin updates works smoothly, but we recommend you always backup your website.

= You Choose your own LLM provider =

Works with popular AI services you already know:
- OpenAI
- Anthropic
- Cohere  
- xAI
- Google
- Meta Llama
- Mistral
- Ollama
- Your provider not in the list? You can add as many LLM providers as you like. 

= AI Provider Costs =
You are billed directly for API usage by your selected LLM provider(s) according to their pricing.

= Your Data Stays Secure =

- Full control of Agent tools, skills and abilities.
- Automated file and database backup and restore.
- Supervised mode shows you exactly what agents will change before they do. 
- Complete audit log of every conversation and action performed by your users and agents.

== Frequently Asked Questions ==

= What is Agent Builder? =

Agent Builder lets you create, train and manage AI agents directly inside your WordPress site.

Your AI agents have access to over 250 powerful tools in a managed environment. 

= How is Agent Builder different from other plugins? =

Most AI plugins are just chat interfaces that send every request to a LLM provider.

**Agent Builder is the orchestration layer and the WP7 bridge:**

- **WordPress 7 native substrate + full backward compatibility** — On 7.0+ we prefer the core AI Client, Connectors, Abilities API, and MCP Adapter. On 6.4–6.9 (the reality for most sites for years) we deliver the complete modern experience (multi-agent teams with delegation + shared run context, local memory, Abilities bridge, governance, beautiful UI) as a transparent bridge. One plugin, full power everywhere.
- Everything runs inside WordPress (deep integration with core functions, hooks, REST API, user roles, capabilities, the official Abilities API and MCP surfaces).
- Real multi-agent orchestration in the free build — delegate sub-tasks, share context via `Agent_Run`, respect depth + budgets. Content Writer can hand work to specialists; the trainer creates teams.
- Local memory/facts store (zero external) + optional cloud RAG so agents remember facts across conversations with full privacy.
- You can create an unlimited number of specialized agents for various jobs (Content Writer, SEO Optimizer, Security Guardian, Support Agent…) and orchestrate them together with shared tools and memory.
- 5 vertical quick-start templates included free (install via the Assistant Trainer).
- Built-in 5-tier risk system, approval workflows, full audit, and automatic exposure of your tools as native WordPress Abilities.
- Pro adds extreme tools, more agents, channels (WhatsApp/Slack/etc), outbound MCP consumption, hard cost caps, visual workflows, marketplace, and more — all while free remains 100% standalone and directory-legal.

Unlike external frameworks (OpenClaw, LangChain-based tools, etc.) that treat WordPress as just another API, Agent Builder treats WordPress as the primary runtime — faster, more secure, and dramatically simpler to maintain.

= Is Agent Builder free? =

The core plugin lets you deploy an unlimited number of AI agents with hundreds of tools and skills - completely free. 

You can also switch to [Agent Builder Pro](https://agentic-plugin.com/download/) any time.

= Where does Agent Builder send my data? =

Data is sent to your LLM providers such as Agentic AI, xAI, OpenAI, Anthropic or Google etc.

You can also use local models via Ollama / LM Studio (fully private — nothing leaves your server)

Extensive [Documentation](https://agentic-plugin.com/documentation/) is available.

= What is the WordPress Abilities API? =

The Abilities API (introduced in WordPress 6.9) is WordPress's native system for plugins to declare what actions they can perform — making those actions discoverable by other plugins, the REST API, MCP clients, and the Command Palette.

Agent Builder integrates in both directions:

1. **Outbound** — All agent tools are registered as WordPress abilities under the `agent-builder/` namespace. Any abilities-aware plugin or client can discover and call them.
2. **Inbound** — Agent Builder queries all registered WordPress abilities from other plugins and makes them available as tools your agents can use. Install an abilities-aware plugin and your agents gain new capabilities automatically.
3. **Extended** — Agent Builder also registers common WordPress operations (get posts, manage media, handle taxonomies) as abilities under the `wp-extended/` namespace, filling gaps that WordPress core doesn't cover yet.

Each registered ability includes risk-level metadata, permission checks, and MCP annotations. On WordPress versions before 6.9, the abilities bridge stays inactive and the plugin works normally.

= What are Tools and Skills? =

**Tools** are the individual actions you permit an agent to take — each action is a permission-controlled operation.

**Skills** Assign a skill to any agent to expand what it can do without writing any code.

= Where can I report bugs or request features? =

Use the official support forum on WordPress.org or [report an issue](https://agentic-plugin.com/support/) at https://agentic-plugin.com/

We respond to support tickets within 24–48 hours (faster for confirmed bugs).

== Screenshots ==

1. Dashboard – Agent Builder overview with quick access to chat, agents, abilities, and deployments
2. Agents overview – manage the 3 powerful free agents (Assistant Trainer, Content Writer, WordPress Assistant) plus any custom ones, just like plugins
3. Chat interface – talk to any AI agent (here the Assistant Trainer) with quick actions, markdown support, file uploads, and delegation hints
4. WordPress Abilities – dedicated admin page showing the bidirectional WP7 Abilities bridge (outbound tools + inbound third-party abilities) with native readiness banners
5. Audit log – full transparency over every AI action, tool call, reasoning, cost, and decision
6. Agent configuration – set provider, model, mode (supervised/autonomous), tools, and permissions per agent
7. Setup Wizard – choose your AI provider with pricing comparison and recommendations

== AI Agent Updates ==

Agent Builder can check for newer versions of the AI agents you have installed **opt-in only** — if you explicitly enable it. 
This expedites security patches and improvements to agent logic, prompts, and tool calling. 
Regular updates mean your AI agents work smarter and benefit from improvements by the WordPress developer community. 

= When enabled =

On the first visit to **Agent Builder → Agents**, the plugin shows a consent screen explaining what data will be sent and why. You can accept or decline. If you decline, no update checks for newer versions of your AI Agents are ever made.

= Resetting your choice =

Deactivating and reactivating the Agent Builder plugin clears your Agent Update consent.

== External Services ==

This plugin lets you connect to third-party services to process and execute tasks. **No data is transmitted unless you configure a cloud-based provider.** The plugin sends conversation messages (user input and system context) to your selected LLM provider's API to receive AI-generated responses.

= OpenAI =
* **Endpoint:** `https://api.openai.com/v1/chat/completions`
* **When used:** When OpenAI is selected as the AI provider in Settings.
* **Data sent:** Chat messages, system prompts, tool definitions, and tool call results.
* **Terms of Service:** [https://openai.com/terms](https://openai.com/terms)
* **Privacy Policy:** [https://openai.com/privacy](https://openai.com/privacy)

= Anthropic =
* **Endpoint:** `https://api.anthropic.com/v1/messages`
* **When used:** When Anthropic is selected as the AI provider in Settings.
* **Data sent:** Chat messages, system prompts, tool definitions, and tool call results.
* **Terms of Service:** [https://www.anthropic.com/terms](https://www.anthropic.com/terms)
* **Privacy Policy:** [https://www.anthropic.com/privacy](https://www.anthropic.com/privacy)

= xAI =
* **Endpoint:** `https://api.x.ai/v1/chat/completions`
* **When used:** When xAI is selected as the AI provider in Settings.
* **Data sent:** Chat messages, system prompts, tool definitions, and tool call results.
* **Terms of Service:** [https://x.ai/legal/terms-of-service](https://x.ai/legal/terms-of-service)
* **Privacy Policy:** [https://x.ai/legal/privacy-policy](https://x.ai/legal/privacy-policy)

= Google =
* **Endpoint:** `https://generativelanguage.googleapis.com/v1beta/models/`
* **When used:** When Google is selected as the AI provider in Settings.
* **Data sent:** Chat messages, system prompts, tool definitions, and tool call results.
* **Terms of Service:** [https://ai.google.dev/terms](https://ai.google.dev/terms)
* **Privacy Policy:** [https://policies.google.com/privacy](https://policies.google.com/privacy)

= Mistral =
* **Endpoint:** `https://api.mistral.ai/v1/chat/completions`
* **When used:** When Mistral is selected as the AI provider in Settings.
* **Data sent:** Chat messages, system prompts, tool definitions, and tool call results.
* **Terms of Service:** [https://mistral.ai/terms/](https://mistral.ai/terms/)
* **Privacy Policy:** [https://mistral.ai/terms/#privacy-policy](https://mistral.ai/terms/#privacy-policy)

= Meta Llama =
* **Endpoint:** `https://api.llama.com/v1/chat/completions`
* **When used:** When Meta Llama is selected as the AI provider in Settings.
* **Data sent:** Chat messages, system prompts, tool definitions, and tool call results.
* **Terms of Service:** [https://llama.meta.com/llama3/license/](https://llama.meta.com/llama3/license/)
* **Privacy Policy:** [https://www.meta.com/privacy/](https://www.meta.com/privacy/)

= Cohere =
* **Endpoint:** `https://api.cohere.com/v2/chat`
* **When used:** When Cohere is selected as the AI provider in Settings.
* **Data sent:** Chat messages, system prompts, tool definitions, and tool call results.
* **Terms of Service:** [https://cohere.com/terms-of-use](https://cohere.com/terms-of-use)
* **Privacy Policy:** [https://cohere.com/privacy](https://cohere.com/privacy)

= Ollama (Local) =
* **Endpoint:** User-configured local URL (default: `http://localhost:11434`)
* **When used:** When Ollama is selected as the AI provider in Settings.
* **Data sent:** All data stays on your local machine. No external network requests are made.

= Agentic AI =
* **Endpoint:** `https://chat.agentic-plugin.com`
* **When used:** When Agentic AI is selected as the AI provider.
* **Data sent:** Chat messages, system prompts, license key, and site URL. Free daily credits.
* **Terms of Service:** [https://agentic-plugin.com/terms-of-service/](https://agentic-plugin.com/terms-of-service/)
* **Privacy Policy:** [https://agentic-plugin.com/privacy-policy/](https://agentic-plugin.com/privacy-policy/)

= Agentic AI (RAG) =
* **Endpoint:** `https://rag.agentic-plugin.com`
* **When used:** When knowledge files or training data are uploaded via the Knowledge page.
* **Data sent:** Site URL, license key, document content for vector indexing.
* **Terms of Service:** [https://agentic-plugin.com/terms-of-service/](https://agentic-plugin.com/terms-of-service/)
* **Privacy Policy:** [https://agentic-plugin.com/privacy-policy/](https://agentic-plugin.com/privacy-policy/)

= Agentic AI (Image Gen) =
* **Endpoint:** `https://imagegen.agentic-plugin.com`
* **When used:** When an agent generates or edits images. Only active if the Media Assistant agent is installed and a user requests image generation.
* **Data sent:** Site URL, license key, text prompts, and optionally a source image (for edit operations). No user-identifying information beyond the license key.
* **Terms of Service:** [https://agentic-plugin.com/terms-of-service/](https://agentic-plugin.com/terms-of-service/)
* **Privacy Policy:** [https://agentic-plugin.com/privacy-policy/](https://agentic-plugin.com/privacy-policy/)

= Agentic AI (TTS) =
* **Endpoint:** `https://tts.agentic-plugin.com`
* **When used:** When Text to Speech is enabled and an agent reads a chat response aloud, or when `wp agent chat` / `wp agent prompt` is run with TTS active.
* **Data sent:** Site URL, license key, and the text content to be synthesized. No user-identifying information beyond the license key.
* **Terms of Service:** [https://agentic-plugin.com/terms-of-service/](https://agentic-plugin.com/terms-of-service/)
* **Privacy Policy:** [https://agentic-plugin.com/privacy-policy/](https://agentic-plugin.com/privacy-policy/)

= Agentic AI (Video Gen) =
* **Endpoints:** `https://videogen.agentic-plugin.com` (video generation, stitching, trimming, captions, analysis, add audio)
* **When used:** When an agent generates video clips, stitches or edits videos, searches for background music, or adds an audio track.
* **Data sent:** Site URL, license key, text prompts, image data (for image-to-video), video URLs (for editing operations), and audio URLs (for audio mixing).
* **Terms of Service:** [https://agentic-plugin.com/terms-of-service/](https://agentic-plugin.com/terms-of-service/)
* **Privacy Policy:** [https://agentic-plugin.com/privacy-policy/](https://agentic-plugin.com/privacy-policy/)

= Agent Update Checks (Opt In) =
* **Endpoint:** `https://agentic-plugin.com/wp-json/agentic/v1/agents/check-updates`
* **When used:** Only when the administrator has explicitly opted in for update checks on AI agents.
* **Data sent:** Installed agent slugs and version numbers.
* **How to disable:** Decline the opt-in prompt, or deactivate/reactivate the plugin to reset your choice.
* **Terms of Service:** [https://agentic-plugin.com/terms-of-service/](https://agentic-plugin.com/terms-of-service/)
* **Privacy Policy:** [https://agentic-plugin.com/privacy-policy/](https://agentic-plugin.com/privacy-policy/)

= Agentic AI Deregister (on uninstall) =
* **Endpoint:** `https://agentic-plugin.com/wp-json/agentic/v1/deregister` (or the configured Agentic provider endpoint)
* **When used:** During plugin uninstall, only if an API key for the Agentic provider exists (indicating prior use of the hosted service). Sends a non-blocking fire-and-forget POST.
* **Data sent:** API key and site URL (for account cleanup on the service side).
* **Terms of Service:** [https://agentic-plugin.com/terms-of-service/](https://agentic-plugin.com/terms-of-service/)
* **Privacy Policy:** [https://agentic-plugin.com/privacy-policy/](https://agentic-plugin.com/privacy-policy/)

== Changelog ==

= 2.9.254 - 2026-06-04 =
* Release 2.9.254



= 2.9.253 - 2026-06-04 =
* Release 2.9.253



= 2.9.252 - 2026-06-04 =
* Release 2.9.252



= 2.9.251 - 2026-06-04 =
* Release 2.9.251



= 2.9.250 - 2026-06-04 =
* Full P1–P6 (complete, integrated, no stubs): Outbound MCP (full stdio + HTTP JSON-RPC 2.0 with handshake), Workflow Engine (all step types + parallel/join/triggers/checkpoints), DLP + hard caps, Marketplace (signed), signed exports.
* Pro wiring + free executor guard for P4.
* UI polish round: last U1 fallbacks (approvals, train, settings, agents, etc.), P admin forms (hard caps, outbound MCP manager, export button), CSS extraction for new cards.
* readme + pro readme + library/README alignment ("exactly 3 free + safe Trainer", F1-4, full Pro P delights, 7 official screenshots).
* Prereleases green; test site in sync.

= 2.9.249 - 2026-06-04 =
* Release 2.9.249

= 2.9.248 - 2026-06-04 =
* Release 2.9.248

= 2.9.247 - 2026-06-04 =
* Release 2.9.247

= 2.9.246 - 2026-06-04 =
* Release 2.9.246

= 2.9.245 - 2026-06-04 =
* Release 2.9.245



= 2.9.244 - 2026-06-04 =
* Release 2.9.244



= 2.9.243 - 2026-06-04 =
* Release 2.9.243



= 2.9.242 - 2026-06-04 =
* Release 2.9.242



= 2.9.241 - 2026-06-04 =
* Release 2.9.241



= 2.9.240 - 2026-06-04 =
* Release 2.9.240



= 2.9.239 - 2026-06-04 =
* Release 2.9.239



= 2.9.238 - 2026-06-04 =
* Release 2.9.238



= 2.9.237 - 2026-06-04 =
* Release 2.9.237



= 2.9.236 - 2026-06-04 =
* Release 2.9.236



= 2.9.235 - 2026-06-04 =
* Release 2.9.235



= 2.9.234 - 2026-06-04 =
* Release 2.9.234



= 2.9.233 - 2026-06-04 =
* Release 2.9.233



= 2.9.232 - 2026-06-04 =
* Release 2.9.232



= 2.9.231 - 2026-06-04 =
* Release 2.9.231



= 2.9.230 - 2026-06-04 =
* Release 2.9.230



= 2.9.229 - 2026-06-02 =
* Release 2.9.229



= 2.9.228 - 2026-06-03 =
* readme.txt + README.md refresh: Stronger "WordPress 7 + Full Backward Compatibility — The Bridge" positioning throughout (prominent new section, updated Key Features, FAQ "How is it different", requirements, and Free-vs-Pro table). Explicitly call out F1 multi-agent delegation/router + shared runs (now in free), F2 local zero-external memory/facts, F3 productized Abilities bridge + admin page + banners + native passthrough, F4 5 templates. "Cockpit on top of the WP7 engine" messaging. Accurate free agent count and Pro delight clarity. Prerelease remains 16/0.



= 2.9.227 - 2026-06-03 =
* Full strategy gap analysis implementation (F0–F4 + P1 start): Free now ships with complete .org-compliant "orchestration + WP7 bridge" (3 agents, safe trainer, delegate+router, local memory, abilities surface + banners, 5 templates, prerelease 16/0). Added explicit "Upgrade to Pro — Immediate Delights" + free-vs-pro table for clear upgrade value. Pro stubs for workflows (P2). All changes preserve zero pro strings/trialware in free tree; delight via activation-time filter precedence + risk maxing.



= 2.9.226 - 2026-06-02 =
* Release 2.9.226



= 2.9.225 - 2026-06-02 =
* Release 2.9.225



= 2.9.224 - 2026-06-02 =
* Release 2.9.224



= 2.9.223 - 2026-06-02 =
* Release 2.9.223



= 2.9.222 - 2026-06-03 =
* Strategy gap analysis (F0): Added prominent "Upgrade to Agent Builder Pro — Immediate Delights" section explicitly listing unlocks on upgrade (full extreme-power Assistant Trainer with arbitrary code/remote, +7 specialized agents, extreme tools usable in custom agents + trainer, outbound MCP client, durable workflows, hard governance/caps, advanced channels, marketplace, etc.). Free always .org-clean + complete (3 agents incl. safe trainer, delegation primitives, abilities bridge). Prerelease 16/0 + spot checks remain green. Minor UX/a11y polish on remaining delete confirmations. Free-vs-Pro positioning and changelog updated for delight + compliance.



= 2.9.220 - 2026-06-02 =
* Release 2.9.220



= 2.9.219 - 2026-06-02 =
* Release 2.9.219



= 2.9.218 - 2026-06-02 =
* Release 2.9.218



= 2.9.217 - 2026-06-02 =
* Release 2.9.217



= 2.9.216 - 2026-06-02 =
* Release 2.9.216



= 2.9.215 - 2026-06-02 =
* Release 2.9.215



= 2.9.214 - 2026-06-02 =
* Release 2.9.214



= 2.9.213 - 2026-06-02 =
* Release 2.9.213



= 2.9.212 - 2026-06-02 =
* Release 2.9.212



= 2.9.211 - 2026-06-02 =
* Release 2.9.211



= 2.9.210 - 2026-06-02 =
* Release 2.9.210
* WordPress.org compliance audit fixes (June 2026): Migrated high-risk arbitrary-code tools (create_agent_files, install_plugin_from_url, git_pull) and Pro-gated channel tools (send_email, get_email_settings, form_send_to_google_sheet) to the separate Pro add-on (not present in .org build). Reclassified risks to EXTREME. Removed in-build "requires Pro" blocking stubs from free. Added support for Pro tool/agent dirs via filter. Fixed unconditional front-end asset registration, autoload for heavy options, uninstall deregister disclosure + External Services entry in readme.
* Assistant Trainer experience restored to free as a fully functional safe custom-agent creator (uses only pre-existing audited tools; writes only declarative agents to user directory). Full arbitrary tool code generation and high-risk actions remain Pro-only. Updated prerelease, prompts, docs, and guards. See docs/free-assistant-trainer-compliance-plan.md.



= 2.9.209 - 2026-06-02 =
* Release 2.9.209



= 2.9.208 - 2026-05-31 =
* Release 2.9.208



= 2.9.207 - 2026-05-31 =
* Release 2.9.207



= 2.9.206 - 2026-05-31 =
* Release 2.9.206



= 2.9.205 - 2026-05-30 =
* Release 2.9.205



= 2.9.204 - 2026-05-30 =
* Release 2.9.204



= 2.9.203 - 2026-05-30 =
* Release 2.9.203



= 2.9.202 - 2026-05-30 =
* Release 2.9.202



= 2.9.201 - 2026-05-27 =
* Release 2.9.201



= 2.9.201 - Unreleased (In Progress) =
* core stabilization (P0 Free Essential — Item 4 "do all 4" complete): Production-ready hardening of the foundation after Items 1–3 (observability, multi-agent, tool reliability).

* strong agent creation (P0 Free Essential — "Strong Free Agent Creation Experience"): Major quality push on the Assistant Trainer so it becomes a **highly trusted producer of excellent agents**.
  - New strict "Definition of a High-Quality Agent" + mandatory self-critique before writing files.
  - Significantly improved system prompt generation in the trainer (richer, more opinionated prompts modeled on the best bundled agents).
  - validate_agent_code now performs qualitative checks, not just syntax.
  - Trainer now communicates higher standards and only builds when confident in the result.

- Phase 2 tool overhauls (continued):
  - `analyze_requirements` received a major upgrade — far smarter tool discovery and rich quality-aware analysis output.
  - `generate_system_prompt` now produces high-quality, opinionated prompts instead of weak generic ones.
  - Supporting improvements across the creation toolchain.
  - Result: Agents created with the Assistant Trainer are noticeably more focused, better prompted, and more trustworthy out of the box.
  - **Schema migrations (2.10.3)**: Proper versioned migration system now covers provider_type column + critical composite indexes on audit/approval/memory tables. No more ad-hoc ALTERs anywhere. CREATE definitions + migrations are the single source of truth. Upgrades are safe and idempotent.
  - **Job system hardening**: New hourly health checks detect stuck "processing" jobs (>45min) and abandoned "pending" jobs (>6h). Auto-marks them failed with clear messages so async operations (e.g. Assistant Trainer) never hang forever. Self-healing + audit trail for recoveries. Lightweight `get_health()` API.
  - **System Health surface**: Dashboard "Status" card now shows live Schema version + Jobs queue health (pending/running counts + prominent indicators when stuck/abandoned jobs were auto-recovered). Modern, always-visible, zero-config.
  - **Test isolation**: Removed last bootstrap ALTER hacks. Test DB schema now converges cleanly via the same migration code as production installs. Fewer flakies, stricter validation.
  Result: The entire agent orchestration engine (chat, autonomous, scheduled, multi-agent handoffs, tool use on any model) rests on rock-solid, observable, self-healing infrastructure. Free feels premium and trustworthy; Pro builds advanced job dashboards/replay on top.

* tool use (P0 Free Essential — Item 3): Major reliability improvements for weaker and local models (Ollama, Gemma, Phi, small Llama etc.).
  - Tool calling is now enabled for the 'agentic'/small-model path (previously explicitly disabled).
  - Automatic schema simplification for weaker models.
  - Proper tool call response parsing for Ollama-style backends (was completely missing).
  - Robust error-feedback + limited retry loop — models get clear correction messages when they produce invalid JSON or tool calls fail.
  - Dedicated weak-model tool guidance (concise rules + example) automatically injected for smaller models.
  Result: Much more reliable agentic behavior on local and smaller models — one of the highest real-world impact P0 features for the free plugin.
* observability (P0 Free Essential — core slices delivered): significantly improved reasoning visibility and audit transparency. Agents now surface their own step-by-step thinking, tool decision rationales, and iteration traces via the existing rich audit schema (no DB changes).
  - New collapsible "Agent reasoning & steps" cards appear in live chat after tool-using or multi-iteration turns (progressive disclosure — clean for casual users, full visibility for power users and debugging).
  - Audit Log table now has a dedicated Reasoning column with smart truncation + full expander (immediately shows the new captured data from tool_choice and completion entries).
  - Lightweight, filterable reasoning guidance injected into every system prompt (works on strong and weaker models).
  - Per-turn reasoning now logged for both interactive chat and autonomous/scheduled runs.
  - Free agent prompts lightly updated to demonstrate the new habit.
  - Strong Free/Pro split preserved: Free now feels trustworthy and "finished"; Pro P1 can add visual replay, cost-per-step, timelines, etc. on top with zero conflicts.
* ui-ux: new surfaces use modern card/details patterns, consistent with the existing first-class design system.
* ui-ux (Conversations): the admin Conversations browser now delivers a truly impressive, premium experience. Opening any session shows a clean transcript + a beautiful vertical reasoning timeline featuring the agent's actual captured thinking, tool decisions, tokens/cost per step, and provider info — powered by the new observability layer. First-class modern styling (8px cards, timeline rail, differentiated step colors, prominent reasoning blocks).
* ui-ux (Broad + lower-priority consistency): Comprehensive professional polish across *all* admin pages. Added standardized professional tab styling, settings form treatment, approval/skill/tool card patterns, and global consistency rules. Key lower pages (Approvals, Skills, Tools, Settings tabs) wrapped in modern cards or given the full modern treatment. No more dated screens — the entire admin area now feels like a cohesive, premium, professional product with 8px radii, hover states, clean typography, and unified visual language everywhere. Observability features integrate seamlessly.
* feat (Item 2 — COMPLETE): Basic Multi-Agent Orchestration (P0 Free Essential) delivered to production quality.
  - Rich shared context on handoff: last conversation turns + reasoning from previous agent automatically shared.
  - `agent_delegation` events logged with full details (visible in Audit Log).
  - Clean `[HANDOFF FROM ...]` injection into receiving agent's prompt via dedicated Prompt Builder method.
  - Professional handoff banner in chat UI (styled to match reasoning cards).
  - Updated prompts in main free agents to use and explain the capability.
  - Full traces in Audit Log + Conversations UI.
  Result: Free users now get credible, professional agent teams with real handoffs and shared understanding. Polished, consistent with Item 1 observability work. Clear, valuable upgrade path remains for Pro's advanced orchestration (supervisors, parallel, hierarchical, persistent memory, visual builder).
* code-quality: full PHPCS clean on changed files; all new strings/outputs properly escaped; additive changes only.
* docs: complete synthesis + proposal in CLAUDE.md before any code; progress log updated after each slice.

= 2.9.200 - 2026-05-24 =
* production: comprehensive code standards audit and cleanup — all auto-fixable PHPCS violations resolved; remaining style issues (docs, Yoda, ternaries) addressed in core classes for WP.org submission readiness
* security: full review of nonces, REST permission callbacks, sanitization/escaping, capability checks, and CSRF protection across admin AJAX, chat endpoints, and deployments — production grade
* architecture: reviewed registries (agents, tools, skills, providers), lazy loading strategy in main bootstrap, custom deployments table, and 462-tool discovery loader — no major refactors required; patterns confirmed solid and efficient
* ui-ux: modernized admin dashboard and page aesthetics — upgraded cards (8px radius, subtle shadows, hover lift), provider rows, quick-action grids, form polish, and consistent spacing/typography aligned with contemporary WP admin
* ui-ux: first-class chat interface enhancements — improved focus rings and keyboard accessibility, refined input shadows and transitions, modern streaming cursor animation, better mobile responsiveness for agent selector and messages, message action button polish
* compliance: added proper file doc headers to all silence index.php files and key classes; updated dynamic index.php generators; verified readme.txt, external services disclosure, GDPR, and uninstall data handling
* improvement: reduced total PHPCS errors from 102+ to near-zero (style/docs only remain in low-risk internal methods); plugin now passes strict WordPress Coding Standards cleanly for core runtime files

= 2.9.199 - 2026-05-12 =
* improvement: signup configuration section redesigned as a two-column grid with inline explanations for each setting
* improvement: "Reset" button added to signup config section to restore defaults in one click
* improvement: model labels shortened to 1–2 words for better readability in dropdowns
* improvement: prerelease smoke-test script now uses configurable TEST_SITE env variable

= 2.9.198 - 2026-05-08 =
* refactor: removed hardcoded pricing from built-in Agentic AI provider; pricing now fetched live via the Get Latest Pricing operation

= 2.9.197 - 2026-05-08 =
* improvement: added Gemma 4 26B model to the Agentic AI provider
* improvement: Agentic AI model rates updated with 50% markup

= 2.9.196 - 2026-05-08 =
* fix: post-merge hook now survives www-data ownership reset via sudo chmod +x



= 2.9.195 - 2026-05-07 =
* Release 2.9.195



= 2.9.194 - 2026-05-07 =
* fix: SSE streaming now works correctly with tool calls and cache-hit responses
* fix: dashboard audit-log links corrected to the right page slug
* fix: Usage and Agent Health dashboard buttons removed from free build (WP.org guideline 5 compliance)
* fix: welcome message and agent shortcuts now reflect only active agents
* improvement: dashboard "Tools & Channels" renamed to "Tools"; Skills quick-action button added
* improvement: chat UI cleanup and message action bar (copy, thumbs, regenerate)

= 2.9.154 - 2026-05-04 =
* Release 2.9.154



= 2.9.145 - 2026-05-03 =
* feat: Agent delegation — context-switch buttons let you hand off to any installed agent mid-conversation

= 2.9.141 - 2026-05-01 =
* feat: SSE streaming for chat — agent responses now stream in real time instead of waiting for the full reply
* refactor: Agent_Prompt_Builder extracted to a dedicated class; unused Plugin methods removed

= 2.9.108 - 2026-04-30 =
* feat: 42 new tools and 8 new skills (content planning, web browsing, translation, data analysis, PDF/DOCX, XLSX)
* fix: TTS word-by-word sync with audio playback;

For the full version history, visit [agentic-plugin.com/changelog](https://agentic-plugin.com/changelog/).

== Upgrade Notice ==

= 2.9.200 =
UI/UX modernization, full WordPress Coding Standards compliance pass, security & architecture review. Production-ready for WP.org. No breaking changes.

= 2.9.194 =
SSE streaming fixes, dashboard improvements, and WP.org compliance updates. No breaking changes.

= 2.9.145 =
SSE streaming, 42 new tools, agent delegation, and TTS improvements. No breaking changes.

= 2.9.38 =
Privacy improvement: LLM connection only makes external request with explicit user consent.

== Legal ==

By using this plugin you agree to our [Terms of Service](https://agentic-plugin.com/terms-of-service/) and [Privacy Policy](https://agentic-plugin.com/privacy-policy/)